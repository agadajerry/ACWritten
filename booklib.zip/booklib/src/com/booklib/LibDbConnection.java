package com.booklib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class LibDbConnection {

	public static Connection getConnection()
	 {
		 Connection conn = null;
		 try
		 {

			 String dbURL = "jdbc:sqlite:C:\\Book_Library\\bookLib.db";
			 
			
			 conn = DriverManager.getConnection(dbURL);
			
			 
		 }catch(SQLException ex)
		 {
			 System.out.println(ex.getMessage()+" DB connection");
		 }
		 return conn;
	 }
	
}

