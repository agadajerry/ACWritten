package com.booklib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class CreateCellDialog extends JDialog {

	private JButton cancelB, okBtn;

	public CreateCellDialog() {

		setSize(new Dimension(440, 220));

		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setUndecorated(true);
		setLayout(null);
		getRootPane().setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, new Color(0, 118, 255)));

		// this.setTitle();
		setLocationRelativeTo(null);
		setBackground(Color.WHITE);
		setModal(true);

		JLabel detailLabel = new JLabel("Enter Shelf Cell you want to Create:", JLabel.CENTER);
		detailLabel.setBounds(100, 30, 200, 30);
		add(detailLabel);

		JTextField inputField = new JTextField(20);
		inputField.setBounds(100, 70, 200, 30);
		add(inputField);
		okBtn = new JButton("CREATE");
		okBtn.setBounds(100, 110, 100, 30);
		add(okBtn);
		cancelB = new JButton("CANCEL");
		cancelB.setBounds(210, 110, 95, 30);
		cancelB.setForeground(new Color(0,120,230));
		okBtn.setForeground(new Color(0,120,230));
		add(cancelB);
		cancelB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				dispose();// exit this dialog
			}

		});

		okBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				if (inputField.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Enter Shelf Cell information to Create.");
				} else {
					PreparedStatement ps = null;
					try {
						ps = LibDbConnection.getConnection()
								.prepareStatement("Create TABLE "+inputField.getText().toUpperCase()+" ( s_no TEXT NOT NULL UNIQUE, "
										+ "bookName TEXT NOT NULL,"
										+ " author TEXT, Quantity INT NOT NULL, PRIMARY KEY (s_no))");
						ps.execute();
						JOptionPane.showMessageDialog(null, inputField.getText().toUpperCase()+" Table Created Successfully");
						inputField.setText(null);

					} catch (SQLException exc) {
						JOptionPane.showMessageDialog(null, exc);
					} finally {
						try {
							LibDbConnection.getConnection().close();
						} catch (SQLException ex) {
							ex.printStackTrace();
						}
					}
				}
			}

		});

	}

}
