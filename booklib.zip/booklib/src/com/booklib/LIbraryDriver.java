package com.booklib;

import java.awt.Color;
import java.awt.Dimension;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class LIbraryDriver extends JDialog{

	public static void main(String[] args) {
     new LIbraryDriver();
     createFolder();
	}
	
	public LIbraryDriver() {
		
		setSize(new Dimension(500, 300));
		setLocationRelativeTo(null);
		setUndecorated(true);
		initialiseUi();
	}
	private void initialiseUi() {

		JPanel welcomePanel = new JPanel();
		welcomePanel.setLayout(null);
		welcomePanel.setBackground(Color.WHITE);
		ImageIcon northBgIcon = new ImageIcon(getClass().getResource("/com/booklib/images/welcome.png"));
		
		JLabel labelIcon = new JLabel("",northBgIcon, JLabel.CENTER);
		labelIcon.setBounds(0, 50, 500, 173);
		welcomePanel.add(labelIcon);
		JLabel loading = new JLabel("Wait...");
		loading.setBounds(250, 180, 250, 180);
		welcomePanel.add(loading);
		add(welcomePanel);
		
		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					Thread.sleep(5000);
					Book_Library bizHome = new Book_Library();
					bizHome.setVisible(true);
					dispose();

				} catch (InterruptedException e) {

				}
			}
			
		}).start();
		
		setVisible(true);
	}

	private static void createFolder() {

		String dbURL_location = "C:\\Book_Library\\";

		File newFile = new File(dbURL_location);
		if (!newFile.exists()) {
			newFile.mkdirs();
		}		
	}

}
