package com.booklib;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

public class Book_Library extends JFrame {
	private JTable table;
	private DefaultTableModel tModel = new DefaultTableModel();
	private JButton[] qryBtn = new JButton[4];
	private JTextField[] inputField = new JTextField[5];
	private JLabel[] inputLabel = new JLabel[5];
	private JLabel totalBooks, availableBkLabel, cellLabel;
	private JButton clearBtn;
	private SimpleDateFormat sDate = new SimpleDateFormat("dd-MM-yyyy");
	private Date date;

	public Book_Library() {
		inialiseUi();
		menuUi();
	}

	private void menuUi() {

		// Menu section Code
		// menu bar and items
		JMenuBar mBar = new JMenuBar();
		JMenu filemenu = new JMenu("File");
		filemenu.setMnemonic(KeyEvent.VK_F);
		JMenu editMenu = new JMenu("Edit");
		JMenu help = new JMenu("Help");
		help.setMnemonic(KeyEvent.VK_H);
		editMenu.setMnemonic(KeyEvent.VK_E);

		mBar.add(filemenu);
		mBar.add(editMenu);
		mBar.add(help);
		// mBar.setBackground(new Color(240, 98, 146));

		JMenuItem newBook = new JMenuItem("ADD NEW BOOK");
		JMenuItem deleteCell = new JMenuItem("DELETE CELL");
		JMenuItem addCell = new JMenuItem("ADD NEW CELL");
		JMenuItem deleteBook = new JMenuItem("DELETE BOOK");
		JMenuItem aboutDev = new JMenuItem("ABOUT");
		aboutDev.addActionListener(new AboutDevListener());

		newBook.setMnemonic(KeyEvent.VK_N);
		newBook.addActionListener(new AddBookListener());
		deleteCell.setMnemonic(KeyEvent.VK_D);
		deleteCell.addActionListener(new ShelfCellDelete());
		addCell.setMnemonic(KeyEvent.VK_C);
		aboutDev.setMnemonic(KeyEvent.VK_A);

		filemenu.add(newBook);
		filemenu.addSeparator();
		filemenu.add(deleteCell);
		filemenu.add(addCell);
		addCell.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				CreateCellDialog cD = new CreateCellDialog();
				cD.setVisible(true);
			}

		});
		//
		filemenu.add(deleteBook);
		deleteBook.addActionListener(new DeleteBookListener());
		help.add(aboutDev);
		setJMenuBar(mBar);
	}

	private void inialiseUi() {
		setSize(new Dimension(1300, 700));
		setTitle("Library management system");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource
				("/com/booklib/images/applogo.png"));
		setIconImage(icon);
		
		JPanel northPanel = new JPanel();
		northPanel.setBackground(new Color(255, 255, 255));
		northPanel.setPreferredSize(new Dimension(1200, 200));
		ImageIcon northBgIcon = new ImageIcon(getClass().getResource("/com/booklib/images/lib_heading.png"));
		JLabel northLabel = new JLabel("", northBgIcon, JLabel.CENTER);

		northPanel.add(northLabel);
		northPanel.add(new JLabel("The best Book Store"));
		northPanel.setBorder(new LineBorder(new Color(0,130,230),2));

		add(northPanel, BorderLayout.NORTH);

		// westPanel for text fields and button

		JPanel westPanel = new JPanel(new GridLayout(2, 1));
		westPanel.setBorder(new LineBorder(Color.BLACK,2));
		// two panels in western part of the container
		JPanel firstWPanel = new JPanel(new GridLayout(5, 2, 3, 3));
		// firstWPanel.setBackground(Color.WHITE);
		firstWPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		JPanel secondWPanel = new JPanel(new GridLayout(1, 2, 3, 3));
		// divide second west panel secondWPanel into two

		JPanel secondW1Panel = new JPanel(new GridLayout(4, 1));// this is an information panel

		JPanel secondW2Panel = new JPanel(new GridLayout(4, 1));
		secondWPanel.add(secondW1Panel);
		secondWPanel.add(secondW2Panel);
		secondWPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		secondWPanel.setBackground(Color.WHITE);

		// adding the above two panel to main west Panel

		westPanel.add(firstWPanel);
		westPanel.add(secondWPanel);
		// looping for label and input
		for (int i = 0; i < inputLabel.length; i++) {
			inputLabel[i] = new JLabel();
			inputField[i] = new JTextField();
			inputField[i].setPreferredSize(new Dimension(300, 30));
			inputLabel[i].setPreferredSize(new Dimension(100, 30));
			inputLabel[i].setForeground(new Color(0, 130, 230));
			inputLabel[i].setBorder(new LineBorder(new Color(204, 204, 204), 2));
			inputField[i].setBorder(new LineBorder(new Color(63, 63, 63), 2));
			inputLabel[i].setFont(new Font("David", 1, 20));
			inputField[i].setFont(new Font("David", 1, 20));
			firstWPanel.add(inputLabel[i]);
			firstWPanel.add(inputField[i]);
		}
		// focus listener for cell name
		inputField[0].addFocusListener(new TotalCellBookFocu());

		inputLabel[0].setText("ENTER CELL LABEL:");
		inputLabel[1].setText("BOOK NAME:");
		inputLabel[2].setText("BOOK S/NO:");
		inputLabel[3].setText("QUANTITY:");
		inputLabel[4].setText("AUTHOR:");

		// query buttons
		for (int j = 0; j < qryBtn.length; j++) {
			qryBtn[j] = new JButton();
			qryBtn[j].setPreferredSize(new Dimension(200, 30));
			qryBtn[j].setBackground(Color.WHITE);
			qryBtn[j].setForeground(new Color(0, 130, 230));
			qryBtn[j].setFont(new Font("David", 1, 20));
			qryBtn[j].setBorder(new LineBorder(new Color(204, 204, 204), 3));
			qryBtn[j].addFocusListener(new MouseClassListener());

			secondW2Panel.add(qryBtn[j]);

		}
		qryBtn[0].setText("SEARCH BOOK");
		qryBtn[1].setText("REMOVE BOOK");
		qryBtn[2].setText("UPDATE SHELF");
		qryBtn[3].setText("ADD NEW BOOK");
		qryBtn[3].addActionListener(new AddNewBookListener());
		qryBtn[0].addActionListener(new SearchBookListina());
		qryBtn[1].addActionListener(new BookGiveOutListina());
		qryBtn[2].addActionListener(new BookUpdateListina());

		/*
		 * ImageIcon addIcon = new
		 * ImageIcon(getClass().getResource("/lib/images/addnew.jpg")); ImageIcon
		 * minusIcon = new ImageIcon(getClass().getResource("/lib/images/minus.jpg"));
		 * ImageIcon searchIcon = new
		 * ImageIcon(getClass().getResource("/lib/images/search.jpg")); ImageIcon
		 * plusIcon = new ImageIcon(getClass().getResource("/lib/images/book.jpg"));
		 */

		// info panel for displaying available books
		JLabel infoLabel = new JLabel("Shelve Cell Information", SwingConstants.CENTER);
		availableBkLabel = new JLabel("Search Result: ");
		availableBkLabel.setFont(new Font("David", 1, 20));
		totalBooks = new JLabel("Total Books in Shelf:");
		totalBooks.setFont(new Font("David", 1, 20));
		cellLabel = new JLabel("Total Shelve Cells: 700");
		cellLabel.setFont(new Font("David", 1, 20));
		totalBooks.setFont(new Font("David", 1, 20));
		infoLabel.setForeground(new Color(0, 130, 230));
		totalBooks.setForeground(new Color(0, 130, 230));
		cellLabel.setForeground(new Color(0, 130, 230));
		availableBkLabel.setForeground(new Color(0, 130, 230));
		infoLabel.setFont(new Font("David", 1, 20));
		totalBooks.setBorder(new LineBorder(new Color(0, 130, 230)));
		cellLabel.setBorder(new LineBorder(new Color(0, 130, 230)));
		availableBkLabel.setBorder(new LineBorder(new Color(0, 130, 230)));
		secondW1Panel.add(infoLabel);
		secondW1Panel.add(availableBkLabel);
		secondW1Panel.add(totalBooks);
		secondW1Panel.add(cellLabel);
		add(westPanel, BorderLayout.WEST);

		// Today's date showing on the label
		sDate = new SimpleDateFormat("dd-MM-yyyy");
		date = new Date();
		cellLabel.setText("Today's Date: " + sDate.format(date));
		//
		// centerPanel hold table
		JPanel eastPanel = new JPanel();
		eastPanel.setBorder(new LineBorder(Color.BLACK,2));
		eastPanel.setBackground(Color.WHITE);
		String[] columnName = { "Serial No", "Book Name", "Author, Quantity" };
		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 14));
		table.getTableHeader().setBackground(new Color(0, 130, 230));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(30);
		table.setForeground(Color.RED);

		tModel = (DefaultTableModel) table.getModel();
		tModel.setColumnIdentifiers(columnName);
		JScrollPane tableScroll = new JScrollPane(table);
		tableScroll.setPreferredSize(new Dimension(700, 400));
		eastPanel.add(tableScroll);

		// east Panel with button and check btn
		clearBtn = new JButton("CLEAR TABLE");
		clearBtn.setPreferredSize(new Dimension(200, 50));
		clearBtn.setForeground(new Color(0, 130, 230));
		clearBtn.addActionListener(new ClearTableListener());
		clearBtn.addFocusListener(new ClearTableFocusListener());
		clearBtn.setFont(new Font("David", Font.BOLD, 20));
		clearBtn.setBackground(Color.WHITE);
		clearBtn.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		eastPanel.add(clearBtn);

		add(eastPanel, BorderLayout.CENTER);

		// bottom panel displacing database info

		JPanel bottomPanel = new JPanel(new GridLayout());
		bottomPanel.setBackground(Color.WHITE);
		bottomPanel.setBorder(new LineBorder(new Color(0,130,230),2));

		bottomPanel.add(new JLabel("Coded By: JerrySoft", JLabel.RIGHT));
		add(bottomPanel, BorderLayout.SOUTH);
		setVisible(true);
	}

	private class AddNewBookListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			
			
			if (inputField[0].getText().equals("") || inputField[1].getText().equals("")
					|| inputField[2].getText().equals("") || inputField[4].getText().equals("")) {
				JOptionPane.showMessageDialog(null, "One or all Input Fields are empty...");
			} else {
				PreparedStatement ps = null;
				String qry = "INSERT INTO " + inputField[0].getText().toUpperCase()
						+ "(s_No, BookName, author, Quantity) Values (?, ?, ?,?)";
				try {
					ps = LibDbConnection.getConnection().prepareStatement(qry);

					ps.setString(1, inputField[2].getText().toString().toUpperCase().trim());
					ps.setString(2, inputField[1].getText().toString().toUpperCase().trim());
					ps.setString(3, inputField[4].getText().toString().toUpperCase().trim());
					ps.setInt(4, Integer.parseInt(inputField[3].getText().toString().trim()));
					ps.execute();

					JOptionPane.showMessageDialog(null, inputField[1].getText() + " With Serial No: "
							+ inputField[2].getText() + " Inserted into Cell " + inputField[0].getText());
					for (int i = 0; i < inputField.length; i++) {
						inputField[i].setText(null);
					}

				} catch (NumberFormatException nfe) {
					inputField[3].setText("Enter Only number for Qtty");

				} catch (SQLException ex) {

					int choice = JOptionPane.showConfirmDialog(null,
							"The Shelf Cell specified is not available\n\n " + "Do you want to create Cell ["
									+ inputField[0].getText().substring(0, 1).toUpperCase() + "]" + " Arrays ?");

					if (choice == JOptionPane.YES_OPTION) {
						try {
							for (int i = 0; i < 5; i++) {
								PreparedStatement pst = null;

								String qry2 = "Create TABLE "
										+ inputField[0].getText().substring(0, 1).toUpperCase() + (i + 1) + " "
										+ "( s_no TEXT NOT NULL UNIQUE, bookName TEXT NOT NULL, author TEXT, Quantity INT "
										+ "NOT NULL, PRIMARY KEY (s_no) )";
								pst = LibDbConnection.getConnection().prepareStatement(qry2);
								pst.execute();
							}
						} catch (SQLException exc) {
							JOptionPane.showMessageDialog(null, "The Shelf Cell Or Serial Number Already Taken.\n"
									+ " Check Your Entry And Try Again");

						}
						JOptionPane.showMessageDialog(null,
								"[" + inputField[0].getText().substring(0, 1).toUpperCase()
										+ "]  Array of Cells Created Successfully...\n " + "Add Your Entry again");
					}

				} finally {
					try {
						LibDbConnection.getConnection().close();
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}

			}
		}
	}

	// serach book class
	private class SearchBookListina implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (BookOutValidation.check4Book(inputField[2].getText(), inputField[0].getText().toUpperCase(),
					inputField[1].getText().toUpperCase())) {

				JOptionPane.showMessageDialog(null, inputField[1].getText().toUpperCase() + " Is in Shelf Cell "
						+ inputField[0].getText().toUpperCase());

				//
				availableBkLabel.setText(inputField[1].getText().toString() + " " + inputField[2].getText().toString()
						+ " Is Available.");

				// change back the label of search result after 5 sec
				if (inputField[0].getText().toUpperCase().isEmpty() || inputField[2].getText().isEmpty()) {
					System.out.println("Emput Fields");
				} else {
					new Thread(new Runnable() {

						@Override
						public void run() {
							try {
								Thread.sleep(5000);
								availableBkLabel.setText("Search Result: ");
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}

					}).start();
				}
			}
		}
	}

	// borrowing or selling of book which is out of the shelf. This is the class
	// handling such thing
	private class BookGiveOutListina implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {

			if (inputField[0].getText().equals("") || inputField[2].getText().equals("")
					|| inputField[3].getText().equals("")) {
				JOptionPane.showMessageDialog(null, "PLEASE ENTER THE SHELF CELL NAME, BOOK SERIAL NUMBER\n"
						+ "AND THE QUANTITY YOU WANT TO REMOVE");
			} else {
				int bookRemain = BookOutValidation.bookWaring(inputField[0].getText().toUpperCase(),
						inputField[2].getText());

				if (bookRemain <= 0) {
					System.out.println("No Book in the shelf");
				} else {
					if (!BookOutValidation.check4Book(inputField[2].getText(), inputField[0].getText().toUpperCase(),
							inputField[1].getText().toUpperCase())) {
						JOptionPane.showMessageDialog(null, "Not Such Book To Remove. Check Your Entry Again....");
					} else {
						// check if book is enough in the shelf

						int result = BookOutValidation.removeBook(inputField[2].getText().toString().trim(),
								inputField[0].getText().toString().trim().toUpperCase(),
								Integer.parseInt(inputField[3].getText().toString().trim()));
						if (result > 0) {
							JOptionPane.showMessageDialog(null,
									inputField[3].getText() + " Book with serial Number: " + inputField[2].getText()
											+ " is removed " + "from Shelf " + inputField[0].getText().toUpperCase());
						}

					}
				}
			}
		}

	}

	// focus listener for cell entry
	private class TotalCellBookFocu implements FocusListener {

		@Override
		public void focusGained(FocusEvent arg0) {
		}

		@Override
		public void focusLost(FocusEvent arg0) {

			allBookInCell();
			showBooksOnCell(); // show all Books in a specified cell
		}

	}

	/// method for all books in a shelf cell

	private void allBookInCell() {

		if (inputField[0].getText().equals("")) {
			System.out.println("empty field");
		} else {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = LibDbConnection.getConnection().prepareStatement(
						"" + "Select COUNT(bookName) as Book From " + inputField[0].getText().toUpperCase());
				rs = ps.executeQuery();
				while (rs.next()) {
					totalBooks.setText(
							"Total Books In " + inputField[0].getText().toUpperCase() + "::" + rs.getString("Book"));
				}
			} catch (SQLException ex) {
				System.out.println("No such cell table");
			} finally {
				try {

					LibDbConnection.getConnection().close();
				} catch (SQLException exc) {
					exc.printStackTrace();
				}
			}
		}
	}

	// display the value on a table when cell is focus
	private void showBooksOnCell() {
		if (inputField[0].getText().isEmpty()) {
			System.out.println("Cell Fields Is empty");
		} else {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = LibDbConnection.getConnection()
						.prepareStatement("Select * From " + inputField[0].getText().toUpperCase());
				rs = ps.executeQuery();
				table.setModel(DbUtils.resultSetToTableModel(rs));

			} catch (SQLException ex) {
				JOptionPane.showMessageDialog(null, "No Such Table");
			} finally {
				try {

					LibDbConnection.getConnection().close();

				} catch (SQLException exc) {
					JOptionPane.showMessageDialog(null, "No Such Table");
				}
			}
		}
	}

	// reset table
	private class ClearTableListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			table.setModel(tModel);
		}

	}

	// update class
	private class BookUpdateListina implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			updateShelf();
		}

	}

	// update shelf method
	private void updateShelf() {
		if (inputField[0].getText().equals("") || inputField[2].getText().equals("")
				|| inputField[3].getText().equals("") || inputField[4].getText().equals("")) {
			JOptionPane.showMessageDialog(null, "FILL IN THE FIELDS TO UPDATE THE REQUIRED BOOK INFORMTION.");
		} else {

			
			PreparedStatement ps = null;
			
			String qry = "Update " + inputField[0].getText().toUpperCase() + " SET bookName=?, Quantity=?, author=? "
					+ "WHERE s_no=?";

			try {
				ps = LibDbConnection.getConnection().prepareStatement(qry);

				ps.setString(1, inputField[1].getText().toString().toUpperCase());
				ps.setInt(2, Integer.parseInt(inputField[3].getText().toString().trim()));
				ps.setString(3, inputField[4].getText().toString().toUpperCase());
				ps.setString(4, inputField[2].getText().toString().toUpperCase());
				ps.execute();
				JOptionPane.showMessageDialog(null, "Data Updated Successfully...");

				inputField[1].setText("");
				inputField[2].setText("");
				inputField[3].setText("");
				inputField[4].setText("");

			} catch (SQLException ex) {
				ex.printStackTrace();
			} finally {
				try {
					ps.close();
					LibDbConnection.getConnection().close();

				} catch (SQLException exc) {
					exc.printStackTrace();
				}
			}

		}
	}
	// shelf cell deletion class

	private class ShelfCellDelete implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			DeleteCellDialog deleteCell = new DeleteCellDialog();
			deleteCell.setVisible(true);
		}

	}

	// add book dialog
	private class AddBookListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			AddNewBookDialog addBook = new AddNewBookDialog();
			addBook.setVisible(true);
		}

	}

	// delete book listener class
	private class DeleteBookListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			DeleteBookDialog dBdialog = new DeleteBookDialog();
			dBdialog.setVisible(true);
		}

	}

	// about developer
	private class AboutDevListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			AboutDevDialog aDd = new AboutDevDialog();
			aDd.setVisible(true);
		}

	}

// mouse listener
	private class MouseClassListener implements FocusListener {

		@Override
		public void focusGained(FocusEvent ev) {

			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("SEARCH BOOK")) {
				qryBtn[0].setBackground(new Color(0,130,230));
				qryBtn[0].setForeground(Color.WHITE);

			}
			//
			if (btn.getActionCommand().equals("REMOVE BOOK")) {
				qryBtn[1].setBackground(new Color(0,130,230));
				qryBtn[1].setForeground(Color.WHITE);

			}
			if (btn.getActionCommand().equals("UPDATE SHELF")) {
				qryBtn[2].setBackground(new Color(0,130,230));
				qryBtn[2].setForeground(Color.WHITE);

			}
			if (btn.getActionCommand().equals("ADD NEW BOOK")) {
				qryBtn[3].setBackground(new Color(0,130,230));
				qryBtn[3].setForeground(Color.WHITE);

			}
			
		}

		@Override
		public void focusLost(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("SEARCH BOOK")) {
			qryBtn[0].setBackground(Color.WHITE);
			qryBtn[0].setForeground(new Color(0,130,230));
			}
			if (btn.getActionCommand().equals("REMOVE BOOK")) {
				qryBtn[1].setBackground(Color.WHITE);
				qryBtn[1].setForeground(new Color(0,130,230));
				}
			if (btn.getActionCommand().equals("UPDATE SHELF")) {
				qryBtn[2].setBackground(Color.WHITE);
				qryBtn[2].setForeground(new Color(0,130,230));
				}
			if (btn.getActionCommand().equals("ADD NEW BOOK")) {
				qryBtn[3].setBackground(Color.WHITE);
				qryBtn[3].setForeground(new Color(0,130,230));
				}
			
			

		}
	}
	//clear table button focus listener class for hover effect
	private class ClearTableFocusListener implements FocusListener{

		@Override
		public void focusGained(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("CLEAR TABLE")) {
				clearBtn.setBackground(new Color(0,130,230));
				clearBtn.setForeground(Color.WHITE);

			}			
		}

		@Override
		public void focusLost(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("CLEAR TABLE")) {
				clearBtn.setBackground(Color.WHITE);
				clearBtn.setForeground(new Color(0,130,230));
				}
		}
		
	}
	// Validate serial number before update the table
	
}
