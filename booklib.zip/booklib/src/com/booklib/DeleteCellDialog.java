package com.booklib;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class DeleteCellDialog extends JDialog {

	private DeleteCellDialogData data = new DeleteCellDialogData();

	public DeleteCellDialog() {

		setSize(new Dimension(440, 220));

		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setUndecorated(true);
		setLayout(null);
		getRootPane().setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, new Color(0, 118, 255)));

		// this.setTitle();
		setLocationRelativeTo(null);
		setBackground(Color.WHITE);
		setModal(true);

		JLabel detailLabel = new JLabel("Enter Shelf Cell you want to delete:", JLabel.CENTER);
		detailLabel.setBounds(100, 30, 200, 30);
		add(detailLabel);

		JTextField inputField = new JTextField(20);
		inputField.setBounds(100, 70, 200, 30);
		add(inputField);
		data.okBtn = new JButton("DELETE");
		data.okBtn.setBounds(100, 110, 100, 30);
		add(data.okBtn);
		data.cancelB = new JButton("CANCEL");
		data.cancelB.setBounds(210, 110, 95, 30);
		data.cancelB.setForeground(new Color(0,120,230));
		data.okBtn.setForeground(new Color(0,120,230));
		add(data.cancelB);
		data.cancelB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				dispose();// exit this dialog
			}

		});

		data.okBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				if (inputField.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Enter Shelf Cell information to delete.");
				} else {
					PreparedStatement ps = null;
					try {
						ps = LibDbConnection.getConnection()
								.prepareStatement("Drop" + " Table " + inputField.getText().toUpperCase());
						ps.execute();
						JOptionPane.showMessageDialog(null, inputField.getText().toUpperCase()+" Deleted Successfully");
						inputField.setText(null);

					} catch (SQLException exc) {
						JOptionPane.showMessageDialog(null, "No Such table exist");
					} finally {
						try {
							LibDbConnection.getConnection().close();
						} catch (SQLException ex) {
							ex.printStackTrace();
						}
					}
				}
			}

		});

	}

}
