package com.booklib;

import javax.swing.JButton;

public class DeleteCellDialogData {
	public JButton cancelB;
	public JButton okBtn;

	public DeleteCellDialogData() {
	}
}