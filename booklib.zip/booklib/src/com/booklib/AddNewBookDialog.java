package com.booklib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class AddNewBookDialog extends JDialog {

	private JTextField[] inputField = new JTextField[5];
	private JLabel[] inputLabel = new JLabel[5];
	private JButton addBtn, cancelBtn;

	public AddNewBookDialog() {
		setSize(new Dimension(650, 500));
		setTitle("Library management system");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setResizable(false);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		JPanel northPanel = new JPanel();
		northPanel.setBackground(new Color(255, 255, 255));
		northPanel.setPreferredSize(new Dimension(1200, 200));
		ImageIcon northBgIcon = new ImageIcon(getClass().getResource("/com/booklib/images/lib_heading.png"));
		JLabel northLabel = new JLabel("", northBgIcon, JLabel.CENTER);
		setModal(true);
		northPanel.add(northLabel);
		northPanel.add(new JLabel("Add New Book To The Store"));
		add(northPanel, BorderLayout.NORTH);
		initUi();
	}

	private void initUi() {
		JPanel centerPanel = new JPanel(new GridLayout(5, 2));
		centerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		for (int i = 0; i < inputLabel.length; i++) {
			inputLabel[i] = new JLabel();
			inputField[i] = new JTextField();
			inputField[i].setPreferredSize(new Dimension(300, 30));
			inputLabel[i].setPreferredSize(new Dimension(100, 30));
			inputLabel[i].setForeground(new Color(0, 130, 230));
			inputLabel[i].setBorder(new LineBorder(new Color(204, 204, 204), 2));
			inputField[i].setBorder(new LineBorder(new Color(63, 63, 63), 2));
			inputLabel[i].setFont(new Font("David", 1, 20));
			inputField[i].setFont(new Font("David", 1, 20));
			centerPanel.add(inputLabel[i]);
			centerPanel.add(inputField[i]);
		}
		inputLabel[0].setText("ENTER CELL LABEL:");
		inputLabel[1].setText("BOOK NAME:");
		inputLabel[2].setText("BOOK S/NO:");
		inputLabel[3].setText("QUANTITY:");
		inputLabel[4].setText("AUTHOR:");
		add(centerPanel, BorderLayout.CENTER);

		// button add and cancel in south panel

		JPanel southPanel = new JPanel(new GridLayout());
		southPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

		cancelBtn = new JButton("CANCEL");
		addBtn = new JButton("ADD NEW BOOK");
		cancelBtn.setBackground(Color.WHITE);
		cancelBtn.setForeground(new Color(0, 130, 230));
		cancelBtn.setFont(new Font("David", 1, 20));
		cancelBtn.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		cancelBtn.setPreferredSize(new Dimension(150, 30));
		cancelBtn.addFocusListener(new CancelHoverListener());
		addBtn.setPreferredSize(new Dimension(150, 30));
		//
		addBtn.setBackground(Color.WHITE);
		addBtn.setForeground(new Color(0, 130, 230));
		addBtn.setFont(new Font("David", 1, 20));
		addBtn.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		southPanel.add(addBtn);
		southPanel.add(cancelBtn);
		add(southPanel, BorderLayout.SOUTH);
		addBtn.addFocusListener(new AddHoverListener());
		// action listener
		addBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				if (inputField[0].getText().equals("") || inputField[1].getText().equals("")
						|| inputField[2].getText().equals("") || inputField[4].getText().equals("")) {
					JOptionPane.showMessageDialog(null, "One or all Input Fields are empty...");
				} else {
					PreparedStatement ps = null;
					String qry = "INSERT INTO " + inputField[0].getText().toUpperCase()
							+ "(s_No, BookName, author, Quantity) Values (?, ?, ?,?)";
					try {
						ps = LibDbConnection.getConnection().prepareStatement(qry);

						ps.setString(1, inputField[2].getText().toString().toUpperCase().trim());
						ps.setString(2, inputField[1].getText().toString().toUpperCase().trim());
						ps.setString(3, inputField[4].getText().toString().toUpperCase().trim());
						ps.setInt(4, Integer.parseInt(inputField[3].getText().toString().trim()));
						ps.execute();

						JOptionPane.showMessageDialog(null, inputField[1].getText() + " With Serial No: "
								+ inputField[2].getText() + " Inserted into Cell " + inputField[0].getText());
						for (int i = 0; i < inputField.length; i++) {
							inputField[i].setText(null);
						}

					} catch (NumberFormatException nfe) {
						inputField[3].setText("Enter Only number for Qtty");

					} catch (SQLException ex) {

						int choice = JOptionPane.showConfirmDialog(null,
								"The Shelf Cell specified is not available\n\n " + "Do you want to create Cell ["
										+ inputField[0].getText().substring(0, 1).toUpperCase() + "]" + " Arrays ?");

						if (choice == JOptionPane.YES_OPTION) {
							try {
								for (int i = 0; i < 5; i++) {
									PreparedStatement pst = null;

									String qry2 = "Create TABLE "
											+ inputField[0].getText().substring(0, 1).toUpperCase() + (i + 1) + " "
											+ "( s_no TEXT NOT NULL UNIQUE, bookName TEXT NOT NULL, author TEXT, Quantity INT "
											+ "NOT NULL, PRIMARY KEY (s_no) )";
									pst = LibDbConnection.getConnection().prepareStatement(qry2);
									pst.execute();
								}
							} catch (SQLException exc) {
								JOptionPane.showMessageDialog(null, "The Shelf Cell Or Serial Number Already Taken.\n"
										+ " Check Your Entry And Try Again");

							}
							JOptionPane.showMessageDialog(null,
									"[" + inputField[0].getText().substring(0, 1).toUpperCase()
											+ "]  Array of Cells Created Successfully...\n " + "Add Your Entry again");
						}

					} finally {
						try {
							LibDbConnection.getConnection().close();
						} catch (SQLException ex) {
							ex.printStackTrace();
						}
					}

				}

			}

		});
		// cancel this dialog box
		cancelBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				dispose();// exit this dialog
			}

		});
	}
	
	//Hover effect for add button
	private class AddHoverListener implements FocusListener{

		@Override
		public void focusGained(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("ADD NEW BOOK")) {
				addBtn.setBackground(new Color(0,130,230));
				addBtn.setForeground(Color.WHITE);

			}			
		}

		@Override
		public void focusLost(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("ADD NEW BOOK")) {
				addBtn.setBackground(Color.WHITE);
				addBtn.setForeground(new Color(0,130,230));
				}			
		}
		
	}
	// cancel button with hover effect
	private class CancelHoverListener implements FocusListener{

		@Override
		public void focusGained(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("CANCEL")) {
				addBtn.setBackground(new Color(0,130,230));
				addBtn.setForeground(Color.WHITE);

			}					
		}

		@Override
		public void focusLost(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("CANCEL")) {
				addBtn.setBackground(Color.WHITE);
				addBtn.setForeground(new Color(0,130,230));
				}						
		}
		
	}
}
