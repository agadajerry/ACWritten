package com.booklib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

public class AboutDevDialog extends JDialog {

	public AboutDevDialog() {

		setSize(new Dimension(500, 330));
		setTitle("About Dev");
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLayout(new BorderLayout());
		getRootPane().setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, new Color(204, 204, 204)));

		// this.setTitle();
		setLocationRelativeTo(null);
		setModal(true);
		setResizable(false);
		JPanel centerPanel = new JPanel();
		centerPanel.setPreferredSize(new Dimension(500,330));
		centerPanel.setBackground(Color.WHITE);
		//centerPanel.setBorder(new EmptyBorder(5,5,5,5));
		ImageIcon meIcon = new ImageIcon(getClass().getResource("/com/booklib/images/jerry.png"));

		JLabel imageLabel = new JLabel("", meIcon, JLabel.CENTER);


		JPanel northP = new JPanel(new GridLayout(2,1));
		northP.setBorder(new EmptyBorder(5,5,5,5));
		northP.add(imageLabel);
		northP.setBackground(Color.WHITE);
		JLabel myName = new JLabel("Engr Jerry Agada",JLabel.CENTER);
		myName.setFont(new Font("David", Font.PLAIN, 12));
		// Tahoma
		myName.setBackground(Color.WHITE);

		northP.add(myName);
		
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setFont(new Font("David", Font.BOLD, 16));
		textArea.setText("Library Managaement System\n\nVersion: 2020-6(1.0.0)\n\n"
				+ "Developed By JerrySoft\nIf you find any error in this desktop app or has any idea to improve this app please"
				+ "write to us jerryitprogramm@gmail.com with subject 'Library Management App'");

		textArea.setLineWrap(true);
		textArea.setTabSize(5);
		textArea.setPreferredSize(new Dimension(370,330));

		centerPanel.add(textArea);
		add(northP,BorderLayout.NORTH);
		add(centerPanel,BorderLayout.CENTER);

	}

}
