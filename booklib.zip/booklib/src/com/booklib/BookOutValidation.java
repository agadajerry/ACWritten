package com.booklib;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class BookOutValidation {

	public static boolean check4Book(String serialNo, String cellName, String bookName) {
		PreparedStatement pps = null;
		boolean status1 = false;
		if (serialNo.equals("") || cellName.equals("")) {
			JOptionPane.showMessageDialog(null, "Pls Enter Book serial number and it shelf cell name...");
		} else {
			try {
				pps = LibDbConnection.getConnection().prepareStatement("SELECT * FROM " + cellName + " Where s_no = ?");

				pps.setString(1, serialNo);
				ResultSet rSet = pps.executeQuery();
				status1 = rSet.next();

			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "Error! No Such Shelf Cell Created...");
			} finally {
				try {
					pps.close();
					LibDbConnection.getConnection().close();

				} catch (SQLException exc) {
					JOptionPane.showMessageDialog(null, "Error! No Such Shelf Cell Created...");

				}
			}
		}
		return status1;

	}

	// remove and update shelf cell quantity

	//
	public static int update(String serialNo, String cellName, int qtty) {
		PreparedStatement pst = null;
		int status = 0;
		try {
			pst = LibDbConnection.getConnection()
					.prepareStatement("UPDATE " + cellName + " SET Quantity = Quantity- ? WHERE s_no = " + serialNo);

			pst.setInt(1, qtty);
			status = pst.executeUpdate();
			System.out.println("Update successful");
		} catch (SQLException ex) {
			System.out.println(ex + " bookOut");
		} finally {
			try {
				pst.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return status;
	}

	public static int bookWaring(String cellName, String serialNo) {

		PreparedStatement ps = null;
		ResultSet rs = null;
		int remainingQuantity = 0;
		try {
			ps = LibDbConnection.getConnection()
					.prepareStatement("Select Quantity From " + cellName + " Where s_no = ?");
			ps.setString(1, serialNo);

			rs = ps.executeQuery();

			if (rs.next()) {
				remainingQuantity = rs.getInt("Quantity");
			}
			if (remainingQuantity <= 0) {
				JOptionPane.showMessageDialog(null, "The Book Specified Is empty in the Shelf, Update Your Content...");
				
			}else {
				System.out.println("Quantity is higher "+remainingQuantity);
			}

		} catch (SQLException ex) {
JOptionPane.showMessageDialog(null, "No Shelf Cell Specified...");
} finally {
			try {
				rs.close();
				ps.close();
				LibDbConnection.getConnection().close();
			} catch (SQLException exc) {
				System.out.println(exc+" jjjrrr");
			}
		}
		return remainingQuantity;

	}

	// remove and update shelf cell quantity

	public static int removeBook(String serialNo, String cellName, int qtty) {
		PreparedStatement pst = null;
		int status = 0;
		try {
			pst = LibDbConnection.getConnection()
					.prepareStatement("UPDATE " + cellName + " SET Quantity = Quantity - ? WHERE s_no = " + serialNo);

			pst.setInt(1, qtty);
			status = pst.executeUpdate();
			pst.close();
			LibDbConnection.getConnection().close();
			System.out.println("Update successful");
		} catch (SQLException ex) {
			System.out.println(ex + " bookOut");
		} finally {
			try {
				LibDbConnection.getConnection().close();

			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return status;
	}

	// book waring in the shelf

}
