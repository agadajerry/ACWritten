package com.booklib;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class DeleteBookDialog extends JDialog {


	private JButton cancelB, okBtn;

	public DeleteBookDialog() {

		setSize(new Dimension(440, 220));

		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setUndecorated(true);
		setLayout(null);
		getRootPane().setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, new Color(0, 118, 255)));

		// this.setTitle();
		setLocationRelativeTo(null);
		setBackground(Color.WHITE);
		setModal(true);

		JLabel detailLabel = new JLabel("Enter Shelf Cell and Book Serial Number you want to delete:", JLabel.CENTER);
		detailLabel.setBounds(30, 30, 350, 30);
		add(detailLabel);

		JTextField inputField = new JTextField(20);
		JTextField inputField2 = new JTextField(20);
		inputField.setBounds(100, 70, 200, 30);
		add(inputField);
		JLabel cellName = new JLabel("Shelf Name:");
		cellName.setBounds(5, 70, 70, 30);
		add(cellName);
		okBtn = new JButton("DELETE BOOK");
		inputField2.setBounds(100, 110, 200, 30);
		add(inputField2);
		JLabel serialNo = new JLabel("SerialNo:");
		serialNo.setBounds(5, 110, 70, 30);
		add(serialNo);
		//
		add(okBtn);
		okBtn.setBounds(60, 150, 130, 30);
		cancelB = new JButton("CANCEL");
		cancelB.setBounds(210, 150, 130, 30);
		cancelB.setForeground(new Color(0,120,230));
		okBtn.setForeground(new Color(0,120,230));
		add(cancelB);
		cancelB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				dispose();// exit this dialog
			}

		});

		okBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				if (inputField.getText().isEmpty()||inputField2.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Enter Shelf Cell Name And Book Serial Number...");
				} else {
					PreparedStatement ps = null;
					try {
						ps = LibDbConnection.getConnection()
								.prepareStatement("DELETE FROM " + inputField.getText().toUpperCase()+" Where s_no= ?");
						ps.setString(1, inputField2.getText());
						ps.execute();
						JOptionPane.showMessageDialog(null, inputField.getText().toUpperCase()+" Book Deleted Successfully");
						inputField.setText(null);

					} catch (SQLException exc) {
						JOptionPane.showMessageDialog(null, "No Such table exist");
					} finally {
						try {
							LibDbConnection.getConnection().close();
						} catch (SQLException ex) {
							ex.printStackTrace();
						}
					}
				}
			}

		});

	}
}
