package eStrong.inventory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class UpdateProductDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField[] inputField = new JTextField[6];
	private JLabel[] inputLabel = new JLabel[6];
	private JButton addBtn, cancelBtn;
	private int qty, prodNo;
	private double selinP, costP;
	private String productName, loction, supplier;

	public UpdateProductDialog(int prodS_no, String productName, int qty, double costP, double sellingP, String loction,
			String suppl) {

		this.qty = qty;
		this.prodNo = prodS_no;
		this.productName = productName;
		this.loction = loction;
		this.costP = costP;
		this.selinP = sellingP;
		this.supplier = suppl;

		//
		Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/e_Strong/images/e_stronglogo.png"));
		setIconImage(icon);
		//
		setSize(new Dimension(710, 500));
		setTitle("Inventory management system");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setResizable(false);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		JPanel northPanel = new JPanel();
		northPanel.setBackground(new Color(255, 255, 255));
		northPanel.setPreferredSize(new Dimension(1200, 100));
		setModal(true);
		
		ImageIcon shopIcon = new ImageIcon(getClass().getResource("/e_Strong/images/e_strong.png"));

		JLabel northLabel = new JLabel("<html><body><div>" + "<h2> SALES INVENTORY MANAGEMENT SYSTEM " + ""
				+ "</h2><hr/><span style=color:red>PRODUCT ADDITION</span></div></body></html>");

		northLabel.setFont(new Font("Aharoni", Font.BOLD, 18));
		JLabel northIconLabel = new JLabel("E-strong|", shopIcon, JLabel.CENTER);

		northPanel.add(northIconLabel);
		northPanel.add(northLabel);
		add(northPanel, BorderLayout.NORTH);
		initUi();
	}

	private void initUi() {
		JPanel centerPanel = new JPanel(new GridLayout(6, 2));
		centerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		//

		//
		for (int i = 0; i < inputLabel.length; i++) {
			inputLabel[i] = new JLabel();
			inputField[i] = new JTextField();

			inputLabel[i].setForeground(new Color(0, 0, 0));
			inputField[i].setBorder(new LineBorder(new Color(63, 63, 63), 2));
			inputLabel[i].setFont(new Font("David", 1, 20));
			inputField[i].setFont(new Font("David", 1, 20));
			centerPanel.add(inputLabel[i]);
			centerPanel.add(inputField[i]);
		}
		//

		inputLabel[0].setText("PRODUCT NAME:");
		inputLabel[1].setText("QUANTITY:");
		inputLabel[2].setText("COST PRICE:");
		inputLabel[3].setText("SELLING PRICE:");
		inputLabel[4].setText("PRODUCT LOCATION:");
		inputLabel[5].setText("PRODUCT SUPPLIER:");
		//
		inputField[0].setText(productName);
		inputField[2].setText("" + costP);
		inputField[3].setText("" + selinP);
		inputField[4].setText(loction);
		inputField[5].setText(supplier);
		add(centerPanel, BorderLayout.CENTER);

		// button add and cancel in south panel

		JPanel southPanel = new JPanel(new GridLayout());
		southPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

		cancelBtn = new JButton("CANCEL");
		addBtn = new JButton("UPDATE TABLE");
		addBtn.setToolTipText("Update new items");
		cancelBtn.setBackground(Color.WHITE);
		cancelBtn.setForeground(new Color(0, 130, 230));
		cancelBtn.setFont(new Font("David", 1, 20));
		cancelBtn.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		cancelBtn.setPreferredSize(new Dimension(150, 40));
		cancelBtn.addFocusListener(new CancelHoverListener());
		addBtn.setPreferredSize(new Dimension(150, 40));
		//
		addBtn.setBackground(Color.WHITE);
		addBtn.setForeground(new Color(0, 130, 230));
		addBtn.setFont(new Font("David", 1, 20));
		addBtn.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		southPanel.add(addBtn);
		southPanel.add(cancelBtn);
		add(southPanel, BorderLayout.SOUTH);
		addBtn.addFocusListener(new AddHoverListener());
		// action listener
		addBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				try {
					String productNam = inputField[0].getText().trim();
					String itemLocation = inputField[4].getText().toUpperCase().trim();

					if (productNam.isEmpty() || itemLocation.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Item's location or Item name fields is empty...");
					}
					int choice = JOptionPane.showConfirmDialog(null,
							"Are you Show You want to update" + " " + inputField[0].getText().toUpperCase());
					if (choice == JOptionPane.YES_OPTION) {
						updateToDb();

					}
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(null, "The values entered are not correct or empty input fields.\n"
							+ " Check your entry" + " and try again...");
				}

			}

		});
		// cancel this dialog box
		cancelBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				dispose();// exit this dialog
			}

		});
		// selectAllProduct();// calling all items method to be inside combo box
	}

	// Hover effect for add button
	private class AddHoverListener implements FocusListener {

		@Override
		public void focusGained(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("ADD NEW BOOK")) {
				addBtn.setBackground(new Color(0, 130, 230));
				addBtn.setForeground(Color.WHITE);

			}
		}

		@Override
		public void focusLost(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("UPDATE")) {
				addBtn.setBackground(Color.WHITE);
				addBtn.setForeground(Color.GRAY);
			}
		}

	}

	// cancel button with hover effect
	private class CancelHoverListener implements FocusListener {

		@Override
		public void focusGained(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("CANCEL")) {
				addBtn.setBackground(new Color(0, 130, 230));
				addBtn.setForeground(Color.WHITE);

			}
		}

		@Override
		public void focusLost(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("CANCEL")) {
				addBtn.setBackground(Color.WHITE);
				addBtn.setForeground(new Color(0, 130, 230));
			}
		}

	}

	private void updateToDb() {

		int qtty = Integer.parseInt(inputField[1].getText().trim());
		double costPrice = Double.parseDouble(inputField[2].getText().trim());
		double sellingPrice = Double.parseDouble(inputField[3].getText().trim());
		String itemLocation = inputField[4].getText().toUpperCase().trim();
		String supplier = inputField[5].getText().toUpperCase().trim();

		PreparedStatement ps = null;
		String qry = "Update allitems_Inventory SET quantity = quantity + ?, costprice=?, sellingprice=?, "
				+ " itemlocation=?, supplier=? where serialNo=?";
//		String qry2 ="update item_purchased SET "

		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(qry);

			ps.setInt(1, qtty);
			ps.setDouble(2, costPrice);
			ps.setDouble(3, sellingPrice);
			ps.setString(4, itemLocation);
			ps.setString(5, supplier);
			ps.setInt(6, prodNo);
			// -------------------------------------------

			ps.executeUpdate();
			for (int i = 0; i < inputField.length; i++) {
				inputField[i].setText(null);
			}
		} catch (SQLException exc) {
			System.out.println("Update error: " + exc);
		}finally {
			try {
				ps.close();
				EstrongDbConnection.getConnection().close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
