package eStrong.inventory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

public class CustomerProductListDialog extends JDialog {

	private static final long serialVersionUID = 1L;
	private JLabel[] addItemLabel = new JLabel[3];
	private JTextField[] inputField = new JTextField[3];
	private DefaultTableCellRenderer cellRenderer, cellRenderer1;
	private JTable table;
	private DefaultTableModel model;
	private JButton updateB;
	private JComboBox<String> cusName_addr;
	private DefaultComboBoxModel<String> cusModel;
	private double totalPaid = 0.0;
	private int sNo = 0;
	private int orderQtty = 0;
	private String productName2 = null;
	private JLabel totalVisitNo;

	public CustomerProductListDialog() {

		this.setTitle("Cust Product purchased List");
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setResizable(false);
		this.setSize(new Dimension(990, 600));
		this.setLocationRelativeTo(null);
		this.setModal(true);
		this.setLayout(new BorderLayout(8, 8));
		initUi();

	}

	private void initUi() {

		JPanel centerPanel = new JPanel();
		JPanel westPanel = new JPanel(new BorderLayout(8, 8));
		add(centerPanel, BorderLayout.CENTER);
		add(westPanel, BorderLayout.WEST);
		// -------------------------------------------------------
		centerPanel.setBackground(Color.WHITE);
		westPanel.setBackground(Color.WHITE);
		// ------------------North panel component-----------------

		JPanel northPanel = new JPanel(new GridLayout(1, 2, 2, 3));
		northPanel.setBackground(Color.WHITE);
		ImageIcon shopIcon = new ImageIcon(getClass().getResource("/e_Strong/images/e_strong.png"));

		JLabel northLabel = new JLabel("<html><body><div>" + "<h2> SALES INVENTORY MANAGEMENT SYSTEM " + ""
				+ "</h2><hr/><span style=color:red>UPDATE UNIT</span></div></body></html>");

		northLabel.setFont(new Font("Aharoni", Font.BOLD, 18));
		JLabel northIconLabel = new JLabel("Product Reversal|", shopIcon, JLabel.CENTER);

		// This panel hold display images
		JPanel dispPanel = new JPanel();
		dispPanel.setBackground(Color.WHITE);
		dispPanel.add(northIconLabel);
		northPanel.add(dispPanel);

		northPanel.add(northLabel);
		add(northPanel, BorderLayout.NORTH);
		// adding component to west panel

		JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		searchPanel.setBackground(Color.WHITE);
		cusModel = new DefaultComboBoxModel<String>();
		cusName_addr = new JComboBox<String>(cusModel);
		cusName_addr.setEditable(true);
		AutoCompleteDecorator.decorate(cusName_addr);
		cusName_addr.addItemListener(new CustSelectionListener());
		cusName_addr.setFont(new Font("David", 1, 16));
		cusName_addr.setForeground(new Color(0, 0, 0));
		cusName_addr.setBorder(new LineBorder(Color.BLACK, 2));
		JLabel searchLabel = new JLabel("CustomerName:");
		searchLabel.setFont(new Font("David", 1, 16));
		searchPanel.add(searchLabel);
		searchPanel.add(cusName_addr);

		//

		westPanel.add(searchPanel, BorderLayout.NORTH);
		// -------------------------------------------------------

		JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));

		//

		// -----------------------------------------------------------------c
		for (int i = 0; i < inputField.length; i++) {
			inputField[i] = new JTextField();
			addItemLabel[i] = new JLabel();
			addItemLabel[i].setHorizontalTextPosition(SwingConstants.RIGHT);
			addItemLabel[i].setForeground(new Color(0, 0, 0));
			addItemLabel[i].setFont(new Font("David", 1, 16));
			inputField[i].setFont(new Font("David", 1, 16));
			inputField[i].setBorder(new LineBorder(Color.BLACK, 1));
			inputField[i].setEditable(false);
			addItemLabel[i].setBorder(new LineBorder(new Color(204, 204, 204), 3));
			inputPanel.add(addItemLabel[i]);
			inputPanel.add(inputField[i]);
		}
		addItemLabel[0].setText("Amount Paid:");
		addItemLabel[1].setText("Product ID:");
		addItemLabel[2].setText("Customer Name:");

		inputPanel.setBackground(Color.WHITE);
		westPanel.add(inputPanel, BorderLayout.CENTER);

		/// -------------------Buttons in west panel--------------------

		totalVisitNo = new JLabel();
		totalVisitNo.setFont(new Font("David", 1, 24));

		//
		updateB = new JButton("Update Quantity");
		updateB.addActionListener(new UpdateReturnedQttyListener());
		updateB.setToolTipText("Enter the amount of unit you want to returned.");

		JPanel southPanelW = new JPanel(new GridLayout(3, 1, 3, 3));
		southPanelW.setBackground(Color.WHITE);
		southPanelW.setBorder(new EmptyBorder(10, 10, 10, 10));
		southPanelW.add(totalVisitNo);
		southPanelW.add(updateB);
		//
		updateB.setForeground(Color.BLACK);
		updateB.setBackground(Color.WHITE);
		updateB.setFont(new Font("David", 1, 18));
		updateB.setPreferredSize(new Dimension(200, 30));
		updateB.setBorder(new LineBorder(new Color(0, 194, 255), 2));
		// -----------------------------------------------

		//
		westPanel.add(southPanelW, BorderLayout.SOUTH);
		/// --------------Center Panel component-----------------------

		// table for inserted data from input field
		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 16));
		table.getTableHeader().setBackground(new Color(0, 194, 255));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(30);
		table.setForeground(Color.BLACK);
		table.setFont(new Font("David", Font.BOLD, 12));
		table.addMouseListener(new RowClickListener());

		String tableColumn[] = { "Id", "Product_Name", "Quantity", "Selling_Price", "Customer/Addr", "Date" };

		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(tableColumn);
		JScrollPane scrollBar3 = new JScrollPane(table);
		scrollBar3.setPreferredSize(new Dimension(600, 400));
		//
		cellRenderer1 = new DefaultTableCellRenderer();
		cellRenderer1.setHorizontalAlignment(JLabel.CENTER);
		table.getColumnModel().getColumn(0).setPreferredWidth(60);
		table.getColumnModel().getColumn(1).setPreferredWidth(320);
		table.getColumnModel().getColumn(4).setPreferredWidth(320);
		table.getColumnModel().getColumn(5).setPreferredWidth(180);
		table.getColumnModel().getColumn(0).setCellRenderer(cellRenderer);
		//

		/*
		 * // JPanel tablePanel = new JPanel(new GridLayout()); //
		 * tablePanel.add(scrollBar3);
		 */
		centerPanel.add(scrollBar3);

		JLabel myName = new JLabel("Designed By: JerrySoft Inc.");
		myName.setFont(new Font("Forte", 1, 18));
		myName.setForeground(Color.BLACK);
		JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		southPanel.setBackground(Color.GRAY);
		southPanel.add(myName);
		add(southPanel, BorderLayout.SOUTH);

		customerNames();// Load customer List from db
		deleteZeroQtty();

	}

	private void customerNames() {

		PreparedStatement ps = null;
		ResultSet rs=null;
		String custName = null;
		try {
			ps = EstrongDbConnection.getConnection()
					.prepareStatement("Select DISTINCT customerName_adress From item_purchased ");

			 rs = ps.executeQuery();
			while (rs.next()) {
				custName = rs.getString("CustomerName_adress");
				// cusModel.removeAllElements();
				cusModel.addElement(custName);

			}

		} catch (SQLException exc) {
			exc.printStackTrace();
		}finally {
			try {
				
				EstrongDbConnection.getConnection().close();
				ps.close();
				rs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	// Listening class combo box for date selection
	private class CustSelectionListener implements ItemListener {

		@Override
		public void itemStateChanged(ItemEvent arg0) {

			if (cusName_addr.getSelectedIndex() != -1) {

				model.setRowCount(0);
				// searchPaitentId();// Load drug List from db
				searchCusomerDateAndName(cusName_addr.getSelectedItem().toString());

				//
				totalPaid = 0.0;
				totalPaid();// Amount paid
				// deleteZeroQtty();// delete less -1 qtty

			} else {
				System.out.println("No date is selected...");

			}
		}

	}

	// search patients drug list
	private void searchCusomerDateAndName(String cusName) {

		int qtty = 0;
		double unitPrice = 0.0;

		PreparedStatement ps = null;
		ResultSet rs = null;
		String orderDate = "";
		int serialNo = 0;
		String custName = null, producName = null;
		try {
			ps = EstrongDbConnection.getConnection()
					.prepareStatement("Select * From item_purchased " + "where " + "customerName_adress=?");

			ps.setString(1, cusName_addr.getSelectedItem().toString());

			rs = ps.executeQuery();
			while (rs.next()) {
				producName = rs.getString("product_name");
				qtty = rs.getInt("quantity");
				unitPrice = rs.getDouble("unitPrice");
				serialNo = rs.getInt("serilaN");
				orderDate = rs.getString("myDate");
				custName = rs.getString("customerName_adress");

				model.addRow(
						new String[] { "" + serialNo, producName, "" + qtty, "" + unitPrice, custName, orderDate });
			}

		} catch (SQLException exc) {
			exc.printStackTrace();
		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();
				rs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	// Total Amount paid on a given date

	private void totalPaid() {
		for (int i = 0; i < table.getRowCount(); i++) {

			int qttySold = Integer.parseInt(table.getValueAt(i, 2) + "");
			double unitPrice = Double.parseDouble(table.getValueAt(i, 3) + "");
			totalPaid += (unitPrice * qttySold);
		}
		NumberFormat numberfmt = NumberFormat.getInstance();

		inputField[0].setText("0.00");
		inputField[0].setText("" + numberfmt.format(totalPaid) + " (Naira)");// display the total amount
																				// on jLabel at south
																				// panel
	}

	// Row click listener class of table

	private class RowClickListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent ev) {

			if (ev.getClickCount() == 1) {
				JTable targetCell = (JTable) ev.getSource();
				int row = targetCell.getSelectedRow();
				// String []text = (String[]) table.getinventoryTableAt(row, col);

				sNo = Integer.parseInt((String) targetCell.getValueAt(row, 0));
				productName2 = ((String) targetCell.getValueAt(row, 1));
				orderQtty = Integer.parseInt((String) targetCell.getValueAt(row, 2));

				inputField[1].setText("" + sNo);
				inputField[2].setText((String) targetCell.getValueAt(row, 4));

			}
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {

		}

		@Override
		public void mouseExited(MouseEvent arg0) {

		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	// update already sold drug quantity back
	private class UpdateReturnedQttyListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			int row = table.getSelectedRow();
			if (row < 0) {

				JOptionPane.showMessageDialog(null, "Click on the product you want to update....");
			} else {
				OrderQuantityUpdate oqu = new OrderQuantityUpdate(sNo, productName2, orderQtty);
				oqu.setVisible(true);

			}
		}

	}

	private void deleteZeroQtty() {
		PreparedStatement ps = null;
		try {
			ps = EstrongDbConnection.getConnection().prepareStatement("Delete from item_purchased where quantity<=?");
			ps.setInt(1, 0);

			ps.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				
				EstrongDbConnection.getConnection().close();
				ps.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}
