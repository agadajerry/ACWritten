package eStrong.inventory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class AddNewItemPanel extends JDialog implements FocusListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel[] addItemLabel = new JLabel[6];
	private JTextField[] inputField = new JTextField[6];
	private JTable table;
	private DefaultTableModel model;
	private JButton saveB, updateB, deleteB, refreshB, subUpdateB;
	private JTextField searchField;
	private DefaultTableCellRenderer cellRenderer;
	private TableRowSorter<DefaultTableModel> sorter;
	private int prodS_no = 0;
	private int productIdIncremnt = 1;
	private int productId = 0;

	public AddNewItemPanel() {
		this.setSize(new Dimension(1300, 650));
		setTitle("Sale Inventory Management System");
		setLocationRelativeTo(null);
		// setResizable(false);
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setModal(true);
		Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/e_Strong/images/e_stronglogo.png"));
		setIconImage(icon);
		//

		add(new ProductSelection(), BorderLayout.NORTH);
		// centerPanel for input and it label
		JPanel mainCenterPanel = new JPanel(new GridLayout(2, 1));
		// mainCenterPanel.setBorder(new EmptyBorder(10,10,10,10));

		JPanel centerPanel = new JPanel(new GridLayout(6, 2, 5, 5));

		centerPanel.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		// centerPanel.setBackground(Color.WHITE);
		JPanel addPanel2Center = new JPanel(new GridLayout(1, 2, 10, 10));
		addPanel2Center.add(centerPanel);
		addPanel2Center.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		//
		JPanel operationPanel = new JPanel();// dummy panel
		ImageIcon cmpIcon = new ImageIcon(getClass().getResource("/e_Strong/images/display.png"));
		JLabel iconLabel = new JLabel("", cmpIcon, JLabel.CENTER);
		// operationPanel.setBackground(Color.GRAY);

		operationPanel.add(iconLabel);
		addPanel2Center.add(operationPanel);//

		for (int i = 0; i < inputField.length; i++) {
			inputField[i] = new JTextField();
			addItemLabel[i] = new JLabel();
			addItemLabel[i].setForeground(new Color(0, 0, 0));
			addItemLabel[i].setFont(new Font("David", 1, 16));
			inputField[i].setFont(new Font("David", 1, 16));
			inputField[i].setBorder(new LineBorder(new Color(204, 204, 204), 3));
			centerPanel.add(addItemLabel[i]);
			centerPanel.add(inputField[i]);
		}
		inputField[1].addFocusListener(new ExistProdListener());

		addItemLabel[0].setText("ITEM'S NAME:");
		addItemLabel[1].setText("QUANTITY:");
		addItemLabel[2].setText("COST PRICE:");
		addItemLabel[3].setText("SELLING PRICE:");
		addItemLabel[4].setText("ITEM'S LOCATION:");
		addItemLabel[5].setText("SUPPLIER NAME:");
		//

		JPanel operationBtnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		operationBtnPanel.setBackground(Color.WHITE);

		//
		subUpdateB = new JButton("REDUCTION UPDATE");
		subUpdateB.setForeground(Color.WHITE);
		subUpdateB.setBackground(new Color(0, 194, 255));
		subUpdateB.setFont(new Font("David", 1, 16));
		subUpdateB.setPreferredSize(new Dimension(250, 40));
		subUpdateB.addFocusListener(this);
		subUpdateB.addActionListener(new ReduceQttyListener());
		operationBtnPanel.add(subUpdateB);
		//
		// search product name
		searchField = new JTextField();
		searchField.setPreferredSize(new Dimension(230, 30));
		searchField.setFont(new Font("David", 1, 16));
		searchField.setBorder(new LineBorder(Color.BLACK));
		searchField.addKeyListener(new ItemSearchListener());
		JLabel searchLabel = new JLabel("Search:");
		searchLabel.setBorder(new LineBorder(Color.GRAY));
		searchLabel.setFont(new Font("David", 1, 18));
		operationBtnPanel.add(searchLabel);
		operationBtnPanel.add(searchField);
		//
		saveB = new JButton("SAVE");
		saveB.addActionListener(new SaveDataListener());
		updateB = new JButton("UPDATE");
		deleteB = new JButton("DELETE");
		updateB.addActionListener(new UpdateListener());

		operationBtnPanel.add(saveB);
		operationBtnPanel.add(updateB);
		operationBtnPanel.add(deleteB);

		//
		//
		saveB.setForeground(Color.WHITE);
		saveB.setBackground(new Color(0, 194, 255));
		saveB.setFont(new Font("David", 1, 16));
		saveB.setPreferredSize(new Dimension(200, 40));
		saveB.addFocusListener(this);
		//
		deleteB.setForeground(Color.WHITE);
		deleteB.setBackground(new Color(0, 194, 255));
		deleteB.setFont(new Font("David", 1, 16));
		deleteB.setPreferredSize(new Dimension(200, 40));
		deleteB.addFocusListener(this);
		deleteB.addActionListener(new DeleteInventoryListener());
		//

		updateB.setPreferredSize(new Dimension(200, 40));
		updateB.setForeground(Color.WHITE);
		updateB.setBackground(new Color(0, 194, 255));
		updateB.setFont(new Font("David", 1, 16));
		updateB.addFocusListener(this);

		//
		refreshB = new JButton("REFRESH");
		refreshB.setForeground(Color.WHITE);
		refreshB.setBackground(new Color(0, 194, 255));
		refreshB.setFont(new Font("David", 1, 16));
		refreshB.setPreferredSize(new Dimension(200, 40));
		refreshB.addActionListener(new RefreshListener());

		JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		southPanel.add(refreshB);
		add(southPanel, BorderLayout.SOUTH);
		//
		mainCenterPanel.add(addPanel2Center);

		// table for inserted data from input field
		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 18));
		table.getTableHeader().setBackground(new Color(0, 194, 255));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(25);
		table.setForeground(Color.BLACK);
		table.setFont(new Font("David", Font.BOLD, 13));

		table.addMouseListener(new TextFieldGetTextListener());

		String tableColumn[] = { "Serial No", "ItemName", "Quantity", "CostPrice", "SellingPrice", "Item'sLocation",
				"Supplier", "Date" };
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(tableColumn);
		JScrollPane scrollBar = new JScrollPane(table);
		scrollBar.setPreferredSize(new Dimension(1150, 200));
		JPanel tablePanel = new JPanel(new BorderLayout());
		tablePanel.add(operationBtnPanel, BorderLayout.NORTH);
		tablePanel.add(scrollBar, BorderLayout.CENTER);

		///

		table.getColumnModel().getColumn(0).setPreferredWidth(4);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(0).setCellRenderer(cellRenderer);
		cellRenderer = new DefaultTableCellRenderer();
		cellRenderer.setHorizontalAlignment(JLabel.CENTER);
		mainCenterPanel.add(tablePanel);
		add(mainCenterPanel, BorderLayout.CENTER);

		getInventoryProduct();// call the inventory product
		lastProductId();// last serial no of product id

	}

	// save data from text field to database
	private class SaveDataListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			try {
				String itemName = inputField[0].getText().toString().trim();
				String itemLocation = inputField[4].getText().toUpperCase().trim();

				if (itemName.isEmpty() || itemLocation.isEmpty()) {
					JOptionPane.showMessageDialog(null, "One or two fields are empty...");
				} else {

					saveToDb();

					// refresh
					model.setRowCount(0);
					getInventoryProduct();
					lastProductId();// last serial no of product id

				}
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(null, "The values entered are not correct or empty input fields.\n"
						+ " Check your entry" + " and try again...");
			}
		}

	}

	//
	private void saveToDb() {
		String itemName = inputField[0].getText().toString().trim().toUpperCase();
		int qtty = Integer.parseInt(inputField[1].getText().trim());
		double costPrice = Double.parseDouble(inputField[2].getText().trim());
		double sellingPrice = Double.parseDouble(inputField[3].getText().trim());
		String itemLocation = inputField[4].getText().trim().toUpperCase();
		String supplier = inputField[5].getText().trim().toUpperCase();
		//

		SimpleDateFormat sDateF = new SimpleDateFormat("yyyy-MM-dd");
		Date nDate = new Date();
		String todayDate = sDateF.format(nDate.getTime());
		//
		PreparedStatement ps = null;
		String qry = " INSERT INTO allitems_Inventory VALUES (?,?,?,?,?,?,?,?,?)";
		try {

			ps = EstrongDbConnection.getConnection().prepareStatement(qry);

			ps.setInt(1, productIdIncremnt);
			ps.setInt(2, productId);
			ps.setString(3, itemName);
			ps.setInt(4, qtty);
			ps.setDouble(5, costPrice);
			ps.setDouble(6, sellingPrice);
			ps.setString(7, itemLocation);
			ps.setString(8, supplier);
			ps.setString(9, todayDate);

			ps.executeUpdate();

			for (int i = 0; i < inputField.length; i++) {
				inputField[i].setText(null);
			}

		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null,
					"Import product from product list first " + "before taking the inventory");
			ex.printStackTrace();
		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	// Update class listener
	private class UpdateListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (table.getSelectedRow() == -1) {
				JOptionPane.showMessageDialog(null,
						"Product Name / ID is unknown. Select row of interest from the table and hit update...");
			} else {
				int i = table.getSelectedRow();
				prodS_no = Integer.parseInt("" + model.getValueAt(i, 0));
				String productName = (String) model.getValueAt(i, 1);
				int qty = Integer.parseInt("" + model.getValueAt(i, 2));
				double costP = Double.parseDouble((String) model.getValueAt(i, 3));
				double sellingP = Double.parseDouble((String) model.getValueAt(i, 4));
				String loction = (String) model.getValueAt(i, 5);
				String suppl = (String) model.getValueAt(i, 6);
				// String dateTim = (String) model.getValueAt(i, 7);

				UpdateProductDialog upd = new UpdateProductDialog(prodS_no, productName, qty, costP, sellingP, loction,
						suppl);
				upd.setVisible(true);
			}
		}
	}

	// setting back jtable text to text field
	private class TextFieldGetTextListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent arg0) {
			int i = table.getSelectedRow();
			prodS_no = Integer.parseInt("" + model.getValueAt(i, 0));
			saveB.setEnabled(false);

		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	@Override
	public void focusGained(FocusEvent ev) {
		JButton btn = (JButton) ev.getSource();
		if (btn.getActionCommand().equals("SAVE")) {
			saveB.setBackground(Color.WHITE);
			saveB.setForeground(new Color(0, 194, 255));
		}
		if (btn.getActionCommand().equals("UPDATE")) {
			updateB.setBackground(Color.WHITE);
			updateB.setForeground(new Color(0, 194, 255));
		}
		if (btn.getActionCommand().equals("DELETE")) {
			deleteB.setBackground(Color.WHITE);
			deleteB.setForeground(new Color(0, 194, 255));
		}
		if (btn.getActionCommand().equals("REDUCTION UPDATE")) {
			deleteB.setBackground(Color.WHITE);
			deleteB.setForeground(new Color(0, 194, 255));
		}
	}

	@Override
	public void focusLost(FocusEvent ev) {
		JButton btn = (JButton) ev.getSource();
		if (btn.getActionCommand().equals("SAVE")) {
			saveB.setBackground(new Color(0, 194, 255));
			saveB.setForeground(Color.WHITE);
		}
		if (btn.getActionCommand().equals("UPDATE PRODUCT")) {
			updateB.setBackground(new Color(0, 194, 255));
			updateB.setForeground(Color.WHITE);
		}
		if (btn.getActionCommand().equals("DELETE ROW")) {
			deleteB.setBackground(new Color(0, 194, 255));
			deleteB.setForeground(Color.WHITE);
		}
		if (btn.getActionCommand().equals("REDUCTION UPDATE")) {
			deleteB.setBackground(new Color(0, 194, 255));
			deleteB.setForeground(Color.WHITE);
		}
	}

	// clear table
	private class DeleteInventoryListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (table.getSelectedRow() == -1) {
				JOptionPane.showMessageDialog(null,
						"Product Name / ID is unknown. Select row of interest from the table and hit delete...");
			} else {
				int choice = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to delete the selected Product from the inventory?");
				if (choice == JOptionPane.YES_OPTION) {
					// remove table data first

					deleteinventoryProductDetails();
					//
					model.setRowCount(0);
					getInventoryProduct();// refresh product table again
					//

					saveB.setEnabled(true);//

				}
			}
		}
	}

	private void deleteinventoryProductDetails() {
		PreparedStatement ps = null;
		try {
			ps = EstrongDbConnection.getConnection()
					.prepareStatement("Delete From" + " allitems_Inventory where serialNo =?");
			ps.setInt(1, prodS_no);
			ps.executeUpdate();
		} catch (SQLException ex) {
			System.out.println("" + ex);
		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	// sorter focus listener class
	private void sorterProduct(String qry) {
		sorter = new TableRowSorter<DefaultTableModel>(model);
		table.setRowSorter(sorter);
		sorter.setRowFilter(RowFilter.regexFilter(qry));
	}
	//

	// keylistener for search product
	private class ItemSearchListener implements KeyListener {

		@Override
		public void keyPressed(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void keyReleased(KeyEvent arg0) {
			sorterProduct(searchField.getText().toString().toUpperCase());

		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	/*
	 * this method retrive inventory product from the table
	 * 
	 */
	private void getInventoryProduct() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		int sNo = 0;
		String prdName = null;
		String loctn = null, dateTime = null, supplier = null;
		int qtty = 0;
		double costP = 0, sellingP = 0;
		try {

			String qry = "Select * from allitems_Inventory";
			ps = EstrongDbConnection.getConnection().prepareStatement(qry);
			rs = ps.executeQuery();
			while (rs.next()) {
				sNo = rs.getInt("serialNo");
				prdName = rs.getString("itemname");
				qtty = rs.getInt("Quantity");
				loctn = rs.getString("ITEMLocation");
				dateTime = rs.getString("dateNow");
				supplier = rs.getString("supplier");
				costP = rs.getDouble("costprice");
				sellingP = rs.getDouble("sellingprice");
				//
				model.addRow(new String[] { "" + sNo, prdName, "" + qtty, "" + costP, "" + sellingP, loctn, supplier,
						dateTime });
				//
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();
				rs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	// refresh table after update or deletion is made on the table
	private class RefreshListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			model.setRowCount(0);
			getInventoryProduct(); // call inventory table data
			saveB.setEnabled(true);
		}

	}

	// last entered id
	private void lastProductId() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = EstrongDbConnection.getConnection()
					.prepareStatement("Select serialNo from allitems_Inventory " + "ORDER BY serialNo DESC LIMIT 1");

			rs = ps.executeQuery();

			if (rs.next()) {
				int idNo = rs.getInt("serialNo");
				productIdIncremnt = (idNo + 1);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();
				rs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public class ProductSelection extends JPanel {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private JTextField searchField;
		private DefaultTableCellRenderer cellRenderer;
		private TableRowSorter<DefaultTableModel> sorter;
		private JTable table;
		private DefaultTableModel model;

		public ProductSelection() {

			// setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

			setBackground(Color.WHITE);
			JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
			northPanel.setBackground(Color.WHITE);

			//

			JPanel southPanel2 = new JPanel();
			southPanel2.setLayout(new FlowLayout(FlowLayout.LEFT));

			southPanel2.setBackground(Color.WHITE);

			searchField = new JTextField();
			searchField.setPreferredSize(new Dimension(250, 30));
			searchField.setFont(new Font("David", 1, 16));
			searchField.setBorder(new LineBorder(Color.GRAY));
			searchField.addKeyListener(new ItemSearchListener());
			JLabel searchLabel = new JLabel("Search:");
			searchLabel.setFont(new Font("David", 1, 16));
			southPanel2.add(searchLabel);
			southPanel2.add(searchField);
			JLabel northLabel = new JLabel("<html><h1>  INVENTORY OF PRODUCTS</h1></html>");
			southPanel2.add(new JLabel(""));

			southPanel2.add(northLabel);

			// adding components to panel31

			//

			String tableColumn[] = { "S/No", "ItemName", "Vendor", "CATEGORY", "Item's Location", "Date" };
			table = new JTable();
			table.getTableHeader().setFont(new Font("David", Font.BOLD, 18));
			table.getTableHeader().setBackground(new Color(0, 194, 255));
			table.getTableHeader().setForeground(Color.WHITE);
			table.getTableHeader().setOpaque(false);
			table.setRowHeight(25);
			table.setForeground(Color.BLACK);
			table.setFont(new Font("David", Font.BOLD, 12));
			table.addMouseListener(new RowClickedListener());
			model = (DefaultTableModel) table.getModel();
			model.setColumnIdentifiers(tableColumn);

			JScrollPane tableScroll = new JScrollPane(table);
			JPanel tableScrollPanel = new JPanel(new BorderLayout());
			tableScrollPanel.setPreferredSize(new Dimension(1200, 100));

			table.getColumnModel().getColumn(0).setPreferredWidth(4);
			table.getColumnModel().getColumn(1).setPreferredWidth(320);
			table.getColumnModel().getColumn(0).setCellRenderer(cellRenderer);
			cellRenderer = new DefaultTableCellRenderer();
			cellRenderer.setHorizontalAlignment(JLabel.CENTER);
			// tableScrollPanel.setBorder(new EmptyBorder(5,5,5,5));
			tableScrollPanel.add(tableScroll, BorderLayout.CENTER);
			//
			JPanel southPanel = new JPanel(new BorderLayout());
			southPanel.setBorder(new LineBorder(Color.GRAY, 2));
			southPanel.setBackground(Color.LIGHT_GRAY);
			southPanel.add(tableScrollPanel, BorderLayout.CENTER);
			southPanel.add(southPanel2, BorderLayout.NORTH);
			add(southPanel, BorderLayout.CENTER);
			getProductName();// get product list
		}

		/*
		 * this method retrive product record from the table
		 * 
		 */
		private void getProductName() {
			int sNo = 0;
			PreparedStatement ps = null;
			ResultSet rs = null;
			String prdName = null;
			String vendorN = null, loctn = null, dateTime = null, category = null;
			try {

				String qry = "Select * from Product_record";
				ps = EstrongDbConnection.getConnection().prepareStatement(qry);
				rs = ps.executeQuery();
				while (rs.next()) {
					sNo = rs.getInt("serialNo");
					prdName = rs.getString("productName");
					vendorN = rs.getString("VENDOR");
					loctn = rs.getString("ITEMLocation");
					dateTime = rs.getString("createDate");
					category = rs.getString("Category");
					//
					model.addRow(new String[] { "" + sNo, prdName, vendorN, category, loctn, dateTime });
					//
				}

			} catch (SQLException ex) {
				ex.printStackTrace();
			} finally {
				try {

					EstrongDbConnection.getConnection().close();
					ps.close();
					rs.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}

		// sorter focus listener class
		private void sorterProduct(String qry) {
			sorter = new TableRowSorter<DefaultTableModel>(model);
			table.setRowSorter(sorter);
			sorter.setRowFilter(RowFilter.regexFilter(qry));
		}

		// key listener class
		private class ItemSearchListener implements KeyListener {

			@Override
			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent arg0) {

				sorterProduct(searchField.getText().toString().toUpperCase());

			}

			@Override
			public void keyTyped(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

		}

		// Table row click, collecting the selected row data
		private class RowClickedListener implements MouseListener {

			@Override
			public void mouseClicked(MouseEvent ev) {

				if (ev.getClickCount() == 1) {
					JTable targetCell = (JTable) ev.getSource();
					int row = targetCell.getSelectedRow();

					productId = Integer.parseInt((String) targetCell.getValueAt(row, 0));
					String productDescription = (String) targetCell.getValueAt(row, 1);
					String vendorNa = (String) targetCell.getValueAt(row, 2);
					String dCat = (String) targetCell.getValueAt(row, 3);
					String loctn = (String) targetCell.getValueAt(row, 4);

					inputField[0].setText(productDescription);// product description
					inputField[4].setText(loctn);// product location

				}
			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

		}
	}

	private class ExistProdListener implements FocusListener {

		@Override
		public void focusGained(FocusEvent arg0) {

			productIdNoSearch();

		}

		@Override
		public void focusLost(FocusEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	private void productIdNoSearch() {

		String itemName = null;
		try {
			PreparedStatement ps = EstrongDbConnection.getConnection()
					.prepareStatement("" + "Select itemname from allitems_Inventory  WHERE itemname=?");
			ps.setString(1, inputField[0].getText());
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				itemName = rs.getString("itemname");
			}

			if (itemName != null && itemName.equals(inputField[0].getText().toString())) {

				JOptionPane.showMessageDialog(null,
						"You cannot add this product to" + " the inventory \n" + " because is already in the table.");

				inputField[0].setText(null);
				inputField[1].setText(null);
			}
		} catch (SQLException ex) {
			System.out.println("Error in focus gain for added items");
		}
	}

	// reduction update listener
	private class ReduceQttyListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (table.getSelectedRow() == -1) {
				JOptionPane.showMessageDialog(null,
						" Select the row of interest you want to reduce it quantity...");
			} else {
				int i = table.getSelectedRow();
				prodS_no = Integer.parseInt("" + model.getValueAt(i, 0));
				String productName = (String) model.getValueAt(i, 1);
				int qty = Integer.parseInt("" + model.getValueAt(i, 2));
				double costP = Double.parseDouble((String) model.getValueAt(i, 3));
				double sellingP = Double.parseDouble((String) model.getValueAt(i, 4));
				String loction = (String) model.getValueAt(i, 5);
				String suppl = (String) model.getValueAt(i, 6);
				// String dateTim = (String) model.getValueAt(i, 7);

				UpdateProductDialog2 upd = new UpdateProductDialog2(prodS_no, productName, qty, costP, sellingP, loction,
						suppl);
				upd.setVisible(true);
			}
		}

	}
}
