package eStrong.inventory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Locale;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

import com.toedter.calendar.JDateChooser;

public class ProductRecord extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel[] addItemLabel = new JLabel[3];
	private JTextField[] inputField = new JTextField[3];
	private JTable table;
	private DefaultTableModel model;
	private JButton saveB, refreshB, deleteB;
	private JDateChooser createDate;
	private JTextField searchField;
	private DefaultTableCellRenderer cellRenderer;
	private TableRowSorter<DefaultTableModel> sorter;
	private JLabel iconLabel;
	private JComboBox<String> catBox;
	private DefaultComboBoxModel<String> catModel;
	private int sNo = 0;
	private int productId = 1;

	public ProductRecord() {
		setLayout(new BorderLayout());
		setBorder(new LineBorder(Color.BLACK, 2));

		JPanel northPanel = new JPanel();
		northPanel.setPreferredSize(new Dimension(700, 40));
		northPanel.setBackground(Color.GRAY);
		JLabel descLabel = new JLabel(" PRODUCT RECORDS", JLabel.CENTER);
		descLabel.setFont(new Font("david", 1, 18));
		descLabel.setForeground(Color.WHITE);
		northPanel.add(descLabel);
		add(northPanel, BorderLayout.NORTH);
		// centerPanel for input and it label
		JPanel mainCenterPanel = new JPanel(new GridLayout(2, 1));
		// mainCenterPanel.setBorder(new EmptyBorder(10,10,10,10));

		JPanel centerPanel = new JPanel(new GridLayout(5, 2, 5, 5));

		centerPanel.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		// centerPanel.setBackground(Color.WHITE);
		JPanel addPanel2Center = new JPanel(new GridLayout(1, 2, 10, 10));
		addPanel2Center.add(centerPanel);
		addPanel2Center.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		//
		JPanel operationPanel = new JPanel();// dummy panel
		ImageIcon cmpIcon = new ImageIcon(getClass().getResource("/e_Strong/images/cmp1.png"));
		iconLabel = new JLabel("", cmpIcon, JLabel.CENTER);
		// operationPanel.setBackground(Color.GRAY);

		operationPanel.add(iconLabel);
		addPanel2Center.add(operationPanel);//

		for (int i = 0; i < inputField.length; i++) {
			inputField[i] = new JTextField();
			addItemLabel[i] = new JLabel();
			addItemLabel[i].setForeground(new Color(0, 0, 0));
			addItemLabel[i].setFont(new Font("David", 1, 16));
			inputField[i].setFont(new Font("David", 1, 16));
			inputField[i].setBorder(new LineBorder(new Color(204, 204, 204), 3));
			centerPanel.add(addItemLabel[i]);
			centerPanel.add(inputField[i]);
		}

		addItemLabel[0].setText("PRODUCT NAME:");
		addItemLabel[1].setText("VENDOR'S NAME:");
		addItemLabel[2].setText(" ITEM'S LOCATION:");

		//

		catModel = new DefaultComboBoxModel<String>();
		catBox = new JComboBox<String>(catModel);
		JLabel catLabel = new JLabel("CATEGORY:");
		catLabel.setFont(new Font("David", 1, 16));
		catBox.setEditable(true);
		AutoCompleteDecorator.decorate(catBox);
		catBox.setFont(new Font("David", 1, 16));
		centerPanel.add(catLabel);
		centerPanel.add(catBox);
		//
		createDate = new JDateChooser();
		createDate.setLocale(Locale.UK);
		JLabel dateLabel = new JLabel(" DATE:");

		dateLabel.setFont(new Font("David", 1, 16));
		centerPanel.add(dateLabel);
		centerPanel.add(createDate);
		//

		// operational button, save clear buttons
		JPanel operationBtnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		operationBtnPanel.setBackground(Color.WHITE);

		// search product name
		searchField = new JTextField();
		searchField.setPreferredSize(new Dimension(250, 30));
		searchField.setFont(new Font("David", 1, 16));
		searchField.setBorder(new LineBorder(Color.BLACK));
		searchField.addKeyListener(new ItemSearchListener());
		JLabel searchLabel = new JLabel("Search:");
		searchLabel.setBorder(new LineBorder(Color.GRAY));
		searchLabel.setFont(new Font("David", 1, 18));
		operationBtnPanel.add(searchLabel);
		operationBtnPanel.add(searchField);
		//

		saveB = new JButton("SAVE");
		saveB.addActionListener(new SaveDataListener());
		refreshB = new JButton("REFRESH");
		deleteB = new JButton("DELETE");
		refreshB.addActionListener(new RefreshListener());

		operationBtnPanel.add(saveB);
		operationBtnPanel.add(refreshB);
		operationBtnPanel.add(deleteB);

		//
		//
		saveB.setForeground(Color.WHITE);
		saveB.setBackground(new Color(0, 194, 255));
		saveB.setFont(new Font("David", 1, 16));
		saveB.setPreferredSize(new Dimension(150, 40));
		//
		deleteB.setForeground(Color.WHITE);
		deleteB.setBackground(new Color(0, 194, 255));
		deleteB.setFont(new Font("David", 1, 16));
		deleteB.setPreferredSize(new Dimension(200, 40));
		deleteB.addActionListener(new DeleteRecord());
		//

		refreshB.setPreferredSize(new Dimension(200, 40));
		refreshB.setForeground(Color.WHITE);
		refreshB.setBackground(new Color(0, 194, 255));
		refreshB.setFont(new Font("David", 1, 16));

		//
		mainCenterPanel.add(addPanel2Center);

		// table for inserted data from input field
		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 18));
		table.getTableHeader().setBackground(new Color(0, 194, 255));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(25);
		table.setForeground(Color.BLACK);
		table.setFont(new Font("David", Font.BOLD, 12));
		// table.addMouseListener(new RowClickedListener());
		model = (DefaultTableModel) table.getModel();
		table.addMouseListener(new TextFieldGetTextListener());

		String tableColumn[] = { "S/No", "ItemName", "Vendor", "CATEGORY", "Item's Location", "Date" };
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(tableColumn);
		JScrollPane scrollBar = new JScrollPane(table);
		scrollBar.setPreferredSize(new Dimension(1100, 200));

		//
		table.getColumnModel().getColumn(0).setPreferredWidth(4);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(0).setCellRenderer(cellRenderer);
		cellRenderer = new DefaultTableCellRenderer();
		cellRenderer.setHorizontalAlignment(JLabel.CENTER);
		//

		JPanel tablePanel = new JPanel(new FlowLayout());
		tablePanel.add(operationBtnPanel);
		tablePanel.add(scrollBar);
		mainCenterPanel.add(tablePanel);
		add(mainCenterPanel, BorderLayout.CENTER);
		//
		getProductName();// refresh table immediately need product is inserted
		categoryList();// product category
		lastProductId();// last product id

	}

	// save data from text field to database
	private class SaveDataListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			try {
				String itemName = inputField[0].getText().toString().trim();
				String vendorName = inputField[1].getText().trim().toUpperCase();
				String itemLocation = inputField[2].getText().trim().toUpperCase();

				if (itemName.isEmpty() || itemLocation.isEmpty() || vendorName.isEmpty() || createDate.getDate() == null
						|| catBox.getSelectedItem() == null) {
					JOptionPane.showMessageDialog(null, " One or all Fields are empty...");
				} else {
					saveToDb();
					model.setRowCount(0);
					getProductName();// refresh table immediately need product is inserted

					catModel.removeAllElements();
					categoryList();// product category
					lastProductId();// last product id

				}
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(null, "The values entered are not correct or empty input fields.\n"
						+ " Check your entry" + " and try again...");
			}
		}

	}

	// save to db
	private void saveToDb() {
		String itemName = inputField[0].getText().toString().trim().toUpperCase();
		String vendorName = inputField[1].getText().trim().toUpperCase();
		String itemLocation = inputField[2].getText().trim().toUpperCase();

		SimpleDateFormat sDateF = new SimpleDateFormat("yyyy-MM-dd");
		String todayDate = sDateF.format(createDate.getDate());
		//

		PreparedStatement ps = null;
		String qry = " INSERT INTO Product_record VALUES (?,?,?,?,?,?)";
		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(qry);

			ps.setInt(1, productId);
			ps.setString(2, itemName);
			ps.setString(3, vendorName);
			ps.setString(4, itemLocation);
			ps.setString(5, catBox.getSelectedItem().toString().toUpperCase());
			ps.setString(6, todayDate);

			ps.execute();

			for (int i = 0; i < inputField.length; i++) {
				inputField[i].setText(null);
			}

		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null, ex.getMessage());
			ex.printStackTrace();
		} finally {
			try {
				EstrongDbConnection.getConnection().close();
				ps.close();
			} catch (SQLException exc) {
				System.out.println("Data insertion error 2 " + exc);

			}
		}

	}

	// Update class listener
	private class RefreshListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			model.setRowCount(0);
			getProductName();// refresh product table again
			saveB.setEnabled(true);

		}
	}

	// setting back jtable text to text field
	private class TextFieldGetTextListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent arg0) {
			int i = table.getSelectedRow();
			sNo = Integer.parseInt((String) model.getValueAt(i, 0));
			saveB.setEnabled(false);

		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	// clear table
	private class DeleteRecord implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (table.getSelectedRow() == -1) {
				JOptionPane.showMessageDialog(null,
						"Product Name / ID is unknown. Select Product from the table and hit delete...");
			} else {
				int choice = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to delete the selected Product ?");
				if (choice == JOptionPane.YES_OPTION) {
					// remove table data first

					deleteProductDetails();
					//
					model.setRowCount(0);
					getProductName();// refresh product table again
					//

					saveB.setEnabled(true);//

				}
			}
		}

		private void deleteProductDetails() {
			PreparedStatement ps = null;
			try {
				ps = EstrongDbConnection.getConnection()
						.prepareStatement("Delete From" + " Product_record where serialNo =?");
				ps.setInt(1, sNo);
				ps.executeUpdate();
			} catch (SQLException ex) {
				System.out.println("" + ex);
				try {
					EstrongDbConnection.getConnection().close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					try {

						EstrongDbConnection.getConnection().close();
						ps.close();

					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

			}
		}
	}

	/*
	 * this method retrive product record from the table
	 * 
	 */
	private void getProductName() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		int sNo = 0;
		String prdName = null;
		String vendorN = null, loctn = null, dateTime = null, category = null;
		try {

			String qry = "Select * from Product_record";
			ps = EstrongDbConnection.getConnection().prepareStatement(qry);
			rs = ps.executeQuery();
			while (rs.next()) {
				sNo = rs.getInt("serialNo");
				prdName = rs.getString("productName");
				vendorN = rs.getString("VENDOR");
				loctn = rs.getString("ITEMLocation");
				dateTime = rs.getString("createDate");
				category = rs.getString("Category");
				//
				model.addRow(new String[] { "" + sNo, prdName, vendorN, category, loctn, dateTime });
				//
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();
				rs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	// sorter focus listener class
	private void sorterProduct(String qry) {
		sorter = new TableRowSorter<DefaultTableModel>(model);
		table.setRowSorter(sorter);
		sorter.setRowFilter(RowFilter.regexFilter(qry));
	}

	// search for product
	private class ItemSearchListener implements KeyListener {

		@Override
		public void keyPressed(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void keyReleased(KeyEvent arg0) {
			sorterProduct(searchField.getText().toString().toUpperCase());
		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	// Select category of product from product list and set it on combo
	private void categoryList() {
		String categori = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = EstrongDbConnection.getConnection()
					.prepareStatement("" + "Select DISTINCT Category from product_record");

			rs = ps.executeQuery();
			while (rs.next()) {
				categori = rs.getString("Category");
				catModel.addElement(categori);
			}
		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();
				rs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	// last entered id
	private void lastProductId() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = EstrongDbConnection.getConnection()
					.prepareStatement("Select serialNo from Product_record ORDER BY serialNo DESC LIMIT 1");

			rs = ps.executeQuery();

			if (rs.next()) {
				int idNo = rs.getInt("serialNo");
				productId = (idNo + 1);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();
				rs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}
