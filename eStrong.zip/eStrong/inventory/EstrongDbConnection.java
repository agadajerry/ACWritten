package eStrong.inventory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class EstrongDbConnection {

	public static Connection getConnection() {
		Connection dbConn = null;
		try {

			String dbURL = "jdbc:sqlite:C:\\E_Strong_SellFolder\\InvoiceFiles\\eStrongIctDatabase.db";
			
			dbConn = DriverManager.getConnection(dbURL);

		} catch (SQLException ex) {
			System.out.println(ex.getMessage() + " DB connection");
			ex.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error in database connection. Check your connection..");

		}
		return dbConn;
	}

}
