package eStrong.inventory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

import net.proteanit.sql.DbUtils;

public class AllCustomerList extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTable table;
	private JLabel totalLabel;
	private JComboBox<String> dateCombo;
	private JCheckBox allListCheck;
	
	public static DefaultComboBoxModel<String> dateComboModel = new DefaultComboBoxModel<String>();

	public AllCustomerList() {
		setSize(new Dimension(700, 500));
		setTitle("Customer's List");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setResizable(false);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		JPanel northPanel = new JPanel();
		northPanel.setBackground(new Color(255, 255, 255));
		ImageIcon northBgIcon = new ImageIcon(getClass().getResource("/e_Strong/images/cus_info.png"));
		JLabel northLabel = new JLabel("", northBgIcon, JLabel.CENTER);
		setModal(true);
		northPanel.add(northLabel);
		northPanel.add(new JLabel("All Customer list"));
		add(northPanel, BorderLayout.NORTH);
		initUi();
		allPurchaseDate();// all date of purchase made by customer
	}

	private void initUi() {
		// combobox with sales date

		dateComboModel = new DefaultComboBoxModel<String>();
		dateCombo = new JComboBox<String>(dateComboModel);
		dateCombo.setEditable(true);
		dateCombo.setSize(150, 40);
		AutoCompleteDecorator.decorate(dateCombo);
		dateCombo.addItemListener(new DateSelectionListener());
		table = new JTable();
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 24));
		table.getTableHeader().setBackground(new Color(0, 130, 230));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(30);
		table.setForeground(Color.RED);
		table.setFont(new Font("David", Font.BOLD, 16));

		JScrollPane scrollBar = new JScrollPane(table);
		scrollBar.setPreferredSize(new Dimension(650, 200));
		//

		JPanel tablePanel = new JPanel(new FlowLayout());
		tablePanel.add(dateCombo);
		allListCheck = new JCheckBox("SHOW ALL");
		allListCheck.addItemListener(new ItemSelectionListener());
		tablePanel.add(allListCheck);
		tablePanel.add(scrollBar);
		add(tablePanel, BorderLayout.CENTER);

		totalLabel = new JLabel("", JLabel.CENTER);
		totalLabel.setForeground(Color.RED);
		totalLabel.setFont(new Font("David", 1, 22));
		JPanel totalPanel = new JPanel();
		totalPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		totalPanel.add(totalLabel);
		add(totalPanel, BorderLayout.SOUTH);
	}

	//
	private void allCustomers() {

		PreparedStatement ps = null;
		ResultSet rs = null;
		String qry = "Select * From customerlist" + " where date = ?";

		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(qry);
			ps.setString(1, (String) dateCombo.getSelectedItem());
			rs = ps.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));

		} catch (SQLException ex) {
			System.out.println(ex);
		}finally {
			try {
				
				EstrongDbConnection.getConnection().close();
				ps.close();
				rs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	// date combobox class
	private class DateSelectionListener implements ItemListener {

		@Override
		public void itemStateChanged(ItemEvent arg0) {

			if (dateCombo.getSelectedIndex() != -1) {
				allCustomers();
			}
		}

	}

	//

	private void allPurchaseDate() {
		String dateTime = "";
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;
		String shelName = "Select DISTINCT date from customerlist order By date DESC";

		try {
			ps1 = EstrongDbConnection.getConnection().prepareStatement(shelName);
			rs1 = ps1.executeQuery();
			while (rs1.next()) {
				dateTime = rs1.getString("date");
				dateComboModel.addElement(dateTime);

			}
		} catch (SQLException ex) {
			System.out.println("combobox items error\n" + ex);
		}finally {
			try {
				
				EstrongDbConnection.getConnection().close();
				ps1.close();
				rs1.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}

	// show all customer list
	private void showAllCustomers() {

		PreparedStatement ps1 = null;
		ResultSet rs1 = null;
		String allList = "Select * from customerlist order By date DESC";

		try {
			ps1 = EstrongDbConnection.getConnection().prepareStatement(allList);
			rs1 = ps1.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs1));
		} catch (SQLException exc) {
			System.out.println("All Customers table error \n" + exc);
		}finally {
			try {
				
				EstrongDbConnection.getConnection().close();
				ps1.close();
				rs1.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}
	//check box listener class
	private class ItemSelectionListener implements ItemListener{

		@Override
		public void itemStateChanged(ItemEvent ev) {
			int state = ev.getStateChange();
			if(state== ItemEvent.SELECTED) {
				showAllCustomers();//call all customer list method
			}
		}
		
	}
}
