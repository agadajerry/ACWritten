package eStrong.inventory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class AdminRegistrationDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel userNameLabel, passwordLabel, preNameLabel, prePassLabel;
	private JButton regB, exitB;
	private JTextField userField, preUserField;
	private JPasswordField passField, prePassField;
	private JLabel errorLabel, errorLabel1;
	private int userNo;
	private String userName = null, password = null;

	public AdminRegistrationDialog(int userNo2, String password2, String userName2) {

		setSize(new Dimension(400, 400));

		this.userNo = userNo2;
		this.userName = userName2;
		this.password = password2;
		setLayout(new BorderLayout());
		this.setModal(true);

		this.setLocationRelativeTo(null);
		setBackground(Color.LIGHT_GRAY);
		this.setResizable(false);

		Image iconImage = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/e_Strong/images/e_strong.png"));
		setIconImage(iconImage);
		initialiseUi();

	}

	private void initialiseUi() {
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(null);
		centerPanel.setBounds(10, 10, 390, 290);
		centerPanel.setBackground(Color.LIGHT_GRAY);

		centerPanel.setBackground(Color.WHITE);

		// admin registration dialog
		JLabel adLabel = new JLabel("<html><h2 style= color:rgb(0,130,230);>Admin Registration</h2></html>");
		adLabel.setBounds(105, 8, 200, 30);
		centerPanel.add(adLabel);
		///

		preNameLabel = new JLabel("Old UserName:");
		preNameLabel.setFont(new Font("David", 1, 16));
		preUserField = new JTextField();
		preNameLabel.setBounds(20, 45, 120, 40);
		preUserField.setBounds(140, 45, 200, 40);
		preUserField.setFont(new Font("David", 1, 16));
		preUserField.setBorder(new LineBorder(Color.BLACK, 2));
		centerPanel.add(preNameLabel);
		centerPanel.add(preUserField);
		//

		prePassLabel = new JLabel("Old Password:");
		prePassLabel.setFont(new Font("David", 1, 16));
		prePassField = new JPasswordField();
		prePassLabel.setLabelFor(prePassField);
		prePassLabel.setBounds(20, 100, 120, 16);
		prePassField.setBounds(140, 100, 200, 40);
		prePassField.setBorder(new LineBorder(Color.BLACK, 2));
		prePassField.setFont(new Font("David", 1, 30));
		centerPanel.add(prePassLabel);
		centerPanel.add(prePassField);
		//

		userNameLabel = new JLabel("User Name:");
		userNameLabel.setFont(new Font("David", 1, 16));
		userField = new JTextField();
		userNameLabel.setBounds(20, 150, 120, 40);
		userField.setBounds(140, 150, 200, 40);
		userField.setFont(new Font("David", 1, 16));
		userField.setBorder(new LineBorder(Color.BLACK, 2));
		centerPanel.add(userNameLabel);
		centerPanel.add(userField);
		//
		passwordLabel = new JLabel("Password:");
		passwordLabel.setFont(new Font("David", 1, 16));
		passField = new JPasswordField();
		passwordLabel.setLabelFor(passField);
		passwordLabel.setBounds(20, 195, 120, 16);
		passField.setBounds(140, 195, 200, 40);
		passField.setBorder(new LineBorder(Color.BLACK, 2));
		passField.setFont(new Font("David", 1, 30));
		centerPanel.add(passwordLabel);
		centerPanel.add(passField);
		//
		regB = new JButton("Register");
		regB.setBounds(140, 240, 200, 40);

		exitB = new JButton("Exit");
		exitB.setBounds(140, 285, 200, 40);

		regB.setForeground(Color.BLACK);
		// regB.setBackground(new Color(0, 194, 255));
		regB.setFont(new Font("David", 1, 18));
		exitB.addActionListener(new ExitListener());

		exitB.setForeground(Color.BLACK);
		regB.addActionListener(new RegisterListener());
		// regB.setBackground(new Color(0, 194, 255));
		exitB.setFont(new Font("David", 1, 18));
		centerPanel.add(regB);
		centerPanel.add(exitB);
		//

		errorLabel = new JLabel("");
		errorLabel.setBounds(40, 305, 300, 30);
		errorLabel.setForeground(Color.RED);
		errorLabel.setFont(new Font("David", 1, 16));
		centerPanel.add(errorLabel);
		errorLabel1 = new JLabel("");
		errorLabel1.setBounds(40, 330, 300, 30);
		errorLabel1.setForeground(Color.RED);
		errorLabel1.setFont(new Font("David", 1, 16));
		centerPanel.add(errorLabel1);
		add(centerPanel, BorderLayout.CENTER);

	}

	// exit listener class
	private class ExitListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			dispose();
		}

	}

	// register admin class
	private class RegisterListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			String prePassW = new String(prePassField.getPassword());
			if (preUserField.getText().equals(userName) && prePassW.equals(password)) {

				saveUserCredential();

			} else {
				JOptionPane.showMessageDialog(null, "Older credentials not correct...");

			}
		}

		// user credential insertion
		private void saveUserCredential() {
			PreparedStatement ps = null;
			String passW = new String(passField.getPassword());

			// -----------------------------------------------------------------------

			String sql = "insert into adminTable values(?,?,?)";
			try {
				ps = EstrongDbConnection.getConnection().prepareStatement(sql);

				ps.setInt(1, userNo);
				ps.setString(2, userField.getText().toLowerCase());
				ps.setString(3, passW);

				ps.execute();
				JOptionPane.showMessageDialog(null, "Data saved successfully...", "Message",
						JOptionPane.INFORMATION_MESSAGE);
				new LoginDialog().setVisible(true);
				dispose();


				userField.setText(null);
				passW = "";
			} catch (SQLException exc) {

				exc.printStackTrace();

			} finally {
				try {

					EstrongDbConnection.getConnection().close();
					ps.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	}

}
