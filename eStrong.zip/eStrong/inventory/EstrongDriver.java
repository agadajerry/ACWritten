package eStrong.inventory;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.UIManager.LookAndFeelInfo;

public class EstrongDriver extends JFrame {

	private JComboBox<String> loginBox;
	private JButton okB;
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		// UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		new EstrongDriver();

		createFolder();
		createAdminT();//
		// insertUserCredential();// insert int admin table automatically

		for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {

			if ("Windows Classic".equals(info.getName())) {
				try {
					UIManager.setLookAndFeel(info.getClassName());
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	public EstrongDriver() {

		setSize(new Dimension(500, 300));
		setLocationRelativeTo(null);
		initialiseUi();
		this.setLayout(null);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/e_Strong/images/e_stronglogo.png"));
		setIconImage(icon);

	}

	private void initialiseUi() {

		//
		JLabel titleLabel = new JLabel("E-STRONG INVENTORY SOFTWARE | USER LOGIN PAGE");
		titleLabel.setFont(new Font("ALGERIAN", 1, 16));
		titleLabel.setForeground(Color.BLUE);
		titleLabel.setBounds(20, 20, 500, 30);
		String users[] = { "Users", "Admin" };
		loginBox = new JComboBox<>(users);
		loginBox.addItemListener(new ItemSelectListener());
		JLabel userLabel = new JLabel("Select User's Role");
		userLabel.setFont(new Font("David", 1, 18));
		loginBox.setFont(new Font("David", 1, 18));

		userLabel.setBounds(80, 60, 200, 30);
		loginBox.setBounds(80, 90, 200, 30);
		//
		okB = new JButton("Enter");
		okB.setBounds(80, 130, 100, 30);
		okB.setFont(new Font("David", 1, 18));
		okB.addActionListener(new UserListener());

		//
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		panel.add(userLabel);
		panel.add(loginBox);
		panel.add(okB);
		panel.add(titleLabel);

		///

		ImageIcon cmpIcon = new ImageIcon(getClass().getResource("/e_Strong/images/display.png"));
		JLabel iconLabel = new JLabel("", cmpIcon, JLabel.CENTER);
		iconLabel.setBounds(280, 90, 300, 300);
		panel.add(iconLabel);
		add(panel);

		setVisible(true);
	}

	private class UserListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (loginBox.getSelectedItem().equals("Admin")) {

				LoginDialog lp = new LoginDialog();
				lp.setVisible(true);
				dispose();

			} else {
				UserHomePanel uhp = new UserHomePanel();
				uhp.setVisible(true);
				dispose();
			}

		}

	}

	private class ItemSelectListener implements ItemListener {

		@Override
		public void itemStateChanged(ItemEvent arg0) {
			if (loginBox.getSelectedIndex() == 1) {

				deleteUserCredential();// delete before insert if any available
				insertUserCredential();// insert into table with id =1
			}
		}

	}

	private static void createFolder() {
		String dbURL_location = "C:\\E_Strong_SellFolder\\InvoiceFiles\\";

		File newFile = new File(dbURL_location);
		if (!newFile.exists()) {
			newFile.mkdirs();
		}

		// creation of tables for all inventory entry

		PreparedStatement ps = null, psItemBuy = null, psLog = null, psCus = null, ps_invoice = null, ps_delete = null,
				ps_update = null, ps_productRecord = null;
		String qry = "CREATE TABLE IF NOT EXISTS allitems_Inventory ( serialNo INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
				+ "productId INTEGER NOT NULL, itemname TEXT NOT NULL, "
				+ "quantity INTEGER NOT NULL, costprice INTEGER NOT NULL, " + "sellingprice INTEGER NOT NULL, "
				+ "itemlocation TEXT NOT NULL, supplier TEXT NOT NULL,dateNow VARCHAR(45) NOT NULL,"
				+ "FOREIGN KEY(productId) REFERENCES Product_record(serialNo) "
				+ "ON DELETE CASCADE ON UPDATE CASCADE)";
		//
		String itemboughtUrl = "Create Table If Not Exists item_purchased (serilaN INTEGER not null PRIMARY KEY AUTOINCREMENT,"
				+ "productId INT NOT NULL," + " product_name TEXT NOT NULL,"
				+ "quantity	INTEGER NOT NULL, Unitprice	INTEGER NOT NULL, totalprice int NOT NUll, "
				+ "CustomerName_adress VARCHAR(45), mydate Text Not Null,FOREIGN KEY(productId) REFERENCES allitems_Inventory(serialNo)"
				+ " ON DELETE CASCADE ON UPDATE CASCADE)";

		String logQry = "CREATE TABLE if not Exists customerlog (product_name Text NOT NULL, "
				+ "quantity_bought	Int NOT NULL, selling_price int NOT NULL, totalamount int NOT NULL, "
				+ "mydate TEXT NOT NULL);";
		//
		String custQry = "CREATE TABLE if not Exists customerlist (cusname	Varchar(100) NOT NULL,"
				+ " cusaddress	Varchar(100) NOT NULL, " + "date Text NOT NULL);";

		//

		String deleteTable = "CREATE TABLE IF NOT EXISTS deleted_product (deleted_date TEXT NOT NULL, "
				+ "product_name TEXT NOT NULL," + " quantity INT NOT NULL)";
		String updateQry = "Create Table if not exists update_table (updated_Date Text not null, item_updated Text not null"
				+ ", quantity int NOT NULL)";

		String prdtRecord = "CREATE TABLE IF NOT EXISTS Product_record "
				+ "(serialNo INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
				+ "productName VARCHAR(45) NOT NULL, VENDOR VARCHAR(45) NOT NULL,"
				+ "ITEMLocation VARCHAR(45) NOT NULL," + "Category VARCHAR (45), createDate VARCHAR (45) NOT NULL)";

		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(qry);

			psItemBuy = EstrongDbConnection.getConnection().prepareStatement(itemboughtUrl);
			psLog = EstrongDbConnection.getConnection().prepareStatement(logQry);
			psCus = EstrongDbConnection.getConnection().prepareStatement(custQry);
			ps_delete = EstrongDbConnection.getConnection().prepareStatement(deleteTable);
			ps_update = EstrongDbConnection.getConnection().prepareStatement(updateQry);
			ps_productRecord = EstrongDbConnection.getConnection().prepareStatement(prdtRecord);

			ps_invoice = EstrongDbConnection.getConnection().prepareStatement(
					"Create table if not exists " + "invoiceList (list_Of_invoice_generated" + " TEXT NOT NULL)");

			ps_productRecord.execute();
			ps.execute();
			ps_delete.execute();
			psLog.execute();
			ps_invoice.execute();
			psItemBuy.execute();
			psCus.execute();
			ps_update.execute();
		} catch (SQLException ex) {
			System.out.println("All items table creation error" + ex);
			ex.printStackTrace();
		} finally {
			try {

				EstrongDbConnection.getConnection().close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	// create table
	private static void createAdminT() {
		PreparedStatement ps = null;

		String admintable = "CREATE TABLE IF NOT EXISTS adminTable " + "(userId INTEGER NOT NULL PRIMARY KEY"
				+ " AUTOINCREMENT," + "userName VARCHAR(45) NOT NULL," + " password VARCHAR(45) NOT NULL)";
		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(admintable);
			ps.execute();

		} catch (SQLException ec) {
			ec.printStackTrace();
		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	private static void insertUserCredential() {
		PreparedStatement ps = null;
		// -----------------------------------------------------------------------

		String sql = "insert into adminTable values(?,?,?)";
		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(sql);

			ps.setInt(1, 1);
			ps.setString(2, "admin");
			ps.setString(3, "estrong400");

			ps.execute();

		} catch (SQLException exc) {

			exc.printStackTrace();

		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	// user credential insertion
	private void deleteUserCredential() {
		PreparedStatement ps = null;
		// -----------------------------------------------------------------------

		String sql = "delete from  adminTable  where userId=?";
		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(sql);

			ps.setInt(1, 1);
			ps.execute();

		} catch (SQLException exc) {

			exc.printStackTrace();

		} finally {
			try {

				EstrongDbConnection.getConnection().close();
				ps.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
}
