package eStrong.inventory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class LoginDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel userNameLabel, passwordLabel;
	private JButton loginB, regB;
	private JTextField userField;
	private JPasswordField passField;
	private JLabel errorLabel, errorLabel1;
	private String userName = null, password = null;
	private int userNo;

	public LoginDialog() {

		setSize(new Dimension(400, 300));

		setLayout(new BorderLayout());
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setModal(true);

		this.setLocationRelativeTo(null);
		setBackground(Color.LIGHT_GRAY);
		this.setResizable(false);

		Image iconImage = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/e_Strong/images/e_strong.png"));
		setIconImage(iconImage);
		initialiseUi();

	}

	private void initialiseUi() {
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(null);
		centerPanel.setBounds(10, 10, 390, 290);
		centerPanel.setBackground(Color.LIGHT_GRAY);

		centerPanel.setBackground(Color.WHITE);

		// admin registration dialog
		JLabel adLabel = new JLabel("<html><h2 style= color:rgb(0,130,230);>Admin Login</h2></html>");
		adLabel.setBounds(105, 8, 200, 30);
		centerPanel.add(adLabel);
		///

		userNameLabel = new JLabel("User Name:");
		userNameLabel.setFont(new Font("David", 1, 16));
		userField = new JTextField();
		userNameLabel.setBounds(20, 45, 100, 30);
		userField.setBounds(105, 40, 200, 40);
		userField.setFont(new Font("David", 1, 16));
		userField.setBorder(new LineBorder(Color.BLACK, 2));
		centerPanel.add(userNameLabel);
		centerPanel.add(userField);
		//
		passwordLabel = new JLabel("Password:");
		passwordLabel.setFont(new Font("David", 1, 16));
		passField = new JPasswordField();
		passwordLabel.setLabelFor(passField);
		passwordLabel.setBounds(20, 110, 100, 16);
		passField.setBounds(105, 100, 200, 40);
		passField.setBorder(new LineBorder(Color.BLACK, 2));
		passField.setFont(new Font("David", 1, 30));
		centerPanel.add(passwordLabel);
		centerPanel.add(passField);
		//

		//
		loginB = new JButton("Login");
		loginB.setBounds(105, 150, 200, 40);

		regB = new JButton("Register");
		regB.setBounds(105, 210, 200, 40);

		loginB.setForeground(Color.BLACK);
		// loginB.setBackground(new Color(0, 194, 255));
		loginB.setFont(new Font("David", 1, 18));
		regB.addActionListener(new RegisterListener());

		regB.setForeground(Color.BLACK);
		loginB.addActionListener(new LoginListener());
		// loginB.setBackground(new Color(0, 194, 255));
		regB.setFont(new Font("David", 1, 18));
		centerPanel.add(loginB);
		centerPanel.add(regB);
		//

		errorLabel = new JLabel("");
		errorLabel.setBounds(40, 305, 300, 30);
		errorLabel.setForeground(Color.RED);
		errorLabel.setFont(new Font("David", 1, 16));
		centerPanel.add(errorLabel);
		errorLabel1 = new JLabel("");
		errorLabel1.setBounds(40, 330, 300, 30);
		errorLabel1.setForeground(Color.RED);
		errorLabel1.setFont(new Font("David", 1, 16));
		centerPanel.add(errorLabel1);
		add(centerPanel, BorderLayout.CENTER);

		OlduserNamePassWord();
		lastIdNo();// last serial no

	}

	// exit listener class
	private class LoginListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			String passW = new String(passField.getPassword().toString().toLowerCase());

			if (userField.getText().isEmpty() || passW.isEmpty()) {
				JOptionPane.showMessageDialog(null, "Empty text fields...");
			} else {

				adminLogin(userField.getText().toLowerCase(), passW);
			}
		}

	}

	private void adminLogin(String userName, String password) {
		String passW = String.valueOf(passField.getPassword());
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = EstrongDbConnection.getConnection()
					.prepareStatement("" + "Select * from adminTable " + "order by userId desc limit 1");

			rs = ps.executeQuery();

			if (rs.next()) {

				String users = rs.getString("userName");
				String pass = rs.getString("password");

				if (users.equals(userField.getText().toString().toLowerCase()) && pass.equals(passW)) {
					E_Strong_Home adNew = new E_Strong_Home();
					adNew.setVisible(true);
					dispose();
				} else {
					JOptionPane.showMessageDialog(null, "Wrong user's credentials. Try again");

				}

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				
				EstrongDbConnection.getConnection().close();
				ps.close();
				rs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	// register admin class
	private class RegisterListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			AdminRegistrationDialog ard = new AdminRegistrationDialog(userNo, password, userName);
			System.out.println("password" + password);
			ard.setVisible(true);
			dispose();
		}

	}

	//
	private void OlduserNamePassWord() {

		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			 ps = EstrongDbConnection.getConnection()
					.prepareStatement("" + "Select userName, password From adminTable where userId=?");
			ps.setInt(1, 1);
			 rs = ps.executeQuery();
			while (rs.next()) {
				userName = rs.getString("userName");
				password = rs.getString("password");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}finally {
				try {
					
					EstrongDbConnection.getConnection().close();
					ps.close();
					rs.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}

		}

	

	// last id
	private void lastIdNo() {
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			 ps = EstrongDbConnection.getConnection()
					.prepareStatement("" + "Select userId From adminTable ORDER BY " + "userId desc LIMIT 1");

			 rs = ps.executeQuery();
			while (rs.next()) {
				int userId = rs.getInt("userId");
				userNo = (userId + 1);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}finally {
				try {
					
					EstrongDbConnection.getConnection().close();
					ps.close();
					rs.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}

		}

	}

