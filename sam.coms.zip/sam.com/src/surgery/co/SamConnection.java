package surgery.co;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class SamConnection {

	public static Connection getConnection() {
		Connection dbConn = null;
		try {

		String dbURL = "jdbc:sqlite:C:\\SamSurgeryOperation\\SamOperationDb.db";
			
			dbConn = DriverManager.getConnection(dbURL);
		} catch (SQLException ex) {
			System.out.println(ex.getMessage() + " DB connection");
			ex.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error in sqlite connection...");

		}
		return dbConn;
	}

}
