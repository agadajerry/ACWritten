package surgery.co;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class SurgeryHome extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel centerPanel, contentPane;
	private JTable table;
	private DefaultTableModel model;
	private JButton actionBtn[] = new JButton[4];
	private DefaultTableCellRenderer cellRenderer;
	private TableRowSorter<DefaultTableModel> sorter;
	private JTextField searchField;
	public int idNo = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {

			if ("Windows Classic".equals(info.getName())) {
				try {
					UIManager.setLookAndFeel(info.getClassName());
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SurgeryHome frame = new SurgeryHome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		pathCreation();// create path
		//
		createTable();

	}

	/**
	 * Create the frame.
	 */
	public SurgeryHome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(1200, 700);
		this.setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		//
		Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/sam/image/sam.png"));
		setIconImage(icon);
		//

		JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		northPanel.setToolTipText("fdsdfdfdf");
		northPanel.setBackground(Color.WHITE);

		JLabel northLabel = new JLabel("<html><body><div>" + "<h1> RECORDS FOR SURGICAL OPERATION" + ""
				+ "</h1><hr/><span style=color:red>SAMMY</span></div></body></html>");

		northLabel.setFont(new Font("Aharoni", Font.BOLD, 18));
		northPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

		northPanel.add(northLabel);

		contentPane.add(northPanel, BorderLayout.NORTH);

		///

		centerPanel = new JPanel(new FlowLayout());
		JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		//
		searchField = new JTextField();
		searchField.setPreferredSize(new Dimension(300, 30));
		searchField.setFont(new Font("David", 1, 16));
		searchField.addKeyListener(new ItemSearchListener());

		JLabel searchLabel = new JLabel("Search");
		searchLabel.setBackground(Color.BLACK);
		searchLabel.setFont(new Font("David", 1, 16));
		btnPanel.add(searchLabel);
		btnPanel.add(searchField);

		for (int i = 0; i < actionBtn.length; i++) {
			actionBtn[i] = new JButton();
			actionBtn[i].setPreferredSize(new Dimension(200, 30));
			actionBtn[i].setFont(new Font("David", 1, 20));
			actionBtn[i].addActionListener(new BtnListeners());

			btnPanel.add(actionBtn[i]);
		}
		actionBtn[0].setText("Add New Record");
		actionBtn[1].setText("Update Record");
		actionBtn[2].setText("Delete");
		actionBtn[3].setText("Refresh");
		//
		table = new JTable();
		String[] columnName = { "S/No", "Date", "Patient Names", "Address", "Age", "Sex", "Weight" + "", "Diagnosis",
				"Treatment", "Type of Anesthesia", "anesthestiest names", "Surgeon Name", "Assistance surgeon",
				"Complications" };
		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 14));
		table.getTableHeader().setBackground(new Color(0, 194, 255));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(25);
		table.setForeground(Color.BLACK);
		table.setFont(new Font("David", Font.BOLD, 12));
		table.addMouseListener(new RowClickedListener());
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(columnName);

		JScrollPane tableScroll = new JScrollPane(table);
		tableScroll.setPreferredSize(new Dimension(1300, 500));
		JPanel tableScrollPanel = new JPanel(new FlowLayout());
		tableScrollPanel.setBackground(Color.WHITE);

		table.getColumnModel().getColumn(0).setPreferredWidth(80);
		table.getColumnModel().getColumn(2).setPreferredWidth(200);
		table.getColumnModel().getColumn(10).setPreferredWidth(200);
		table.getColumnModel().getColumn(11).setPreferredWidth(200);
		table.getColumnModel().getColumn(11).setCellRenderer(cellRenderer);
		cellRenderer = new DefaultTableCellRenderer();
		cellRenderer.setHorizontalAlignment(JLabel.CENTER);
		// tableScrollPanel.setBorder(new EmptyBorder(5,5,5,5));
		tableScrollPanel.add(tableScroll);
		//
		centerPanel.add(btnPanel);
		centerPanel.add(tableScrollPanel);

		//
		// add table panel to content pane
		contentPane.add(centerPanel, BorderLayout.CENTER);

		allOperationRecords();// call all saved operation surgically
	}

	// btn listener class
	private class BtnListeners implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent ev) {

			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("Add New Record")) {
				SugeryInfo si = new SugeryInfo();
				si.setVisible(true);
			}

			if (btn.getActionCommand().equals("Update Record")) {

				if (table.getSelectedRow() == -1) {
					JOptionPane.showMessageDialog(null,
							"Select row of interest from the table and click update button...");
				} else {
					int i = table.getSelectedRow();
					int idNo2 = Integer.parseInt((String) model.getValueAt(i, 0));
					String patName = (String) model.getValueAt(i, 2);
					String address = (String) model.getValueAt(i, 3);
					String age = (String) model.getValueAt(i, 4);
					String weight = (String) model.getValueAt(i, 6);
					String treatMnt = (String) model.getValueAt(i, 8);
					String complication = (String) model.getValueAt(i, 13);

					SurgicalUpdateDialog sud = new SurgicalUpdateDialog(idNo2, patName, address, age, weight, treatMnt,
							complication);
					sud.setVisible(true);
					System.out.println("" + idNo2);
				}
			}

			if (btn.getActionCommand().equals("Delete")) {
				if (table.getSelectedRow() == -1) {
					JOptionPane.showMessageDialog(null, "Select the row you want to delete from the table...");
				} else {
					int choice = JOptionPane.showConfirmDialog(null, "Do you want to " + "delete the selected row?");
					if (choice == JOptionPane.YES_OPTION) {
						deleteHistory();
						model.setRowCount(0);
						allOperationRecords();
					}

				}
			}

			if (btn.getActionCommand().equals("Refresh")) {

				if (table.getRowCount() == 0) {
					JOptionPane.showMessageDialog(null, " Table is empty...");
				} else
					model.setRowCount(0);
				allOperationRecords();// call all saved operation surgically

			}
		}

	}

	// create table for the data entry
	private static void createTable() {

		String qry = "CREATE TABLE IF NOT EXISTS samOperation_info ("
				+ "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,patientName VARCHAR(45) NOT NULL,"
				+ " sex VARCHAR(45) NOT NULL,age VARCHAR(45), weight VARCHAR(45),"
				+ "address TEXT not null,surgeonName VARCHAR(45) NOT NULL,assist_Surgeon VARCHAR(45),"
				+ " anesthaticType VARCHAR(45), anesthesia_Name VARCHAR(45)," + " diagnosis VARCHAR(45) NOT NULL,"
				+ "complication VARCHAR(45),Treatment VARCHAR(255),surDate VARCHAR(45))";

		try {
			PreparedStatement ps = SamConnection.getConnection().prepareStatement(qry);
			ps.execute();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	// create a path

	private static void pathCreation() {

		String fileLocation = "C:\\SamSurgeryOperation\\";

		File newFile = new File(fileLocation);
		if (!newFile.exists()) {
			newFile.mkdirs();
		}
	}

	// select all from database

	private void allOperationRecords() {

		try {
			PreparedStatement ps = SamConnection.getConnection().prepareStatement("Select * from samOperation_info");

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int idNo = rs.getInt("id");
				String patName = rs.getString("patientName");
				String sex = rs.getString("sex");
				String age = rs.getString("age");
				String weight = rs.getString("weight");
				String address = rs.getString("address");
				String surgeonName = rs.getString("surgeonName");
				String assist_Surgeon = rs.getString("assist_Surgeon");
				String anesthaticType = rs.getString("anesthaticType");
				String anesthesia_Name = rs.getString("anesthesia_Name");
				String diagnosis = rs.getString("diagnosis");
				String complication = rs.getString("complication");
				String treatment = rs.getString("Treatment");
				String surgDate = rs.getString("surDate");

				model.addRow(new String[] { idNo + "", surgDate, patName, address, age, sex, weight, diagnosis,
						treatment, anesthaticType, anesthesia_Name, surgeonName, assist_Surgeon, complication });

			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	// sorter focus listener class
	private void sorterProduct(String qry) {
		sorter = new TableRowSorter<DefaultTableModel>(model);
		table.setRowSorter(sorter);
		sorter.setRowFilter(RowFilter.regexFilter(qry));
	}

	//
	private class ItemSearchListener implements KeyListener {

		@Override
		public void keyPressed(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void keyReleased(KeyEvent arg0) {
			sorterProduct(searchField.getText().toString().toUpperCase());

		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	private void deleteHistory() {

		try {
			PreparedStatement ps = SamConnection.getConnection()
					.prepareStatement("Delete from samOperation_info where id =?");
			ps.setInt(1, idNo);

			ps.execute();
			JOptionPane.showMessageDialog(null, "The selected record is deleted successfully");
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

	}

	// row clicked listener
	private class RowClickedListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent arg0) {
			int i = table.getSelectedRow();
			idNo = Integer.parseInt("" + model.getValueAt(i, 0));
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

	}
}
