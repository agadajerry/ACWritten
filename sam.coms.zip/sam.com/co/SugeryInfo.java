package surgery.co;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Locale;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

import com.toedter.calendar.JDateChooser;

public class SugeryInfo extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JLabel[] inputLabel = new JLabel[2];
	private JTextField[] inputField = new JTextField[2];
	private JDateChooser regDate;
	private JComboBox<String> sexBox;
	private DefaultComboBoxModel<String> cModel;
	private JTextField patientField;
	private JTextArea addressField;
	private DefaultComboBoxModel<String> surModel, assModel, anestyModel, anesNameModel, diagoModel;

	private JComboBox<String> surgeonNameBox, assist_SurgeonBox, anesthaticTypeBox, anesthesia_NameBox, diagnosisBox;
	private JLabel[] operationLabel = new JLabel[5];
	private JTextArea complexDisplay, treatDisplay;
	private JButton saveB;
	private int lastId = 1;

	/**
	 * Create the dialog.
	 */
	public SugeryInfo() {
		this.setSize(new Dimension(1000, 600));
		this.setLocationRelativeTo(null);
		this.setModal(true);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(null);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPanel.setBackground(Color.WHITE);
		getContentPane().add(contentPanel, BorderLayout.CENTER);

		{

			//
			// title
			JLabel titleLabel = new JLabel("RECORD OF SURGICAL OPERATIONS");
			titleLabel.setFont(new Font("David", 1, 24));
			titleLabel.setBounds(280, 10, 600, 30);
			contentPanel.add(titleLabel);
			{//
				//
				patientField = new JTextField();
				JLabel patientLabel = new JLabel("Patient Name:");
				patientLabel.setFont(new Font("David", 1, 16));
				patientField.setFont(new Font("David", 1, 16));
				patientField.setBorder(new LineBorder(Color.BLACK, 1));
				patientLabel.setBounds(20, 60, 150, 30);
				patientField.setBounds(175, 60, 200, 30);
				contentPanel.add(patientLabel);
				contentPanel.add(patientField);
				//
				String[] genda = { "Gender", "Male", "Female" };
				cModel = new DefaultComboBoxModel<String>(genda);
				sexBox = new JComboBox<String>(cModel);
				sexBox.setBorder(new LineBorder(Color.BLACK, 1));
				JLabel sexLabel = new JLabel("Gender:");
				sexLabel.setBounds(20, 100, 150, 30);
				sexLabel.setForeground(new Color(0, 0, 0));
				sexLabel.setFont(new Font("David", 1, 18));
				//
				sexBox.setPreferredSize(new Dimension(200, 30));
				sexBox.setForeground(new Color(0, 0, 0));
				sexBox.setFont(new Font("David", 1, 18));
				sexBox.setBounds(175, 100, 200, 30);
				contentPanel.add(sexLabel);
				contentPanel.add(sexBox);
				//

				for (int i = 0; i < inputField.length; i++) {
					inputField[i] = new JTextField();
					inputLabel[i] = new JLabel();
					inputLabel[i].setFont(new Font("David", 1, 18));
					inputField[i].setFont(new Font("David", 1, 18));
					inputField[i].setBorder(new LineBorder(Color.BLACK, 1));

					inputLabel[i].setBounds(20, 140 + (35 * i), 150, 30);
					inputField[i].setBounds(175, 140 + (35 * i), 200, 30);
					contentPanel.add(inputLabel[i]);
					contentPanel.add(inputField[i]);

				}
				inputLabel[0].setText("Age:");
				inputLabel[1].setText("Weight:");

				//
				regDate = new JDateChooser();
				regDate.setLocale(Locale.US);
				JLabel dateLabel = new JLabel("Surgery Date:");
				dateLabel.setFont(new Font("David", 1, 18));
				dateLabel.setBounds(20, 215, 150, 30);
				regDate.setBounds(175, 215, 200, 30);
				regDate.setBorder(new LineBorder(Color.BLACK, 1));
				contentPanel.add(dateLabel);
				contentPanel.add(regDate);
				//
				JLabel addrLabel = new JLabel("Address:");
				addressField = new JTextArea();
				addrLabel.setBounds(20, 268, 150, 30);
				addressField.setBounds(175, 268, 200, 80);
				addressField.setBorder(new LineBorder(Color.BLACK, 1));
				addressField.setLineWrap(true);
				addressField.setFont(new Font("David", 1, 18));
				addrLabel.setFont(new Font("David", 1, 18));
				contentPanel.add(addrLabel);
				contentPanel.add(addressField);
			}

			// east panel with remaining components

			// Initialize combo box
			for (int i = 0; i < operationLabel.length; i++) {
				operationLabel[i] = new JLabel();
				operationLabel[i].setBounds(500, 65 + (35 * i), 200, 30);
				operationLabel[i].setFont(new Font("David", 1, 18));
				contentPanel.add(operationLabel[i]);

			}

			operationLabel[0].setText("Surgeon Name:");
			operationLabel[1].setText("Asst. Surgeon:");
			operationLabel[2].setText("Type of anesthesia:");
			operationLabel[3].setText("anesthesia Name:");
			operationLabel[4].setText("Diagonsis:");

			//
			surModel = new DefaultComboBoxModel<>();
			surgeonNameBox = new JComboBox<String>(surModel);
			surgeonNameBox.setBounds(700, 65, 200, 30);
			surgeonNameBox.setEditable(true);
			AutoCompleteDecorator.decorate(surgeonNameBox);

			surgeonNameBox.setFont(new Font("David", 1, 18));
			surgeonNameBox.setBorder(new LineBorder(Color.BLACK, 1));

			contentPanel.add(surgeonNameBox);

			assModel = new DefaultComboBoxModel<>();
			assist_SurgeonBox = new JComboBox<String>(assModel);
			assist_SurgeonBox.setBounds(700, 100, 200, 30);

			assist_SurgeonBox.setEditable(true);
			AutoCompleteDecorator.decorate(assist_SurgeonBox);
			assist_SurgeonBox.setFont(new Font("David", 1, 18));
			assist_SurgeonBox.setBorder(new LineBorder(Color.BLACK, 1));

			contentPanel.add(assist_SurgeonBox);
			//
			anestyModel = new DefaultComboBoxModel<>();
			anesthaticTypeBox = new JComboBox<String>(anestyModel);
			anesthaticTypeBox.setBounds(700, 135, 200, 30);

			anesthaticTypeBox.setFont(new Font("David", 1, 18));
			anesthaticTypeBox.setBorder(new LineBorder(Color.BLACK, 1));
			anesthaticTypeBox.setEditable(true);
			AutoCompleteDecorator.decorate(anesthaticTypeBox);
			contentPanel.add(anesthaticTypeBox);

			anesNameModel = new DefaultComboBoxModel<>();
			anesthesia_NameBox = new JComboBox<String>(anesNameModel);
			anesthesia_NameBox.setBounds(700, 170, 200, 30);
			anesthesia_NameBox.setFont(new Font("David", 1, 18));
			anesthesia_NameBox.setBorder(new LineBorder(Color.BLACK, 1));
			anesthesia_NameBox.setEditable(true);
			AutoCompleteDecorator.decorate(anesthesia_NameBox);
			contentPanel.add(anesthesia_NameBox);
			//
			diagoModel = new DefaultComboBoxModel<>();
			diagnosisBox = new JComboBox<String>(diagoModel);
			diagnosisBox.setBounds(700, 205, 200, 30);
			diagnosisBox.setFont(new Font("David", 1, 18));
			diagnosisBox.setBorder(new LineBorder(Color.BLACK, 1));
			diagnosisBox.setEditable(true);
			AutoCompleteDecorator.decorate(diagnosisBox);
			contentPanel.add(diagnosisBox);
			//

			JLabel complexLabel = new JLabel("Complication:");
			complexDisplay = new JTextArea();
			complexDisplay.setBorder(new LineBorder(Color.BLACK, 1));
			complexLabel.setBounds(500, 250, 150, 30);
			complexDisplay.setBounds(700, 250, 200, 80);
			complexDisplay.setLineWrap(true);
			complexDisplay.setFont(new Font("David", 1, 18));
			complexLabel.setFont(new Font("David", 1, 18));
			contentPanel.add(complexLabel);
			contentPanel.add(complexDisplay);

			///

			JLabel treatLabel = new JLabel("Treatment:");
			treatDisplay = new JTextArea();
			treatLabel.setBounds(500, 330, 160, 30);
			treatDisplay.setBounds(350, 360, 400, 80);
			treatDisplay.setBorder(new LineBorder(Color.BLACK, 1));
			treatDisplay.setLineWrap(true);
			treatDisplay.setFont(new Font("David", 1, 18));
			treatLabel.setFont(new Font("David", 1, 18));
			contentPanel.add(treatLabel);
			contentPanel.add(treatDisplay);
			//

			// save button initialise
			saveB = new JButton("SAVE");
			saveB.setBounds(600, 450, 120, 30);
			saveB.setForeground(Color.WHITE);
			saveB.setBackground(Color.GRAY);
			saveB.setFont(new Font("David", 1, 16));
			contentPanel.add(saveB);
			saveB.addActionListener(new SaveDataListener());

			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);

			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		lastPatientId();// last data entered no
		allComboRecords();
		allComboRecords2();
		allComboRecords3();
		allComboRecords4();
		allComboRecords5();
	}

	// class for button operation
	private class SaveDataListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (patientField.getText().isEmpty() || sexBox.getSelectedItem() == null
					|| inputField[0].getText().isEmpty() || inputField[1].getText().isEmpty()
					|| regDate.getDate() == null || surgeonNameBox.getSelectedItem() == null
					|| anesthaticTypeBox.getSelectedItem() == null || assist_SurgeonBox.getSelectedItem() == null
					|| diagnosisBox.getSelectedItem() == null || anesthesia_NameBox.getSelectedItem() == null
					|| complexDisplay.getText().isEmpty() || treatDisplay.getText().isEmpty()) {

				JOptionPane.showMessageDialog(null, "One or all text fields are empty...");
			} else {
				save2Db();
				lastPatientId();// last data entered no

			}
		}

	}

	// save info to database
	private void save2Db() {

		// date format
		SimpleDateFormat dFormat = new SimpleDateFormat("yyyy/MM/dd");
		String surg_date = dFormat.format(regDate.getDate());
		String qry = "INSERT INTO samOperation_info VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {

			PreparedStatement ps = SamConnection.getConnection().prepareStatement(qry);

			ps.setInt(1, lastId);
			ps.setString(2, patientField.getText().toUpperCase());
			ps.setString(3, sexBox.getSelectedItem().toString());
			ps.setString(4, inputField[0].getText());
			ps.setString(5, inputField[1].getText().toUpperCase());
			ps.setString(6, addressField.getText().toUpperCase());
			ps.setString(7, surgeonNameBox.getSelectedItem().toString().toUpperCase());
			ps.setString(8, assist_SurgeonBox.getSelectedItem().toString().toUpperCase());
			ps.setString(9, anesthaticTypeBox.getSelectedItem().toString().toUpperCase());
			ps.setString(10, anesthesia_NameBox.getSelectedItem().toString().toUpperCase());
			ps.setString(11, diagnosisBox.getSelectedItem().toString().toUpperCase());
			ps.setString(12, complexDisplay.getText().toString().toUpperCase());
			ps.setString(13, treatDisplay.getText().toString().toUpperCase());
			ps.setString(14, surg_date);

			ps.execute();

			//
			// empty fields after saving
			inputField[0].setText("");
			inputField[1].setText("");
			complexDisplay.setText("");
			treatDisplay.setText(null);

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	// last entered id
	private void lastPatientId() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = SamConnection.getConnection().prepareStatement("Select id from samOperation_info ORDER BY id DESC");

			rs = ps.executeQuery();

			if (rs.next()) {
				int idNo = rs.getInt("id");
				lastId = (idNo + 1);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {

			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	private void allComboRecords() {

		try {
			PreparedStatement ps = SamConnection.getConnection()
					.prepareStatement("Select " + " DISTINCT surgeonName from samOperation_info");

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				String surgeonName = rs.getString("surgeonName");

				// ,,,,
				surModel.addElement((surgeonName));

			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private void allComboRecords2() {

		try {
			PreparedStatement ps = SamConnection.getConnection()
					.prepareStatement("Select " + " DISTINCT assist_Surgeon from samOperation_info");

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				String assist_Surgeon = rs.getString("assist_Surgeon");

				// ,,,,
				assModel.addElement(assist_Surgeon);

			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private void allComboRecords3() {

		try {
			PreparedStatement ps = SamConnection.getConnection()
					.prepareStatement("Select " + " DISTINCT anesthaticType from samOperation_info");

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				String anesthaticType = rs.getString("anesthaticType");

				// ,,,,

				anestyModel.addElement(anesthaticType);

			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private void allComboRecords4() {

		try {
			PreparedStatement ps = SamConnection.getConnection()
					.prepareStatement("Select " + " DISTINCT anesthesia_Name from samOperation_info");

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				String anesthesia_Name = rs.getString("anesthesia_Name");
				// ,,,,

				anesNameModel.addElement(anesthesia_Name);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private void allComboRecords5() {

		try {
			PreparedStatement ps = SamConnection.getConnection()
					.prepareStatement("Select " + " DISTINCT diagnosis from samOperation_info");

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				String diagnosis = rs.getString("diagnosis");

				diagoModel.addElement(diagnosis);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}
}
