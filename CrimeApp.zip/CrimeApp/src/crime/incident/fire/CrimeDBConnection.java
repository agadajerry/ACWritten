package crime.incident.fire;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CrimeDBConnection {

	public static Connection getConnection() {
		Connection conn = null;
		try {
			String dbUrl = "jdbc:sqlite:\\DBBrowser\\crimeData.db";
			conn = DriverManager.getConnection(dbUrl);
			
		}catch(SQLException ex) {
			System.out.println(ex.getMessage());
			
		}
		return conn;
	}
}
