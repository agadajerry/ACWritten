package crime.incident.fire;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JPanel;

public class picPanel extends JPanel
{
Image imgp;
picPanel(Image img){
	this.imgp = img;
	repaint();
}
public void paintComponent(Graphics g)
{
	super.paintComponent(g);
	g.drawImage(imgp, 0, 0, getWidth(), getHeight(), this);
}
}
