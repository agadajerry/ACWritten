package crime.incident.fire;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import com.toedter.calendar.JDateChooser;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.Locale;

public class Incidency extends JFrame {

	// class fields

	private static final long serialVersionUID = 1L;
	private JFrame window;
	private JPanel welcomePanel;
	private JLabel welcomeLabel;
	private JButton clickBtn, saveBtn, browse;
	private JPanel fieldPanel, AllPanels;
	private JTextField imageField;
	private JComboBox<String> stateBox, lGABox;
	private JComboBox<String> crimeType;
	private JLabel crimeNameL, imageShow;
	private JTextArea localArea, eventArea;
	private JButton retButton;
	private JTextField idField;
	private JDateChooser crimeDate;
	private Hashtable<String, String[]> subItems = new Hashtable<String, String[]>();

// constructor

	public Incidency() {
		window = new JFrame();
		window.setTitle("CrimeApp");
		window.setSize(new Dimension(830, 600));

		incidentUI();
	}

//method for initialization of ui

	public void incidentUI() {

		welcomePanel = new JPanel(new BorderLayout());
		welcomePanel.setBackground(new Color(36, 31, 27));
		welcomeLabel = new JLabel("WELCOME TO CRIME REPORTER APP", SwingConstants.CENTER);
		welcomeLabel.setForeground(Color.RED);
		Font wlcmFont = new Font("Algerian", 1, 26);
		welcomeLabel.setFont(wlcmFont);
		welcomePanel.add(welcomeLabel);

		JPanel clickPanel = new JPanel();
		clickPanel.setBackground(new Color(36, 31, 27));
		// clickBtn = new JButton("Click Here");
		JLabel instLabel = new JLabel(" To Report A Crime or other related incident");
		instLabel.setForeground(Color.RED);
		// clickBtn.setForeground(Color.RED);
		// clickBtn.setBackground(new Color(36,31,27));
		clickPanel.add(instLabel);
		// clickPanel.add(clickBtn);

		JPanel okWel = new JPanel(new BorderLayout());
		okWel.add(welcomePanel, BorderLayout.CENTER);
		okWel.add(clickPanel, BorderLayout.SOUTH);

//***********************************************************

		// ************************** panel for state, lga etc
		fieldPanel = new JPanel();
		fieldPanel.setLayout(null);

		// **********************************************
		// crime type combo ui

		String[] crimeList = { "Select Out Break", "stealing", "bomb blast", "Rap" };
		crimeType = new JComboBox<String>(crimeList);
		crimeType.setBounds(200, 100, 200, 20);
		crimeNameL = new JLabel("Nature of crime");
		crimeNameL.setBounds(200, 80, 100, 20);
		fieldPanel.add(crimeNameL);
		fieldPanel.add(crimeType);

		// ******************************************** date chooser
		crimeDate = new JDateChooser();
		crimeDate.setLocale(Locale.US);

		JLabel dateLabel = new JLabel("Select crime date");
		dateLabel.setBounds(470, 80, 100, 20);
		crimeDate.setBounds(470, 100, 100, 20);
		fieldPanel.add(dateLabel);
		fieldPanel.add(crimeDate);

		// ***************************************************** State combo box

		String[] state = { "State", "Benue", "Lagos", "Gombe" };
		String lga[] = { "LGA" };
		lGABox = new JComboBox<String>(lga);
		stateBox = new JComboBox<String>(state);
		stateBox.addActionListener(new Listener());

		String[] benue = { "Obi", "Ogbadibo", "Ado" };
		subItems.put(state[1], benue);
		String[] lagos = { "Surulere", "Apapa", "Ikeja", "Ajegula" };
		subItems.put(state[2], lagos);
		String[] gombe = { "Kwami", "Funakayi", "Akko", "Beliri", "Dukku", "Katungu", "Gombe" };
		subItems.put(state[3], gombe);

		// lGABox.addActionListener(this);

		stateBox.setBounds(200, 150, 200, 20);
		lGABox.setBounds(200, 190, 200, 20);
		fieldPanel.add(stateBox);
		fieldPanel.add(lGABox);
		// **********************************************

		JLabel areaLabel = new JLabel("District Address:");
		localArea = new JTextArea(10, 40);
		areaLabel.setBounds(90, 230, 200, 70);
		localArea.setBounds(200, 230, 240, 90);

		JScrollPane scroll = new JScrollPane();
		scroll.add(localArea);
		fieldPanel.add(areaLabel);
		fieldPanel.add(localArea);
		fieldPanel.add(scroll); // this is not scrolling xx

		// *************************************************
		eventArea = new JTextArea("  Describe what happened during the \n incident "
				+ "this will help the the security \nagent fast track the investigation");
		eventArea.setBounds(200, 340, 240, 150);
		// focusListener for the event discreption area field
		eventArea.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent ev) {
				eventArea = (JTextArea) ev.getComponent();
				eventArea.setText("");
				eventArea.removeFocusListener(this);
			}
		});
		JLabel eventLabel = new JLabel("Event Discriptions:");
		eventLabel.setBounds(90, 330, 210, 70);
		fieldPanel.add(eventArea);
		fieldPanel.add(eventLabel);
		// ***************************************************

		JPanel imagePanel = new JPanel();

		imageShow = new JLabel("");
		imageShow.setBounds(449, 229, 229, 259);
		imagePanel.add(imageShow);
		// imagePanel.revalidate();//check this for more
		// imagePanel.repaint(); //check this for more insight

		imagePanel.setBounds(450, 232, 310, 260);
		imagePanel.setBackground(Color.BLUE);

		// create text field and button for image retrieval from database

		retButton = new JButton("Retrieve image");
		idField = new JTextField();

		// setting the location for the retrieving id field and button

		idField.setBounds(450, 495, 90, 20);
		retButton.setBounds(542, 495, 150, 20);
		retButton.addActionListener(new ButtonAction());
		JLabel imageLabel = new JLabel("Import picture (300X260 JPG)");
		imageLabel.setBounds(450, 180, 180, 20);
		browse = new JButton("Browse...");
		browse.addActionListener(new Listener2());
		browse.setBounds(450, 210, 90, 20);
		imageField = new JTextField("No Image Selected");
		imageField.setBounds(540, 210, 190, 20);
		saveBtn = new JButton("Save");
		saveBtn.addActionListener(new Listener2());
		saveBtn.setBounds(729, 210, 70, 20);
		fieldPanel.add(saveBtn);
		fieldPanel.add(imageField);
		fieldPanel.add(browse);
		fieldPanel.add(imagePanel);
		fieldPanel.add(imageLabel);

		// adding retrieving button and id field to panel

		fieldPanel.add(retButton);
		fieldPanel.add(idField);

		// ****************************************************************

		// overall panel and cardLayout section

		CardLayout newCard = new CardLayout();

		AllPanels = new JPanel();
		// add all other panels to this panel,
		// then add above AllPanel to frame

		AllPanels.setLayout(newCard);
		AllPanels.add(fieldPanel, "1");
		AllPanels.add(okWel, "2");
		newCard.show(AllPanels, "2");

		// create a thread that will slide the welcome panel to the next panel

		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					Thread.sleep(7000);
				} catch (InterruptedException e) {
					e.fillInStackTrace();
				}
				newCard.show(AllPanels, "1");
			}

		}).start();

		/*
		 * this action listener enable button click that let to the next panel. thread
		 * has replace button click now clickBtn.addActionListener(new ActionListener()
		 * {
		 * 
		 * @Override public void actionPerformed(ActionEvent e) { // TODO Auto-generated
		 * method stub //newCard.show(AllPanels, "1"); }
		 * 
		 * });
		 */

		window.getContentPane().add(AllPanels);
		window.getRootPane().setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, Color.BLUE));
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);

	} // end of method body

//implementation of action listener for browse button

	private class Listener implements ActionListener {

		public void actionPerformed(ActionEvent e) {

			String stateList = (String) stateBox.getSelectedItem();
			Object o = subItems.get(stateList);
			if (o == null) {
				lGABox.setModel(new DefaultComboBoxModel<String>());
			} else {
				lGABox.setModel(new DefaultComboBoxModel<String>((String[]) o));
			}

		}
	}// end of comboBox listener class

//method for that access images from local files

	private void getImageFile(String imagePath) {

		try {

			FileInputStream fis = null;
			File fileOut = null;
			byte[] rawBytes = null;

			if (imagePath.equals("No Image Selected")) {
				ClassLoader cl = this.getClass().getClassLoader();
				URL resource = cl.getResource("resources\\blank-image.png");
				imagePath = resource.getFile();
			}

			// connection to database

			PreparedStatement ps = null;

			String querryDb = "INSERT INTO CRIMEwatch(CrimeType, State, LGA,crimeDate, DistrictAddr, "
					+ "EventInfo,Photos) Values(?,?,?,?,?,?,?);";

			ps = CrimeDBConnection.getConnection().prepareStatement(querryDb);

			// ****************************************************************

			// converting the table field and combo box to strings

			String crimety = crimeType.getSelectedItem().toString();
			String state = stateBox.getSelectedItem().toString();
			String LGA = lGABox.getSelectedItem().toString();
			String Cdate = "no date yet";
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
			Cdate = dateFormat.format(crimeDate.getDate());
			String districtAddr = localArea.getText();
			String eventInfo = eventArea.getText();

			// **********************************************************************************
			ps.setString(1, crimety);
			ps.setString(2, state);
			ps.setString(3, LGA);
			ps.setString(4, Cdate);
			ps.setString(5, districtAddr);
			ps.setString(6, eventInfo);

			// before using the image file, they is need to convert it to stream of byte
			try {
				fileOut = new File(imagePath);
				fis = new FileInputStream(fileOut);// abstract image path

				// finding the length of image string to integer

				// int imageLength = Integer.parseInt(String.valueOf(imagePath.length()));
				// //image path to integer
				rawBytes = new byte[fis.available()]; // an estimate of the number of remaining bytes that can be read
														// (or skipped over) from this input stream without blocking.

				// reading the image values by the file input stream

				fis.read(rawBytes); // the buffer into which the data is read.

			} catch (FileNotFoundException ex) {
				System.out.println(ex.getMessage());
			} finally {
				try {
					if (fis != null) {
						fis.close();
					}
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
			// set the bytes of image to the prepared statement of db

			ps.setBytes(7, rawBytes);

			// *********************************************************************************

			if (ps.executeUpdate() > 0) {
				JOptionPane.showMessageDialog(this, "Data save successfully");
			} else {
				JOptionPane.showMessageDialog(this, "failed to save data, check your information");
			}
		} catch (HeadlessException | NumberFormatException | IOException | SQLException ex) {
			JOptionPane.showMessageDialog(this, ex.getMessage());

		}
	}// end of image path method

//listener class that handle file chooser
	private class Listener2 implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			if (e.getActionCommand().equals("Browse...")) {
				JFileChooser fc = new JFileChooser();
				/*
				 * If the file passed in as <code>currentDirectory</code> is not a directory,
				 * the parent of the file will be used as the currentDirectory. If the parent is
				 * not traversable, then it will walk up the parent tree until it finds a
				 * traversable directory, or hits the root of the file system.
				 */
				fc.setCurrentDirectory(new File(System.getProperty("user.home")));
				// filter the files
				FileNameExtensionFilter filter = new FileNameExtensionFilter("*.images", "gif", "png", "jpg");
				fc.addChoosableFileFilter(filter);

				int result = fc.showOpenDialog(null);

				// if user click on save in JFileChooser

				if (result == JFileChooser.APPROVE_OPTION) {

					String path = fc.getSelectedFile().getAbsolutePath();

					String extension = path.substring(path.lastIndexOf("."));

					if (extension.equalsIgnoreCase(".jpg") || extension.equalsIgnoreCase(".png")
							|| extension.equalsIgnoreCase("gif")) {
						imageField.setText(fc.getSelectedFile().getPath());

						Image img = Toolkit.getDefaultToolkit().createImage(path).getScaledInstance(229, 258, 0);

						ImageIcon myImage = new ImageIcon(img);

						imageShow.setIcon(myImage);

						// imageShow = new JLabel(new ImageIcon(path),JLabel.CENTER);

					} else {
						JOptionPane.showMessageDialog(null, "selelct image file only");
					}
				} else {
					imageField.setText("no file uploaded");
				}
			} else if (e.getActionCommand().equals("Save")) {
				if (imageField.getText().equals("No Image Selected")) {
					JOptionPane.showMessageDialog(null, "upload an image first");

				} else
					getImageFile(imageField.getText());

			}

		}

	}

	/*
	 * this method will be used to retrieve image from the database
	 */
	public void retrieveImage() throws IOException {
		try {

			String idd = idField.getText();
			if (idd.length() > 0) {

				String retrieveImage = " SELECT photos FROM Crimewatch WHERE ID = ?";
				PreparedStatement pre;
				pre = CrimeDBConnection.getConnection().prepareStatement(retrieveImage);

				pre.setString(1, idd);

				ResultSet rs = pre.executeQuery();
				byte[] image = null;
				while (rs.next()) {

					image = rs.getBytes("photos");

				}

				imageShow.setIcon(
						new ImageIcon(Toolkit.getDefaultToolkit().createImage(image).getScaledInstance(229, 258, 0)));

				pre.close();

			} else {
				JOptionPane.showMessageDialog(this, "please enter id");
			}

		} catch (SQLException ex) {

		}
	}

	// inner class that handle button click on the image retrieval from db
	private class ButtonAction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource().equals(retButton)) {
				try {
					retrieveImage();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}

	}

}
