package crime.incident.fire;

import javax.swing.SwingUtilities;

public class CrimeDriver {

	public static void main(String[] args) 
	{
		new Incidency();
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
			
		});
	}

}
