package com.questionsAndAnswers;



				
public class ToStringLearning {
	private int year;
	private String colour;
	private String make;
	
	
	
	public ToStringLearning(int year, String colour, String make) {
		this.year = year;
		this.colour = colour;
		this.make = make;
	}// end constructor
	
//*********************************************************************
	
	public String toString() {
		return "year =" +year +" colour = " +colour +" make = "  +make;
	}// end toString
//**************************************************************************

	public static void main(String[] args) {
		
		ToStringLearning car = new ToStringLearning(1999, "blue", "honda");
		
		System.out.println(car.toString());
	}

}
