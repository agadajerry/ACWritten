package com.questionsAndAnswers;

import java.util.Scanner;

/*************************************\
 * adding two number together         *
 * @author ENGR_IDOKO				  *
 *									  *
 *************************************/
public class SumTwoNo {

	public static void main(String[] args) {
		int number1;
		int number2;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number one");
		
		number1 = sc.nextInt();
		System.out.println("Enter number  two");
		number2 = sc.nextInt();
		int sum = number1 + number2;
		System.out.println("the sum of the two numbers is =" +" "+sum);
		sc.close();
	}

}
