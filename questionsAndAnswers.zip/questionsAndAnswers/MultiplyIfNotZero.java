package com.questionsAndAnswers;

import java.util.Scanner;

/**************************************************************\
 * multiply two numbers if the first number is not zero, 
 * otherwise print zero  if the first number is zero
 * @author ENGR_IDOKO
 *
 ***************************************************************/


public class MultiplyIfNotZero {

	public static void main(String[] args) {
		
int num1;
int num2;
Scanner sc = new Scanner(System.in);
System.out.println("Enter the first number");
num1 = sc.nextInt();
if(num1!=0) {
	System.out.println("Enter the second number");
num2 = sc.nextInt();
	
	System.out.println("The product of the two entered numbers is: "+num1*num2);
}
else {
	System.out.println("the first number entered is "+0);
}
sc.close();
	}

}
