package com.questionsAndAnswers;
/****************************************************************
 * MY GUI GREETING CODE
 *****************************************************************/

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class GreetingsYou extends JFrame {
	
					private static final int HEIGHT = 300;
					private static final int WIDTH = 250;
					private JTextField jt;
					private JLabel greeting;

					public GreetingsYou() {
					setTitle("greetings");
					setSize(WIDTH, HEIGHT);
					setLayout(new FlowLayout(FlowLayout.LEFT));
					setDefaultCloseOperation(EXIT_ON_CLOSE);
					contents();
					setVisible(true);
				}
					
	//*************************************************************************************
	

					private void contents() {
					JLabel label = new JLabel("what is your name?");
					jt = new JTextField(20);
					greeting = new JLabel();
					add(greeting);
					add(label);
					add(jt);
					
					jt.addActionListener( new Listener());
				
       }

//***************************************************************************************************
					
					private class Listener implements ActionListener{
					
					public void actionPerformed(ActionEvent e) {
				String message = "glad to meet  you, " +jt.getText() + "!";
				jt.setText(" ");
				greeting.setText(message);
				
				setLayout(new FlowLayout(FlowLayout.LEFT));
				validate();
					}
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
new  GreetingsYou();
	}

}
