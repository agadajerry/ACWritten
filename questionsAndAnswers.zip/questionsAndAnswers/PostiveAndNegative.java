package com.questionsAndAnswers;

import java.util.Scanner;

/******************************************************\
 * a number enter whether positive or negative
 * By Jerry 
 ******************************************************/

public class PostiveAndNegative {

	public static void main(String[] args) {

Scanner sc = new Scanner(System.in);
System.out.println("Please enter a number");
int number = sc.nextInt();
if(number>0) {
	System.out.println("the number entered is positive");
}
if(number<0) {
	System.out.println("the number entered is a negative number");
}
sc.close();
	}

}
