
package com.questionsAndAnswers;

import java.util.Scanner;

/****************************************8
 * multiplication oof a number
 * @author ENGR_IDOKO
 *
 **************************************/
public class MultiplicationTable {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number for multiplication");
		int num = sc.nextInt();
		for(int i =0; i<5; i++) {
		int c = i+1;
					System.out.println(num +"X" +c +"=" +" " +(num*c));
					sc.close();
		}
		for(int j =5;j>=0; --j) {
			int aa = j+1;
			System.out.println(aa);
		}
	
	}

}
