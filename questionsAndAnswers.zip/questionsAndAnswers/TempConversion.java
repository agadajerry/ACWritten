package com.questionsAndAnswers;

import java.util.Scanner;

/***************************************
 * Temperature conversion
 *   fahrenheit = 18/10+32 
 *   kelvin = celcius +273
 */
public class TempConversion {

	public static void main(String[] args) {
		double sum = 1.8 + 32;
double cels;
double falh;
Scanner sc = new Scanner(System.in);
System.out.println("Enter Celcius value in degree");
cels = sc.nextDouble();
falh = cels*sum;
System.out.println("the Fahrenheit value is:" +" " +falh+"F");
double kelvin = cels + 273;
System.out.println("Equivalent Temperature in Kelvin is: "+kelvin+"K");
sc.close();
	}

}
