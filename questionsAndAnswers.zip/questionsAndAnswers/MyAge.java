package com.questionsAndAnswers;

import java.util.Scanner;

/*********************************8
 * displaying the expected age of an individual 
 * @author ENGR_IDOKO
 *
 ****************************************************/

public class MyAge {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter your age here");
		
		int age = sc.nextInt();
		
		System.out.println("sorry, you look younger than the inputted age i.e" +" "+age);
	System.out.println(+age-2);
	sc.close();
	}

}
