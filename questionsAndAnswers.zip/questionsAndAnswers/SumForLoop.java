package com.questionsAndAnswers;

import java.util.Scanner;

public class SumForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n;
int sum = 0;
int num = 0;
Scanner sc = new Scanner(System.in);
System.out.println("Enter an Integer");
n = sc.nextInt();

for(int i =1; i<=n; i++) {
if(i%3 ==0) {
		
num =i;
sum += i;

	}
}
System.out.println("[================================================================]");

System.out.println("The sum of a numbers in" +" "+n +" "+ "divided by three without remainder" +" " +" =" +" "+sum);


System.out.println("And the numbers are");
for(int i =1; i<=n; i++) {
if(i%3 ==0) {
		
num =i;
System.out.print(num  +"+");

	}

      }
System.out.println();
System.out.println("[================================================================]");
sc.close();
   }
}
