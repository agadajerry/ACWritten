package com.questionsAndAnswers;

/*
 * timing program using thread class
 * 
 */
 class  demon extends Thread{

	public void run()  {
		for(int i =1;i<=5;i++)
		{
			System.out.println("my name is jerry");
			try{Thread.sleep(1000);}catch(Exception e) {}
		}
	}
}
	 class Hello extends Thread{
		public void run()  {
			for(int i =1;i<=5;i++)
			{
				System.out.println("hello jerry");
				try{ Thread.sleep(1000);}catch (Exception ex) {}
			}
		}
		
	}

	

		public class SimpleThread{
			
		
	public static void main(String[] args) 
	{
		demon de = new demon();
		Hello he = new Hello();
		de.start();
		try { Thread.sleep(1000); }catch (Exception ex) {}
		he.start();
	
	}
	}
	

