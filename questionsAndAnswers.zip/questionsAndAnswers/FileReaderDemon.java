package com.questionsAndAnswers;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class FileReaderDemon 
{

	public static void main(String[] args) 
	{
		Scanner fileInput ;
		try {
			fileInput = new Scanner(new FileReader("C:\\myjavawork\\notePad\\fileOut.txt"));
			System.out.println(fileInput);
			fileInput.close(); 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
