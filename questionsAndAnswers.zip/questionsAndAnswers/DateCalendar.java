package com.questionsAndAnswers;
/*
 * this is a simple time demon. using system timing 
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateCalendar {

	public static void main(String[] args) 
	
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd  hh:mm:ss");
		
		Calendar cal = Calendar.getInstance();
		
		System.out.println(dateFormat.format(cal.getTime()));
	}

}
