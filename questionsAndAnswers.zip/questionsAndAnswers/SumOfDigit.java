package com.questionsAndAnswers;
/*
 * 
 * This program find out the sum of a digit entered
 * 
 ************************************************************/

import java.util.Scanner;

public class SumOfDigit {

	public static void main(String[] args) {
		
		
			int sum = 0;
			int num1;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter a digit to sum it");
			num1 = sc.nextInt();
			
			while(num1>0)
			{
				int x = num1%10;
				sum = sum + x;
				num1 = num1/10;
			}
				System.out.println("The sum of the digit entered is "  +" = "+sum);
				sc.close();

	}

}
