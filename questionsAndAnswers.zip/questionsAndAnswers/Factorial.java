package com.questionsAndAnswers;
/********************************************************8
 * this is a factorial program
 * @author ENGR_IDOKO
 *
 ***********************************************************/
import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int facto = 1;
int n;
//************************************************************************************

Scanner sc = new Scanner(System.in);
System.out.println("ENTER A NUMBER TO SOLVE IT FACTORIAL");
n = sc.nextInt();

for(int i =1; i<=n; i++) {
	
	facto = facto*i;
}
System.out.println("\nTHE NUMBER ENTERED IS "+n);
System.out.println("THE FACTORIAL OF " +" "+n +"!" +"=" +" "+facto);
sc.close();
	}
	

}
