package com.questionsAndAnswers;
/******************************************************************\
 * if a user input pwrong password more than two time, 
 * invalid message will beprint
 ****************************************************************/
import java.util.Scanner;

public class PasswordFiveTimes {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String user, pass;
		int attempts= 0;
//***********************************************************************************************
		do
		{
			System.out.println("enter a user");
			user = sc.next();
			System.out.println("Enter password");
			pass = sc.next();
			attempts++;
		}
//**************************************************************************************************
		
while(!user.equals("user")&&!pass.equals("password") && attempts!= 2);
		if(attempts==2) {
		System.out.println("login incorrect");
		
		}else {
			System.out.println("login correct");
			
			sc.close();
	}


	}
}
