package com.questionsAndAnswers;
/************************************************
 *  multiples of numbers 3 and 5 in 500
 * @author ENGR_IDOKO
 *
 **************************************************/

import java.util.Scanner;
public class multiples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner sc = new Scanner(System.in);
			System.out.println("pls enter number to find it multiples");
			int n = sc.nextInt();
			System.out.println("Enter two number as the multiple of "+n);
			int fn = sc.nextInt();
			int sn = sc.nextInt();
			int i = 1;
			System.out.println("the multiples are");
				while(i<=n) {
				if( (i%fn ==0) && (i%sn ==0))
						
				System.out.println(i +" ");
				
				i++;
				sc.close();
					}
				}
					
	}


