package com.questionsAndAnswers;

import java.util.Scanner;

/**********************
 * remainder of after divisionn
 * @author ENGR_IDOKO
 *
 **************************************/
public class Remainder {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = "anas is here"; 
		System.out.println("enter two number to divide");
		int num1 = sc.nextInt();
		int num2 =  sc.nextInt();
		int num3 = num1%num2;
		System.out.println("the remainder is =" +" " +num3);
		System.out.println(str.toUpperCase());
		sc.close();
	}

}
