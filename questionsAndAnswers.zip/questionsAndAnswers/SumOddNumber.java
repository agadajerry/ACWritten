package com.questionsAndAnswers;

import java.util.Scanner;

public class SumOddNumber 
{

	public static void main(String[] args)
	{
			int firstTerm;
			int secondTerm;
			int commonDifference;
			double sum = 0;
			int term;
			int number;
			Scanner sc =  new Scanner(System.in);
			
			System.out.println("Enter a number to find the range of it terms");
			number = sc.nextInt();
			System.out.println("Enter  it first term");
			firstTerm = sc.nextInt();
			System.out.println("Enter it second term");
			secondTerm = sc.nextInt();
			System.out.println("The first and second term entered of Are "+firstTerm +" ,"+secondTerm);
			
			commonDifference = secondTerm - firstTerm;
			int div = number/2;
			
			sum = div*(2*firstTerm +(number -1)*commonDifference);
			System.out.println("the sum of "+number+" is "+sum);
		sc.close();	
	}

}

				
				
			
		
			

			
			
			
		
	


