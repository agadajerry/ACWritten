package com.questionsAndAnswers;

import java.util.Scanner;

public class DivisionIfNotZero {

	public static void main(String[] args) {
		int num1;
		int num2;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		num1 = sc.nextInt();
		System.out.println("Enter the second number");
		num2 = sc.nextInt();
		if(num2==0) {
			System.out.println("Denominator during division cannoot be zero. This is syntax error");
		}else {
			System.out.println("first number divide by second number is" +" "+(double)num1/num2); //casting of primitive data type, int todouble
			System.out.println("And the remainder is "+" "+num1%num2);
		}
		sc.close();
	}

}
