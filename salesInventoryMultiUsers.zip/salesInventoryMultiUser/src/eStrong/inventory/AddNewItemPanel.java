package eStrong.inventory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class AddNewItemPanel extends JDialog implements FocusListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel[] addItemLabel = new JLabel[6];
	private JTextField[] inputField = new JTextField[6];
	private JTable table;
	private DefaultTableModel model;
	private JButton saveB, updateB, deleteB, importB,refreshB;
	private int idNo;
	private String productDescription;
	private String loctn = "";
	private JTextField searchField;
	private DefaultTableCellRenderer cellRenderer;
	private TableRowSorter<DefaultTableModel> sorter;
	private int prodS_no = 0;

	public AddNewItemPanel(int idNo, String productName, String loctn) {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.setBounds(0,0,screenSize.width,screenSize.height);
		setTitle("Sale Inventory Management System");
		setLocationRelativeTo(null);
		//setResizable(false);
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setModal(true);
		//
		this.idNo = idNo;
		this.productDescription = productName;
		this.loctn = loctn;
		//
		JPanel northPanel = new JPanel();
		northPanel.setBackground(Color.GRAY);
		JLabel descLabel = new JLabel("INVENTORY OF THE PRODUCT", JLabel.CENTER);
		descLabel.setFont(new Font("david", 1, 18));
		descLabel.setForeground(Color.WHITE);
		northPanel.add(descLabel);
		add(northPanel, BorderLayout.NORTH);
		// centerPanel for input and it label
		JPanel mainCenterPanel = new JPanel(new GridLayout(2, 1));
		// mainCenterPanel.setBorder(new EmptyBorder(10,10,10,10));

		JPanel centerPanel = new JPanel(new GridLayout(7, 2, 5, 5));

		centerPanel.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		// centerPanel.setBackground(Color.WHITE);
		JPanel addPanel2Center = new JPanel(new GridLayout(1, 2, 10, 10));
		addPanel2Center.add(centerPanel);
		addPanel2Center.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		//
		JPanel operationPanel = new JPanel();// dummy panel
		ImageIcon cmpIcon = new ImageIcon(getClass().getResource("/e_Strong/images/display.png"));
		JLabel iconLabel = new JLabel("", cmpIcon, JLabel.CENTER);
		// operationPanel.setBackground(Color.GRAY);

		operationPanel.add(iconLabel);
		addPanel2Center.add(operationPanel);//
		// import product details from the record
		importB = new JButton("Import...");
		centerPanel.add(importB);
		importB.addActionListener(new ImportDialogListener());
		centerPanel.add(new JLabel(""));
		for (int i = 0; i < inputField.length; i++) {
			inputField[i] = new JTextField();
			addItemLabel[i] = new JLabel();
			addItemLabel[i].setForeground(new Color(0, 0, 0));
			addItemLabel[i].setFont(new Font("David", 1, 16));
			inputField[i].setFont(new Font("David", 1, 16));
			inputField[i].setBorder(new LineBorder(new Color(204, 204, 204), 3));
			centerPanel.add(addItemLabel[i]);
			centerPanel.add(inputField[i]);
		}

		addItemLabel[0].setText("ITEM'S NAME:");
		addItemLabel[1].setText("QUANTITY:");
		addItemLabel[2].setText("COST PRICE:");
		addItemLabel[3].setText("SELLING PRICE:");
		addItemLabel[4].setText("ITEM'S LOCATION:");
		addItemLabel[5].setText("SUPPLIER NAME:");
		//
		inputField[0].setText(productDescription);// product description
		inputField[4].setText(loctn);// product location
		// operational button, save clear buttons
		JPanel operationBtnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		operationBtnPanel.setBackground(Color.WHITE);

		//
		// search product name
		searchField = new JTextField();
		searchField.setPreferredSize(new Dimension(100, 30));
		searchField.setFont(new Font("David", 1, 16));
		searchField.setBorder(new LineBorder(Color.BLACK));
		searchField.addKeyListener(new ItemSearchListener());
		JLabel searchLabel = new JLabel("Search:");
		searchLabel.setBorder(new LineBorder(Color.GRAY));
		searchLabel.setFont(new Font("David", 1, 18));
		operationBtnPanel.add(searchLabel);
		operationBtnPanel.add(searchField);
		//
		saveB = new JButton("SAVE");
		saveB.addActionListener(new SaveDataListener());
		updateB = new JButton("UPDATE");
		deleteB = new JButton("DELETE");
		updateB.addActionListener(new UpdateListener());

		operationBtnPanel.add(saveB);
		operationBtnPanel.add(updateB);
		operationBtnPanel.add(deleteB);

		//
		//
		saveB.setForeground(Color.WHITE);
		saveB.setBackground(new Color(0, 194, 255));
		saveB.setFont(new Font("David", 1, 16));
		saveB.setPreferredSize(new Dimension(200, 40));
		saveB.addFocusListener(this);
		//
		deleteB.setForeground(Color.WHITE);
		deleteB.setBackground(new Color(0, 194, 255));
		deleteB.setFont(new Font("David", 1, 16));
		deleteB.setPreferredSize(new Dimension(200, 40));
		deleteB.addFocusListener(this);
		deleteB.addActionListener(new DeleteInventoryListener());
		//

		updateB.setPreferredSize(new Dimension(200, 40));
		updateB.setForeground(Color.WHITE);
		updateB.setBackground(new Color(0, 194, 255));
		updateB.setFont(new Font("David", 1, 16));
		updateB.addFocusListener(this);

		//
		refreshB = new JButton("REFRESH");
		refreshB.setForeground(Color.WHITE);
		refreshB.setBackground(new Color(0, 194, 255));
		refreshB.setFont(new Font("David", 1, 16));
		refreshB.setPreferredSize(new Dimension(200, 40));
		refreshB.addActionListener(new RefreshListener());
		
		JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		southPanel.add(refreshB);
		add(southPanel,BorderLayout.SOUTH);
		//
		mainCenterPanel.add(addPanel2Center);

		// table for inserted data from input field
		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 18));
		table.getTableHeader().setBackground(new Color(0, 194, 255));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(25);
		table.setForeground(Color.BLACK);
		table.setFont(new Font("David", Font.BOLD, 13));

		table.addMouseListener(new TextFieldGetTextListener());

		String tableColumn[] = { "Serial No", "ItemName", "Quantity", "CostPrice", "SellingPrice", "Item'sLocation",
				"Supplier", "Date" };
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(tableColumn);
		JScrollPane scrollBar = new JScrollPane(table);
		scrollBar.setPreferredSize(new Dimension(1150, 200));
		JPanel tablePanel = new JPanel(new BorderLayout());
		tablePanel.add(operationBtnPanel,BorderLayout.NORTH);
		tablePanel.add(scrollBar,BorderLayout.CENTER);

		///

		table.getColumnModel().getColumn(0).setPreferredWidth(4);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(0).setCellRenderer(cellRenderer);
		cellRenderer = new DefaultTableCellRenderer();
		cellRenderer.setHorizontalAlignment(JLabel.CENTER);
		mainCenterPanel.add(tablePanel);
		add(mainCenterPanel, BorderLayout.CENTER);

		getInventoryProduct();// call the inventory product
	}

	// save data from text field to database
	private class SaveDataListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			try {
				String itemName = inputField[0].getText().toString().trim();
				String itemLocation = inputField[4].getText().toUpperCase().trim();

				if (itemName.isEmpty() || itemLocation.isEmpty()) {
					JOptionPane.showMessageDialog(null, "One or two fields are empty...");
				} else {

					saveToDb();

					// refresh
					model.setRowCount(0);
					getInventoryProduct();
				}
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(null, "The values entered are not correct or empty input fields.\n"
						+ " Check your entry" + " and try again...");
			}
		}

	}

	//
	private void saveToDb() {
		String itemName = inputField[0].getText().toString().trim().toUpperCase();
		int qtty = Integer.parseInt(inputField[1].getText().trim());
		double costPrice = Double.parseDouble(inputField[2].getText().trim());
		double sellingPrice = Double.parseDouble(inputField[3].getText().trim());
		String itemLocation = inputField[4].getText().trim().toUpperCase();
		String supplier = inputField[5].getText().trim().toUpperCase();
		//

		SimpleDateFormat sDateF = new SimpleDateFormat("yyyy-MM-dd");
		Date nDate = new Date();
		String todayDate = sDateF.format(nDate.getTime());
		//
		PreparedStatement ps = null;
		String qry = " INSERT INTO allitems_Inventory VALUES (0,?,?,?,?,?,?,?,?)";
		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(qry);

			ps.setInt(1, idNo);
			ps.setString(2, itemName);
			ps.setInt(3, qtty);
			ps.setDouble(4, costPrice);
			ps.setDouble(5, sellingPrice);
			ps.setString(6, itemLocation);
			ps.setString(7, supplier);
			ps.setString(8, todayDate);
			ps.execute();

			for (int i = 0; i < inputField.length; i++) {
				inputField[i].setText(null);
			}

		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null,"Import product from product list first "
					+ "before taking the inventory");
		} finally {
			try {
				EstrongDbConnection.getConnection().close();
			} catch (SQLException exc) {
				System.out.println("Data insertion error 2 " + exc);

			}
		}

	}

	// Update class listener
	private class UpdateListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (table.getSelectedRow() == -1) {
				JOptionPane.showMessageDialog(null,
						"Product Name / ID is unknown. Select row of interest from the table and hit update...");
			} else {
				int i = table.getSelectedRow();
				prodS_no = Integer.parseInt("" + model.getValueAt(i, 0));
				String productName = (String) model.getValueAt(i, 1);
				int qty = Integer.parseInt("" + model.getValueAt(i, 2));
				double  costP  = Double.parseDouble((String) model.getValueAt(i, 3));
				double  sellingP  = Double.parseDouble((String) model.getValueAt(i, 4));
				String loction = (String) model.getValueAt(i, 5);
				String suppl = (String) model.getValueAt(i, 6);
				String dateTim = (String) model.getValueAt(i, 7);

				UpdateProductDialog upd = new UpdateProductDialog(prodS_no,productName,qty,costP,sellingP,
						loction,suppl);
				upd.setVisible(true);
			}
		}
	}

	// setting back jtable text to text field
	private class TextFieldGetTextListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent arg0) {
			int i = table.getSelectedRow();
			prodS_no = Integer.parseInt("" + model.getValueAt(i, 0));
			saveB.setEnabled(false);

		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	@Override
	public void focusGained(FocusEvent ev) {
		JButton btn = (JButton) ev.getSource();
		if (btn.getActionCommand().equals("SAVE")) {
			saveB.setBackground(Color.WHITE);
			saveB.setForeground(new Color(0, 194, 255));
		}
		if (btn.getActionCommand().equals("UPDATE")) {
			updateB.setBackground(Color.WHITE);
			updateB.setForeground(new Color(0, 194, 255));
		}
		if (btn.getActionCommand().equals("DELETE")) {
			deleteB.setBackground(Color.WHITE);
			deleteB.setForeground(new Color(0, 194, 255));
		}
	}

	@Override
	public void focusLost(FocusEvent ev) {
		JButton btn = (JButton) ev.getSource();
		if (btn.getActionCommand().equals("SAVE")) {
			saveB.setBackground(new Color(0, 194, 255));
			saveB.setForeground(Color.WHITE);
		}
		if (btn.getActionCommand().equals("UPDATE PRODUCT")) {
			updateB.setBackground(new Color(0, 194, 255));
			updateB.setForeground(Color.WHITE);
		}
		if (btn.getActionCommand().equals("DELETE ROW")) {
			deleteB.setBackground(new Color(0, 194, 255));
			deleteB.setForeground(Color.WHITE);
		}
	}

	// clear table
	private class DeleteInventoryListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (table.getSelectedRow() == -1) {
				JOptionPane.showMessageDialog(null,
						"Product Name / ID is unknown. Select row of interest from the table and hit delete...");
			} else {
				int choice = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to delete the selected Product from the inventory?");
				if (choice == JOptionPane.YES_OPTION) {
					// remove table data first

					deleteinventoryProductDetails();
					//
					model.setRowCount(0);
					getInventoryProduct();// refresh product table again
					//

					saveB.setEnabled(true);//

				}
			}
		}
	}

	// import listener class
	private class ImportDialogListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			ProductSelection pS = new ProductSelection();
			pS.setVisible(true);
		}

	}

	private void deleteinventoryProductDetails() {

		try {
			PreparedStatement ps = EstrongDbConnection.getConnection()
					.prepareStatement("Delete From" + " allitems_Inventory where serialNo =?");
			ps.setInt(1, prodS_no);
			ps.executeUpdate();
		} catch (SQLException ex) {
			System.out.println("" + ex);
		}

	}

	// sorter focus listener class
	private void sorterProduct(String qry) {
		sorter = new TableRowSorter<DefaultTableModel>(model);
		table.setRowSorter(sorter);
		sorter.setRowFilter(RowFilter.regexFilter(qry));
	}
	//

	// keylistener for search product
	private class ItemSearchListener implements KeyListener {

		@Override
		public void keyPressed(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void keyReleased(KeyEvent arg0) {
			sorterProduct(searchField.getText().toString().toUpperCase());

		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	/*
	 * this method retrive inventory product from the table
	 * 
	 */
	private void getInventoryProduct() {
		int sNo = 0;
		String prdName = null;
		String loctn = null, dateTime = null, supplier = null;
		int qtty = 0;
		double costP = 0, sellingP = 0;
		try {

			String qry = "Select * from allitems_Inventory";
			PreparedStatement ps = EstrongDbConnection.getConnection().prepareStatement(qry);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				sNo = rs.getInt("serialNo");
				prdName = rs.getString("itemname");
				qtty = rs.getInt("Quantity");
				loctn = rs.getString("ITEMLocation");
				dateTime = rs.getString("dateNow");
				supplier = rs.getString("supplier");
				costP = rs.getDouble("costprice");
				sellingP = rs.getDouble("sellingprice");
				//
				model.addRow(new String[] { "" + sNo, prdName, "" + qtty, "" + costP, "" + sellingP, loctn, supplier,
						dateTime });
				//
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	//refresh table after update or deletion is made on the table
	private class RefreshListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {

			model.setRowCount(0);
			getInventoryProduct(); // call inventory table data
		}
		
	}
}
