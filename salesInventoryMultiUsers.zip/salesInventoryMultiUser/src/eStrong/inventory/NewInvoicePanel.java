package eStrong.inventory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.Barcode128;

import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.toedter.calendar.JDateChooser;

import eStrong.users.EstrongDbConnection;


public class NewInvoicePanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public JTable table;
	public DefaultTableModel model;
	double qtty, qAndP, uPrice, grandTotal;
	public JTextField idField;
	private JDateChooser chooser;
	private JLabel[] addItemLabel = new JLabel[5];
	private JTextField[] inputField = new JTextField[5];
	private JButton[] buttons = new JButton[4];
	private JLabel statusLabel;
	private int s_no;// from inventory product id
	private JTable table2;
	private DefaultTableModel model2;

	public NewInvoicePanel() {
		setLayout(new BorderLayout());
		setBorder(new LineBorder(Color.BLACK, 2));

		JPanel northPanel = new JPanel();
		northPanel.setBackground(Color.GRAY);

		northPanel.add(new InventoryPanel());
		add(northPanel, BorderLayout.NORTH);

		//
		// centerPanel for input and it label
		JPanel mainCenterPanel = new JPanel(new GridLayout(2, 1));
		// mainCenterPanel.setBorder(new EmptyBorder(10,10,10,10));

		JPanel centerPanel = new JPanel(new GridLayout(6, 2, 5, 5));
		JLabel myLabel = new JLabel("DATE:");
		myLabel.setForeground(new Color(0, 0, 0));
		myLabel.setFont(new Font("David", 1, 16));

		centerPanel.add(myLabel);
		//
		chooser = new JDateChooser();
		chooser.setLocale(Locale.US);
		centerPanel.add(chooser);

		centerPanel.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		// centerPanel.setBackground(Color.WHITE);
		JPanel addPanel2Center = new JPanel(new GridLayout(1, 2, 10, 10));
		// addPanel2Center.setBackground(Color.WHITE);
		addPanel2Center.add(centerPanel);
		addPanel2Center.setBorder(new LineBorder(new Color(204, 204, 204), 3));

		for (int i = 0; i < inputField.length; i++) {
			inputField[i] = new JTextField();
			addItemLabel[i] = new JLabel();
			addItemLabel[i].setForeground(new Color(0, 0, 0));
			addItemLabel[i].setFont(new Font("David", 1, 16));
			inputField[i].setFont(new Font("David", 1, 16));
			inputField[i].setBorder(new LineBorder(new Color(204, 204, 204), 3));
			centerPanel.add(addItemLabel[i]);
			centerPanel.add(inputField[i]);
		}

		inputField[0].setEditable(false);
		inputField[1].addFocusListener(new QuantitycompListener());

		//

		addItemLabel[0].setText("PRODUCT DESCRIPTION:");
		addItemLabel[1].setText("QUANTITY:");
		addItemLabel[2].setText("SELLING PRICE:");
		addItemLabel[3].setText("CUSTOMER NAME:");
		addItemLabel[4].setText("CUSTOMER ADDR:");

		// operational button, save clear buttons
		JPanel operationPanel = new JPanel(new GridLayout(1, 2));
		operationPanel.setBackground(Color.WHITE);

		JPanel operationBtnPanel = new JPanel(new GridLayout(4, 1, 6, 6));
		operationBtnPanel.setBackground(Color.WHITE);

		operationPanel.add(operationBtnPanel);
		JPanel eastPanel = new JPanel(new BorderLayout());
		eastPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

		ImageIcon cmpIcon = new ImageIcon(getClass().getResource("/e_Strong/images/display.png"));

		statusLabel = new JLabel("", cmpIcon, JLabel.CENTER);

		eastPanel.add(statusLabel, BorderLayout.CENTER);
		statusLabel.setForeground(Color.RED);
		statusLabel.setFont(new Font("David", 1, 30));
		statusLabel.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		//
		// eastPanel.setBackground(Color.WHITE);
		operationPanel.add(eastPanel);

		//
		for (int j = 0; j < buttons.length; j++) {
			buttons[j] = new JButton();
			buttons[j].setForeground(new Color(0, 0, 0));
			buttons[j].setFont(new Font("David", 1, 16));
			operationBtnPanel.add(buttons[j]);
			buttons[j].addActionListener(new ButtonListener());
			buttons[j].addFocusListener(new HoverEffect());
			buttons[j].setBackground(new Color(0, 194, 255));
			buttons[j].setForeground(Color.WHITE);
		}
		buttons[0].setText("ADD");
		buttons[1].setText("DELETE ROW");
		buttons[2].setText("CLEAR TABLE");
		buttons[3].setText("SAVE/PRINT");

		//
		addPanel2Center.add(operationPanel);
		mainCenterPanel.add(addPanel2Center);
		add(mainCenterPanel, BorderLayout.CENTER);

		// table
		// table for inserted data from input field
		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 18));
		table.getTableHeader().setBackground(new Color(0, 194, 255));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(25);
		table.setForeground(Color.BLACK);
		table.setFont(new Font("David", Font.BOLD, 13));

		table.addMouseListener(new SetBackTextFieldValueListener());
		String tableColumn[] = { "Id", "Product_Name", "Quantity", "Selling_Price", "TotalPrice" };
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(tableColumn);
		JScrollPane scrollBar = new JScrollPane(table);
		//
		JPanel tablePanel = new JPanel(new GridLayout());
		tablePanel.add(scrollBar);
		mainCenterPanel.add(tablePanel);
	}

	//
	/*
	 * this method retrieve product record from the table
	 * 
	 */
	private void getProductName() {
		int sNo = 0;
		String prdName = null;
		String loctn = null, dateTime = null, supplier = null;
		double selingP = 0, costP = 0;
		int quanti = 0;
		try {

			String qry = "Select * from allitems_Inventory";
			PreparedStatement ps = EstrongDbConnection.getConnection().prepareStatement(qry);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				sNo = rs.getInt("serialNo");
				prdName = rs.getString("itemname");
				loctn = rs.getString("itemLocation");
				dateTime = rs.getString("DateNow");
				quanti = rs.getInt("quantity");
				selingP = rs.getDouble("sellingPrice");
				costP = rs.getDouble("costPrice");
				supplier = rs.getString("supplier");
				//
				model2.addRow(new String[] { "" + sNo, prdName, "" + quanti, "" + costP, "" + selingP, loctn, supplier,
						dateTime });
				//
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	// button class
	private class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent ev) {

			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("ADD")) {
				if (chooser.getDate() == null || inputField[0].getText().isEmpty() || inputField[1].getText().isEmpty()
						|| inputField[2].getText().isEmpty() || inputField[4].getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Input fied is empty...");
					model.setRowCount(0);
				} else
					try {
						int qtty = Integer.parseInt(inputField[1].getText().trim());
						double sellingPrice = Double.parseDouble(inputField[2].getText().trim());
						double totalamount = (qtty * sellingPrice);

						model.addRow(new String[] { "" + s_no, inputField[0].getText().toString(), "" + qtty,
								"" + sellingPrice, "" + totalamount });
						inputField[1].setText("");
						inputField[0].setText("");
					} catch (NumberFormatException nfe) {
						JOptionPane.showMessageDialog(null, "Error: number format exception...\nEnter digit only");
					}
			}
			//
			if (btn.getActionCommand().equals("CLEAR TABLE")) {

				int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to clear the table?");
				if (choice == JOptionPane.YES_OPTION) {
					model.setRowCount(0);

				}
			}
			if (btn.getActionCommand().equals("DELETE ROW")) {
				int row = table.getSelectedRow();
				if (row < 0) {
					JOptionPane.showMessageDialog(null, "No table row is selected....");
				} else
					model.removeRow(row);

			}
			if (btn.getActionCommand().equals("SAVE/PRINT")) {
				if (table.getRowCount() != 0) {
					int choice = JOptionPane.showConfirmDialog(null,
							"You are about to Print/Save the table data." + "\n Do you want to to so?");
					if (choice == JOptionPane.YES_OPTION) {

						model2.setRowCount(0);
						getProductName();// refresh product table again
						try {
							claculateAllTableData();
						} catch (DocumentException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}

			}

			if (btn.getActionCommand().equals("UPDATE TABLE")) {
				UpdateProductDialog upd = new UpdateProductDialog(0, null, 0, 0, 0, null, null);
				upd.setVisible(true);
			}

		}

	}
	// manipulating table data

	private void claculateAllTableData() throws DocumentException {

		// generate random no for invoice references
		int serialNo = 0;
		int seed;
		Paragraph posParagraph = null;
		PdfPTable allContentTable = null;
		PdfPTable imagetable1 = null;

		for (seed = 0; seed < 1000; seed++) {
			serialNo = (int) (Math.random() * 1000);
		}
		//
		String fileUrl = "";
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat sformat = null;
		PdfWriter pdfWriter = null;
		Rectangle paperSize = new Rectangle(168.41f, 420);
		Document doc = new Document(paperSize);

		try {
			serialNo++;
			sformat = new SimpleDateFormat("yyyy-MM-dd");
			fileUrl = "C:\\E_Strong_SellFolder\\" + sformat.format(calendar.getTime()) + "_" + serialNo + "_"
					+ inputField[3].getText() + "_" + inputField[4].getText() + "_Receipt.pdf";

			pdfWriter = PdfWriter.getInstance(doc, new FileOutputStream(fileUrl));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		doc.open();
		try {

			// Time for the invoice creation
			com.itextpdf.text.Font red = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN, 6,
					com.itextpdf.text.Font.ITALIC, BaseColor.GRAY);
			//
			sformat = new SimpleDateFormat("yyyy-MM-dd");
			Paragraph dateP = new Paragraph(sformat.format(calendar.getTime()), red);
			dateP.setAlignment(Element.ALIGN_RIGHT);
			doc.add(dateP);

			//
			com.itextpdf.text.Font blueFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN,
					8, com.itextpdf.text.Font.UNDERLINE, BaseColor.BLUE);
			Paragraph blueParag = new Paragraph("E-STRONG ICT INVOICE", blueFont);
			blueParag.setAlignment(Element.ALIGN_CENTER);
			blueParag.setSpacingAfter(10);
			doc.add(blueParag);
			//
			Image logoimage = Image.getInstance(getClass().getResource("/e_Strong/images/e_stronglogo.png"));

			float[] column = { 0.2f };
			// logo table
			imagetable1 = new PdfPTable(column);
			// table width percentage of the page width
			imagetable1.setTotalWidth(1);

			PdfPCell cell1 = new PdfPCell();

			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.addElement(logoimage);
			imagetable1.addCell(cell1);

			Paragraph tableLogo = new Paragraph();
			tableLogo.setAlignment(Element.ALIGN_CENTER);
			tableLogo.add(imagetable1);
			doc.add(tableLogo);
			imagetable1.setSpacingBefore(30);
			imagetable1.setSpacingAfter(40);

			// ------------------------------------------------------------------------------------------

			com.itextpdf.text.Font blackInk = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN,
					4, com.itextpdf.text.Font.NORMAL, BaseColor.BLACK);
			Paragraph addrP = new Paragraph(
					"Address: No.4 University Road Nsukka, Enugu State\nPhone:" + " 08169793006, 08087480035",
					blackInk);
			addrP.setAlignment(Element.ALIGN_CENTER);

			float[] addrCol = { 1f };
			// address table
			PdfPTable addrT = new PdfPTable(addrCol);
			PdfPCell addrCell = new PdfPCell();
			addrCell.setBorder(Rectangle.NO_BORDER);

			addrCell.addElement(addrP);
			addrT.addCell(addrCell);
			Paragraph addrParagraph = new Paragraph();
			addrParagraph.setAlignment(Element.ALIGN_CENTER);
			addrParagraph.add(addrT);
			doc.add(addrParagraph);
			addrT.setSpacingBefore(40);
			addrT.setSpacingAfter(50);

			// ---------------------------------------------------------------------------------

			// adding table values to paragraph

			com.itextpdf.text.Font blackText = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN,
					5, com.itextpdf.text.Font.NORMAL, BaseColor.BLACK);
			for (int i = 0; i < table.getRowCount(); i++) {
				String productName = (String) table.getValueAt(i, 1);
				int quantit = Integer.parseInt(table.getValueAt(i, 2) + "");
				double unitPric = Double.parseDouble(table.getValueAt(i, 3) + "");
				double totalPric = Double.parseDouble(table.getValueAt(i, 4) + "");

				posParagraph = new Paragraph(

						(i + 1) + ". Item: " + productName + "\n Quantity: " + quantit + "\nUnit Price: " + unitPric
								+ "\nTotal Price: " + totalPric,
						blackText);
				posParagraph.setAlignment(Element.ALIGN_CENTER);
				// doc.add(posParagraph);
				// table cell that contains all the transaction
				float[] cellCol = { 2f };
				allContentTable = new PdfPTable(cellCol);
				allContentTable.addCell(posParagraph);
				doc.add(allContentTable);
			}

			// summing total price column of the table
			grandTotal = 0.00;
			for (int i = 0; i < table.getRowCount(); i++) {

				double totalP = Double.parseDouble(table.getValueAt(i, 4) + "");

				grandTotal = grandTotal + totalP;
			}

			com.itextpdf.text.Font sumText = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.TIMES_ROMAN,
					5, com.itextpdf.text.Font.NORMAL, BaseColor.BLACK);
			// number format for currency
			NumberFormat numberfmt = NumberFormat.getInstance();

			Paragraph tableP2 = new Paragraph("Grand Total:\n" + numberfmt.format(grandTotal) + " (Naira)", sumText);

			float[] sumCol = { 1 };
			PdfPTable sumT = new PdfPTable(sumCol);
			sumT.addCell(tableP2);
			doc.add(sumT);

			// -----------------------------------------------------------

			String cusName = inputField[3].getText().toString();
			String cusAddress = inputField[4].getText().toString();

			//

			Paragraph nameP = new Paragraph("Name:" + cusName, blackText);
			nameP.setAlignment(Element.ALIGN_CENTER);
			doc.add(nameP);
			//
			Paragraph addP = new Paragraph("Address:" + cusAddress, blackText);
			addP.setAlignment(Element.ALIGN_CENTER);
			doc.add(addP);

			// adding bar code
			Barcode128 code128 = new Barcode128();
			code128.setGenerateChecksum(true);
			code128.setCode("EN32078");
			Paragraph barP = new Paragraph();
			barP.setAlignment(Element.ALIGN_CENTER);
			barP.add(code128.createImageWithBarcode(pdfWriter.getDirectContent(), null, null));
			doc.add(barP);

		} catch (DocumentException | IOException e1) {
			e1.printStackTrace();
		} finally {
			if (doc != null) {
				doc.close();
			}
			if (pdfWriter != null) {
				pdfWriter.close();
			}
		}
		// Open the file created immediately

		if (Desktop.isDesktopSupported()) {

			File myFile = new File(fileUrl);

			try {
				Desktop.getDesktop().open(myFile);
				//
				saveInvoiceName(sformat.format(calendar.getTime()) + "_" + serialNo + "_" + inputField[3].getText()
						+ "_" + inputField[4].getText() + "_Receipt.pdf");// invoice list method
				//
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		//

		// ************* When PdfButton is pressed, item Bought will be
		// saved****************
		try {
			PreparedStatement ps = null, pre = null;
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			String bus_date = dateFormat.format(chooser.getDate());
			String querry = "insert into item_purchased (serilaN,productId,product_name, quantity, unitprice,"
					+ " totalprice, CustomerName_adress,mydate) " + "Values(0,?,?,?,?,?,?,?);";
			String updateTable = "Update allitems_Inventory SET quantity = quantity-? where serialNo =?";
			//

			for (int i = 0; i < table.getRowCount(); i++) {
				int soldId = Integer.parseInt(table.getValueAt(i, 0) + "");
				String productName = (String) table.getValueAt(i, 1);
				int quantit = Integer.parseInt(table.getValueAt(i, 2) + "");
				double unitPric = Double.parseDouble(table.getValueAt(i, 3) + "");

				ps = EstrongDbConnection.getConnection().prepareStatement(querry);
				pre = EstrongDbConnection.getConnection().prepareStatement(updateTable);

				//

				ps.setInt(1, soldId);
				ps.setString(2, productName);
				ps.setInt(3, quantit);
				ps.setDouble(4, unitPric);
				ps.setDouble(5, (quantit * unitPric));
				ps.setString(6, inputField[3].getText() + "/" + inputField[4].getText());
				ps.setString(7, bus_date);

				// quanity ordered
				pre.setInt(1, quantit);
				pre.setInt(2, soldId);

				// customer table

				ps.execute();
				pre.executeUpdate();

			}

		} catch (SQLException exc) {
			System.out.println(exc);

		} finally {
			try {
				EstrongDbConnection.getConnection().close();

			} catch (SQLException ex) {
				ex.printStackTrace();
			}

		}
		// triger table for customer
		customerTrigger();
		model.setRowCount(0);// clear all table row

	}// end of the all table data method

	// customer trigger
	private void customerTrigger() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		String bus_date = dateFormat.format(chooser.getDate());

		String customerTrigerTable = "create Trigger if Not Exists my_customerlog AFTER INSERT " + "ON Item_purchased"
				+ " FOR EACH ROW" + " BEGIN "
				+ "INSERT INTO customerlog ( product_name, quantity_bought, selling_price, totalamount, mydate) "
				+ "VALUES (new.product_name, new.quantity, new.unitprice, new.totalprice, new.mydate); END;";
		//
		String cusQry = "INSERT INTO customerlist VALUES(?,?,?)";

		try {
			PreparedStatement ps = null, psCus = null;
			ps = EstrongDbConnection.getConnection().prepareStatement(customerTrigerTable);
			psCus = EstrongDbConnection.getConnection().prepareStatement(cusQry);
			psCus.setString(1, inputField[3].getText().toUpperCase());
			psCus.setString(2, inputField[4].getText().toUpperCase());
			psCus.setString(3, bus_date);

			ps.execute();
			psCus.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	// mouse click on the table listener
	private class SetBackTextFieldValueListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent arg0) {
			int i = table.getSelectedRow();
			inputField[0].setText("" + model.getValueAt(i, 1));
			inputField[1].setText("" + model.getValueAt(i, 2));

		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	// Hover effect class
	private class HoverEffect implements FocusListener {

		@Override
		public void focusGained(FocusEvent ev) {

			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("ADD")) {
				buttons[0].setForeground(new Color(0, 194, 255));
				buttons[0].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("DELETE ROW")) {
				buttons[1].setForeground(new Color(0, 194, 255));
				buttons[1].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("CLEAR TABLE")) {
				buttons[2].setForeground(new Color(0, 194, 255));
				buttons[2].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("PRINT")) {
				buttons[3].setForeground(new Color(0, 194, 255));
				buttons[3].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("UPDATE TABLE")) {
				buttons[4].setForeground(new Color(0, 194, 255));
				buttons[4].setBackground(Color.WHITE);
			}
		}

		@Override
		public void focusLost(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("ADD")) {
				buttons[0].setForeground(Color.WHITE);
				buttons[0].setBackground(new Color(0, 194, 255));
			}
			if (btn.getActionCommand().equals("DELETE ROW")) {
				buttons[1].setForeground(Color.WHITE);
				buttons[1].setBackground(new Color(0, 194, 255));
			}
			if (btn.getActionCommand().equals("CLEAR TABLE")) {
				buttons[2].setForeground(Color.WHITE);
				buttons[2].setBackground(new Color(0, 194, 255));
			}
			if (btn.getActionCommand().equals("SAVE/PRINT")) {
				buttons[3].setForeground(Color.WHITE);
				buttons[3].setBackground(new Color(0, 194, 255));
			}

		}

	}
	// sale invoice generated from purchase

	private void saveInvoiceName(String invoiceName) {

		PreparedStatement ps = null;
		try {
			ps = EstrongDbConnection.getConnection().prepareStatement("insert into invoiceList Values (?)");
			ps.setString(1, invoiceName);
			ps.execute();
		} catch (SQLException exc) {
			System.out.println("invoice name list error\n" + exc);
		}
	}

	// inner inventory panel class

	private class InventoryPanel extends JPanel {

		private static final long serialVersionUID = 1L;
		private JTextField searchField;
		private DefaultTableCellRenderer cellRenderer;
		private TableRowSorter<DefaultTableModel> sorter;
		private JButton refreshB;

		public InventoryPanel() {

			setBackground(Color.WHITE);

			JPanel southPanel2 = new JPanel();
			southPanel2.setLayout(new FlowLayout(FlowLayout.RIGHT));

			southPanel2.setBackground(Color.WHITE);

			searchField = new JTextField();
			searchField.setPreferredSize(new Dimension(250, 30));
			searchField.setFont(new Font("David", 1, 16));
			searchField.setBorder(new LineBorder(Color.GRAY));
			searchField.addKeyListener(new ItemSearchListener());
			JLabel searchLabel = new JLabel("Search:");
			searchLabel.setFont(new Font("David", 1, 16));
			southPanel2.add(searchLabel);
			southPanel2.add(searchField);
			//
			JLabel titleLabel = new JLabel("<html><body><div>"
					+ "<h2> SALE POINT <span style=color:red> <i>AND</i> INVOICE CREATION</span></h2><hr/></div></body></html>");
			southPanel2.add(titleLabel);
			//

			refreshB = new JButton("REFRESH");
			refreshB.setPreferredSize(new Dimension(200, 40));
			refreshB.setForeground(Color.WHITE);
			refreshB.setBackground(new Color(0, 194, 255));
			refreshB.setFont(new Font("David", 1, 16));
			southPanel2.add(refreshB);
			refreshB.addActionListener(new RefreshListener());

			//

			String tableColumn1[] = { "S/No", "ProductDescription", "Quantity", "CostPrice", "SellingPrice",
					"Item's Location", "Supplier", "Date" };
			table2 = new JTable();
			table2.getTableHeader().setFont(new Font("David", Font.BOLD, 18));
			table2.getTableHeader().setBackground(new Color(0, 194, 255));
			table2.getTableHeader().setForeground(Color.WHITE);
			table2.getTableHeader().setOpaque(false);
			table2.setRowHeight(25);
			table2.setForeground(Color.BLACK);
			table2.setFont(new Font("David", Font.BOLD, 12));
			table2.addMouseListener(new RowClickedListener());
			model2 = (DefaultTableModel) table2.getModel();
			model2.setColumnIdentifiers(tableColumn1);

			JScrollPane tableScroll = new JScrollPane(table2);

			tableScroll.setPreferredSize(new Dimension(930, 100));

			JPanel tableScrollPanel = new JPanel(new BorderLayout());

			//
			
			tableScrollPanel.add(southPanel2, BorderLayout.NORTH);
			tableScrollPanel.add(tableScroll,BorderLayout.CENTER);
			add(tableScrollPanel, BorderLayout.NORTH);
			getProductName();// get inventory list
		}

		/*
		 * this method retrieve product record from the table
		 * 
		 */
		private void getProductName() {
			int sNo = 0;
			String prdName = null;
			String loctn = null, dateTime = null, supplier = null;
			double selingP = 0, costP = 0;
			int quanti = 0;
			try {

				String qry = "Select * from allitems_Inventory";
				PreparedStatement ps = EstrongDbConnection.getConnection().prepareStatement(qry);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					sNo = rs.getInt("serialNo");
					prdName = rs.getString("itemname");
					loctn = rs.getString("itemLocation");
					dateTime = rs.getString("DateNow");
					quanti = rs.getInt("quantity");
					selingP = rs.getDouble("sellingPrice");
					costP = rs.getDouble("costPrice");
					supplier = rs.getString("supplier");
					//
					model2.addRow(new String[] { "" + sNo, prdName, "" + quanti, "" + costP, "" + selingP, loctn,
							supplier, dateTime });
					//
				}

			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}

		// sorter focus listener class
		private void sorterProduct(String qry) {
			sorter = new TableRowSorter<DefaultTableModel>(model2);
			table2.setRowSorter(sorter);
			sorter.setRowFilter(RowFilter.regexFilter(qry));
		}

		// key listener class
		private class ItemSearchListener implements KeyListener {

			@Override
			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent arg0) {

				sorterProduct(searchField.getText().toString().toUpperCase());

			}

			@Override
			public void keyTyped(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

		}

		// Table row click, collecting the selected row data
		private class RowClickedListener implements MouseListener {

			@Override
			public void mouseClicked(MouseEvent ev) {

				if (ev.getClickCount() == 1) {
					JTable targetCell = (JTable) ev.getSource();
					int row = targetCell.getSelectedRow();

					s_no = Integer.parseInt((String) targetCell.getValueAt(row, 0));
					String productDescription = (String) targetCell.getValueAt(row, 1);
					double sellingP = Double.parseDouble((String) targetCell.getValueAt(row, 4));

					inputField[0].setText(productDescription);
					inputField[2].setText("" + sellingP);

				}
			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

		}

		// refresh table
		private class RefreshListener implements ActionListener {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				model2.setRowCount(0);
				getProductName();// refresh product table again
			}

		}
	}

	private class QuantitycompListener implements FocusListener {

		@Override
		public void focusGained(FocusEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void focusLost(FocusEvent arg0) {

			try {
				if (Integer.parseInt(inputField[1].getText().trim()) <= 0) {
					JOptionPane.showMessageDialog(null, "Quantity require must not less  or equal zero...");
					inputField[0].setText("");

				} else {
					compareQuantity(inputField[0].getText());
				}
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(null, "Empty quantity fields or string input.");
			}
		}
	}
	
	// Quantity comparison

		private void compareQuantity(String productField) {

			String qry = "Select quantity From allitems_Inventory where itemname=?";
			int qtt = 0;
			try {
				PreparedStatement ps = EstrongDbConnection.getConnection().prepareStatement(qry);

				ps.setString(1, productField);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {

					qtt = rs.getInt("quantity");

				}

				if (Integer.parseInt(inputField[1].getText().toString()) > qtt) {
					JOptionPane.showMessageDialog(null,
							"Required quantity is higher than available quantity\n" + "remove the row.");
					inputField[1].setText("");

				}

				//

			} catch (SQLException ex) {
				System.out.println(ex.getMessage());
			}
		}
}
