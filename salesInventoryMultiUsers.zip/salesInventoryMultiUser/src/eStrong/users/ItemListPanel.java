package eStrong.users;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class ItemListPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static JTable table;
	public static DefaultTableModel model;
	private JTextField qryfield;
	public static DefaultComboBoxModel<String> shelfNameModel = new DefaultComboBoxModel<String>();
	private TableRowSorter<DefaultTableModel> sorter;

	public ItemListPanel() {
		setLayout(new BorderLayout());
		setBorder(new LineBorder(Color.BLACK, 2));

		JPanel northPanel = new JPanel();
		northPanel.setBackground(Color.GRAY);
		JLabel descLabel = new JLabel("LIST OF PRODUCTS STORED", JLabel.CENTER);
		descLabel.setFont(new Font("david", 1, 18));
		descLabel.setForeground(Color.WHITE);
		northPanel.add(descLabel);
		add(northPanel, BorderLayout.NORTH);

		// Center panel, having two fractions of panels, for button and table
		JPanel centerPanel = new JPanel(new BorderLayout());
		JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		btnPanel.setBackground(Color.WHITE);
		//
		qryfield = new JTextField();
		qryfield.addKeyListener(new ItemSorterListener());
		;

		qryfield.setForeground(new Color(0, 0, 0));
		qryfield.setFont(new Font("David", 1, 16));
		qryfield.setBorder(new LineBorder(new Color(204, 204, 204), 3));
		qryfield.setPreferredSize(new Dimension(200, 40));
		//

		JLabel prodtLoctn = new JLabel("SEARCH PRODUCT");
		prodtLoctn.setForeground(new Color(0, 0, 0));
		prodtLoctn.setFont(new Font("David", 1, 16));
		prodtLoctn.setFont(new Font("David", 1, 16));
		//

		//
		btnPanel.add(prodtLoctn);
		btnPanel.add(qryfield);
		//

		JPanel tablePanel = new JPanel(new GridLayout());
		// table for inserted data from input field
		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 18));
		table.getTableHeader().setBackground(new Color(0, 194, 255));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(25);

		String tableColumn1[] = { "S/No", "ProductDescription", "Quantity", "SellingPrice",
				"Item's Location", "Supplier", "Date" };
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(tableColumn1);
		JScrollPane scrollBar = new JScrollPane(table);
		scrollBar.setPreferredSize(new Dimension(770, 400));

		tablePanel.add(scrollBar);
		centerPanel.add(btnPanel, BorderLayout.NORTH);
		centerPanel.add(tablePanel, BorderLayout.CENTER);
		add(centerPanel, BorderLayout.CENTER);
		// AllItems_in_Shelf();// show all stored data when app runs
	}// end of constructor

	public static void AllItems_in_Shelf() {
		int sNo = 0;
		String prdName = null;
		String loctn = null, dateTime = null, supplier = null;
		double selingP = 0;
		int quanti = 0;

		PreparedStatement ps = null;
		ResultSet rs = null;
		String qry = "Select * FROM allitems_Inventory";

		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(qry);

			rs = ps.executeQuery();
			while (rs.next()) {
				sNo = rs.getInt("serialNo");
				prdName = rs.getString("itemname");
				loctn = rs.getString("itemLocation");
				dateTime = rs.getString("DateNow");
				quanti = rs.getInt("quantity");
				selingP = rs.getDouble("sellingPrice");
				supplier = rs.getString("supplier");
				// -------------------------------------------------------------------
				//
				model.addRow(new String[] { "" + sNo, prdName, "" + quanti,  "" + selingP, loctn, supplier,
						dateTime });
				//

			}

		} catch (SQLException exc) {
			System.out.println("Error in combobox item selection" + exc);
		}
	}

	// show item location on the combobox

	// this method is all used by item list button

	// sorter focus listener class
	private void sorterProduct(String qry) {
		sorter = new TableRowSorter<DefaultTableModel>(model);
		table.setRowSorter(sorter);
		sorter.setRowFilter(RowFilter.regexFilter(qry));
	}

	// key listener for product name filtering
	private class ItemSorterListener implements KeyListener {

		@Override
		public void keyPressed(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void keyReleased(KeyEvent arg0) {

			sorterProduct(qryfield.getText().toString().toUpperCase());
		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

	}
}
