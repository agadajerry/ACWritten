package eStrong.users;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;


public class AllDeletedProduct extends JDialog {
	private JTable table;
	private DefaultTableModel model;
	public AllDeletedProduct() {
		setSize(new Dimension(710, 500));
		setTitle("Inventory management system");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setResizable(false);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		JPanel northPanel = new JPanel();
		northPanel.setBackground(new Color(255, 255, 255));
		northPanel.setPreferredSize(new Dimension(1200, 200));
		ImageIcon northBgIcon = new ImageIcon(getClass().getResource("/e_Strong/images/product_delete.png"));
		JLabel northLabel = new JLabel("", northBgIcon, JLabel.CENTER);
		setModal(true);
		northPanel.add(northLabel);
		add(northPanel, BorderLayout.NORTH);
		initUi();
	}

	private void initUi() {
		
		table = new JTable();
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 24));
		table.getTableHeader().setBackground(new Color(0, 130, 230));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(30);
		table.setForeground(Color.RED);
		table.setFont(new Font("David", Font.BOLD, 16));

		String tableColumn[] = { "Product_Name", "Quantity", "Selling_Price", "TotalPrice" };
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(tableColumn);
		JScrollPane scrollBar = new JScrollPane(table);
		//
		JPanel tablePanel = new JPanel(new GridLayout());
		tablePanel.add(scrollBar);
		add(tablePanel,BorderLayout.CENTER);
		
		showDeletedItem();//selected deleted table function
	}
	
	//method for select all deleted product from the table
	private void showDeletedItem() {
		try {
			PreparedStatement ps = EstrongDbConnection.getConnection().prepareStatement("Select * from deleted_product "
					+ "order by deleted_date DESC");
			ResultSet rs =ps.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException ex) {
			System.out.println("select deleted product error\n"+ex);
		}
	}

}
