package eStrong.users;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


import net.proteanit.sql.DbUtils;

public class InvoiceListDialog extends JDialog {
	
	private static final long serialVersionUID = 1L;
	private static JTable table;
	private DefaultTableModel model;

	public InvoiceListDialog() {
		setSize(new Dimension(700, 500));
		setTitle("Inventory management system");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setResizable(false);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		JPanel northPanel = new JPanel();
		northPanel.setBackground(new Color(255, 255, 255));
		ImageIcon northBgIcon = new ImageIcon(getClass().getResource("/e_Strong/images/invoice_list.png"));
		JLabel northLabel = new JLabel("", northBgIcon, JLabel.CENTER);
		setModal(true);
		northPanel.add(northLabel);
		add(northPanel, BorderLayout.NORTH);
		JPanel tablePanel = new JPanel(new GridLayout());
		// table for inserted data from input field
		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 18));
		table.getTableHeader().setBackground(new Color(0, 194, 255));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(25);

		String tableColumn[] = { "ItemName" };
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(tableColumn);
		JScrollPane scrollBar = new JScrollPane(table);
		scrollBar.setPreferredSize(new Dimension(730, 400));
		table.addMouseListener(new RowClickedListener());

		tablePanel.add(scrollBar);
		add(tablePanel, BorderLayout.CENTER);

		// select all invoice list
		allInvoiceList();
	}

	private void allInvoiceList() {

		java.sql.PreparedStatement ps = null;
		try {
			ps = EstrongDbConnection.getConnection().prepareStatement("Select * From invoiceList");

			ResultSet rs = ps.executeQuery();

			table.setModel(DbUtils.resultSetToTableModel(rs));

		} catch (SQLException ex) {
			System.out.println("Invoice list table error\n" + ex);
		}
	}

	//
	private class RowClickedListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent ev) {
			if (ev.getClickCount() == 1) {
				JTable targetCell = (JTable) ev.getSource();
				int row = targetCell.getSelectedRow();
				int col = targetCell.getSelectedColumn();
				String text = (String) table.getValueAt(row, col);
				int choice = JOptionPane.showConfirmDialog(null, "Do you want to open " + text + " ?");
				if (choice == JOptionPane.YES_OPTION) {
					if (Desktop.isDesktopSupported()) {

						File myFile = new File("C:\\E_Strong_SellFolder\\" + text);

						try {
							Desktop.getDesktop().open(myFile);
							//

						} catch (IOException e1) {
							System.out.println("Error");
							JOptionPane.showMessageDialog(null, "Selected file does not exist. It might be deleted\n"
									+ "","Document error", JOptionPane.ERROR_MESSAGE);
						}
					}

				}

			}

		}

		@Override
		public void mouseEntered(MouseEvent ev) {

			
		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

	}
}
