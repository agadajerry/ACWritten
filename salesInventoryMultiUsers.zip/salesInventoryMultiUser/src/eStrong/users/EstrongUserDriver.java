package eStrong.users;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.UIManager.LookAndFeelInfo;


public class EstrongUserDriver extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		//UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		new EstrongUserDriver();
		createFolder();
		
		for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {

			if ("Windows Classic".equals(info.getName())) {
				try {
					UIManager.setLookAndFeel(info.getClassName());
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	public EstrongUserDriver(){

		setSize(new Dimension(500, 300));
		setLocationRelativeTo(null);
		setUndecorated(true);
		initialiseUi();
	}

	private void initialiseUi() {

		JPanel welcomePanel = new JPanel();
		welcomePanel.setLayout(null);
		welcomePanel.setBackground(Color.WHITE);
		ImageIcon northBgIcon = new ImageIcon(getClass().getResource("/e_Strong/images/welcome.png"));

		JLabel labelIcon = new JLabel("", northBgIcon, JLabel.CENTER);
		labelIcon.setBounds(0, 50, 500, 173);
		welcomePanel.add(labelIcon);
		JLabel loading = new JLabel("Wait...");
		loading.setBounds(250, 180, 250, 180);
		welcomePanel.add(loading);
		Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource
				 ("/e_Strong/images/e_stronglogo.png"));
				 setIconImage(icon);
		add(welcomePanel);

		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					Thread.sleep(2000);
					E_Strong_Home bizHome = new E_Strong_Home();
					bizHome.setVisible(true);
					dispose();

				} catch (InterruptedException e) {

				}
			}

		}).start();

		setVisible(true);
	}

	private static void createFolder() {
		String dbURL_location = "C:\\E_Strong_SellFolder\\InvoiceFiles\\";

		File newFile = new File(dbURL_location);
		if (!newFile.exists()) {
			newFile.mkdirs();
		}

		// creation of tables for all inventory entry

		PreparedStatement ps = null, psItemBuy = null, psLog = null, psCus = null, ps_invoice = null,
				ps_delete = null, ps_update=null,ps_productRecord=null;
		String qry = "CREATE TABLE IF NOT EXISTS allitems_Inventory ( serialNo INT NOT NULL PRIMARY KEY AUTO_INCREMENT,"
				+ "productId INT NOT NULL, itemname TEXT NOT NULL, "
				+ "quantity INTEGER NOT NULL, costprice INTEGER NOT NULL, " + "sellingprice INTEGER NOT NULL, "
				+ "itemlocation TEXT NOT NULL, supplier TEXT NOT NULL,dateNow VARCHAR(45) NOT NULL,"
				+ "FOREIGN KEY(productId) REFERENCES Product_record(serialNo) "
				+ "ON DELETE CASCADE ON UPDATE CASCADE)";
		//
		String itemboughtUrl = "Create Table If Not Exists item_purchased (serilaN int not null PRIMARY KEY AUTO_INCREMENT,"
				+ "productId INT NOT NULL,"
				+ " product_name TEXT NOT NULL,"
				+ "quantity	INTEGER NOT NULL, Unitprice	INTEGER NOT NULL, totalprice int NOT NUll, "
				+ "CustomerName_adress VARCHAR(45), mydate Text Not Null,FOREIGN KEY(productId) REFERENCES allitems_Inventory(serialNo)"
				+ " ON DELETE CASCADE ON UPDATE CASCADE)";

		String logQry = "CREATE TABLE if not Exists customerlog (product_name Text NOT NULL, "
				+ "quantity_bought	Int NOT NULL, selling_price int NOT NULL, totalamount int NOT NULL, "
				+ "mydate TEXT NOT NULL);";
		//
		String custQry = "CREATE TABLE if not Exists customerlist (cusname	Varchar(100) NOT NULL,"
				+ " cusaddress	Varchar(100) NOT NULL, " + "date Text NOT NULL);";
		
		//
		
		
		
		String deleteTable = "CREATE TABLE IF NOT EXISTS deleted_product (deleted_date TEXT NOT NULL, "
				+ "product_name TEXT NOT NULL," + " quantity INT NOT NULL)";
		String updateQry = "Create Table if not exists update_table (updated_Date Text not null, item_updated Text not null"
				+ ", quantity int NOT NULL)";
		
		String prdtRecord = "CREATE TABLE IF NOT EXISTS Product_record "
				+ "(serialNo INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,"
				+ "productName VARCHAR(45) NOT NULL, VENDOR VARCHAR(45) NOT NULL,"
				+ "ITEMLocation VARCHAR(45) NOT NULL,"
				+ "Category VARCHAR (45), createDate VARCHAR (45) NOT NULL)";
		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(qry);

			psItemBuy = EstrongDbConnection.getConnection().prepareStatement(itemboughtUrl);
			psLog = EstrongDbConnection.getConnection().prepareStatement(logQry);
			psCus = EstrongDbConnection.getConnection().prepareStatement(custQry);
			ps_delete = EstrongDbConnection.getConnection().prepareStatement(deleteTable);
			ps_update = EstrongDbConnection.getConnection().prepareStatement(updateQry);
			ps_productRecord = EstrongDbConnection.getConnection().prepareStatement(prdtRecord);
			
			
			ps_invoice = EstrongDbConnection.getConnection().prepareStatement(
					"Create table if not exists " + "invoiceList (list_Of_invoice_generated" + " TEXT NOT NULL)");
			
			ps_productRecord.execute();
			ps.execute();
			ps_delete.execute();
			psLog.execute();
			ps_invoice.execute();
			psItemBuy.execute();
			psCus.execute();
			ps_update.execute();
		} catch (SQLException ex) {
			System.out.println("All items table creation error" + ex);
			ex.printStackTrace();
		}

		
		
	}
}
