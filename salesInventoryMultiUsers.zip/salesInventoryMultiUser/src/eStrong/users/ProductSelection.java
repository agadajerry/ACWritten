package eStrong.users;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class ProductSelection extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField searchField;
	private DefaultTableCellRenderer cellRenderer;
	private TableRowSorter<DefaultTableModel> sorter;
	private JTable table;
	private DefaultTableModel model;

	public ProductSelection() {
		setSize(new Dimension(1200, 600));
		setTitle("Hospital management system");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setResizable(false);
		setModal(true);
		// setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		dispose();
		setBackground(Color.WHITE);
		JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		northPanel.setBackground(Color.WHITE);
		JLabel northLabel = new JLabel("Product List");

		northPanel.add(northLabel);

		add(northPanel, BorderLayout.NORTH);

		//

		JPanel southPanel2 = new JPanel();
		southPanel2.setLayout(new FlowLayout(FlowLayout.LEFT));

		southPanel2.setBackground(Color.WHITE);

		searchField = new JTextField();
		searchField.setPreferredSize(new Dimension(250, 30));
		searchField.setFont(new Font("David", 1, 16));
		searchField.setBorder(new LineBorder(Color.GRAY));
		searchField.addKeyListener(new ItemSearchListener());
		JLabel searchLabel = new JLabel("Search:");
		searchLabel.setFont(new Font("David", 1, 16));
		southPanel2.add(searchLabel);
		southPanel2.add(searchField);
		// adding components to panel31

		//

		String tableColumn[] = { "S/No", "ItemName", "Vendor", "CATEGORY", "Item's Location", "Date" };
		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 18));
		table.getTableHeader().setBackground(new Color(0, 194, 255));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(25);
		table.setForeground(Color.BLACK);
		table.setFont(new Font("David", Font.BOLD, 12));
		table.addMouseListener(new RowClickedListener());
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(tableColumn);

		JScrollPane tableScroll = new JScrollPane(table);
		JPanel tableScrollPanel = new JPanel(new GridLayout());

		table.getColumnModel().getColumn(0).setPreferredWidth(4);
		table.getColumnModel().getColumn(1).setPreferredWidth(320);
		table.getColumnModel().getColumn(0).setCellRenderer(cellRenderer);
		cellRenderer = new DefaultTableCellRenderer();
		cellRenderer.setHorizontalAlignment(JLabel.CENTER);
		// tableScrollPanel.setBorder(new EmptyBorder(5,5,5,5));
		tableScrollPanel.add(tableScroll);
		//
		JPanel southPanel = new JPanel(new BorderLayout());
		southPanel.setBorder(new LineBorder(Color.GRAY, 2));
		southPanel.setBackground(Color.LIGHT_GRAY);
		southPanel.add(tableScrollPanel, BorderLayout.CENTER);
		southPanel.add(southPanel2, BorderLayout.NORTH);
		add(southPanel, BorderLayout.CENTER);
		getProductName();//get product list
	}

	/*
	 * this method retrive product record from the table
	 * 
	 */
	private void getProductName() {
		int sNo = 0;
		String prdName = null;
		String vendorN = null, loctn = null, dateTime = null, category = null;
		try {

			String qry = "Select * from Product_record";
			PreparedStatement ps = EstrongDbConnection.getConnection().prepareStatement(qry);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				sNo = rs.getInt("serialNo");
				prdName = rs.getString("productName");
				vendorN = rs.getString("VENDOR");
				loctn = rs.getString("ITEMLocation");
				dateTime = rs.getString("createDate");
				category = rs.getString("Category");
				//
				model.addRow(new String[] { "" + sNo, prdName, vendorN, category, loctn, dateTime });
				//
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	// sorter focus listener class
	private void sorterProduct(String qry) {
		sorter = new TableRowSorter<DefaultTableModel>(model);
		table.setRowSorter(sorter);
		sorter.setRowFilter(RowFilter.regexFilter(qry));
	}

	// key listener class
	private class ItemSearchListener implements KeyListener {

		@Override
		public void keyPressed(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void keyReleased(KeyEvent arg0) {

			sorterProduct(searchField.getText().toString().toUpperCase());

		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub

		}

	}

	// Table row click, collecting the selected row data
	private class RowClickedListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent ev) {

			if (ev.getClickCount() == 1) {
				JTable targetCell = (JTable) ev.getSource();
				int row = targetCell.getSelectedRow();

				int idNo = Integer.parseInt((String) targetCell.getValueAt(row, 0));
				String productDescription = (String) targetCell.getValueAt(row, 1);
				String vendorNa = (String) targetCell.getValueAt(row, 2);
				String dCat = (String) targetCell.getValueAt(row, 3);
				String loctn = (String) targetCell.getValueAt(row, 4);

				 new AddNewItemPanel(idNo,productDescription+""
				 		+ " "+vendorNa+" "+dCat,loctn).setVisible(true);;
				 dispose();
				
			}
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

	}
}
