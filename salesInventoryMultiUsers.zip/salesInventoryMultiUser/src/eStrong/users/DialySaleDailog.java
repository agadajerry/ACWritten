package eStrong.users;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

public class DialySaleDailog extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTable table;
	private JLabel totalLabel;
	public JComboBox<String> dateCombo;
	public static DefaultComboBoxModel<String> dateComboModel = new DefaultComboBoxModel<String>();
	private DefaultTableModel model;
	private JButton calBtn;

	public DialySaleDailog() {
		setSize(new Dimension(700, 500));
		setTitle("Inventory management system");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setResizable(false);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		JPanel northPanel = new JPanel();
		northPanel.setBackground(new Color(255, 255, 255));
		ImageIcon northBgIcon = new ImageIcon(getClass().getResource("/e_Strong/images/daily_sale.png"));
		JLabel northLabel = new JLabel("", northBgIcon, JLabel.CENTER);
		setModal(true);
		northPanel.add(northLabel);
		add(northPanel, BorderLayout.NORTH);
		initUi();
	}

	private void initUi() {

		// combobox with sales date

		dateComboModel = new DefaultComboBoxModel<String>();
		dateCombo = new JComboBox<String>(dateComboModel);
		dateCombo.setEditable(true);
		dateCombo.setSize(150, 40);
		AutoCompleteDecorator.decorate(dateCombo);
		dateCombo.addItemListener(new DateSelectionListener());
		calBtn = new JButton("Calculate");
		calBtn.setSize(150, 40);
		calBtn.addActionListener(new CalcualteTotalListener());

		table = new JTable();
		table.getTableHeader().setFont(new Font("David", Font.BOLD, 18));
		table.getTableHeader().setBackground(new Color(0, 194, 255));
		table.getTableHeader().setForeground(Color.WHITE);
		table.getTableHeader().setOpaque(false);
		table.setRowHeight(25);
		table.setForeground(Color.BLACK);
		table.setFont(new Font("David", Font.BOLD, 13));
		//

		String columnName[] = { "ProductName", "Quantity", "SellingPrice" };
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(columnName);
		JScrollPane scrollBar = new JScrollPane(table);
		scrollBar.setPreferredSize(new Dimension(650, 180));
		//

		JPanel tablePanel = new JPanel(new FlowLayout());
		tablePanel.add(dateCombo);
		tablePanel.add(calBtn);
		tablePanel.add(scrollBar);
		add(tablePanel, BorderLayout.CENTER);

		totalLabel = new JLabel("", JLabel.CENTER);
		totalLabel.setForeground(Color.RED);
		totalLabel.setFont(new Font("David", 1, 22));
		JPanel totalPanel = new JPanel();
		totalPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		totalPanel.add(totalLabel);
		add(totalPanel, BorderLayout.SOUTH);

		allPurchaseDate();// date all items was purchased
	}

	/// daily sales calculation
	private void dailySales() {

		PreparedStatement ps = null;
		ResultSet rs = null;
		String qry = "Select product_name, quantity, unitprice" + " From item_purchased" + " where mydate = ?";

		try {
			ps = EstrongDbConnection.getConnection().prepareStatement(qry);
			ps.setString(1, (String) dateCombo.getSelectedItem());
			rs = ps.executeQuery();

			while (rs.next()) {
				String prodName = rs.getString("product_name");
				int qtty = rs.getInt("quantity");
				double sellingPrice = rs.getDouble("unitPrice");

				model.addRow(new String[] { prodName, "" + qtty, "" + sellingPrice });

				
			}

		} catch (

		SQLException ex) {
			System.out.println(ex);
		}
	}

	// total sales

	private void sumTotal() {
		double totalAmount = 0;
		int quantit = 0;
		double unitPric = 0;

		for (int i = 0; i < table.getRowCount(); i++) {
			quantit = Integer.parseInt(table.getValueAt(i, 1) + "");
			unitPric = Double.parseDouble(table.getValueAt(i, 2) + "");
			NumberFormat nFormat = NumberFormat.getInstance();

			totalAmount += quantit * unitPric;
			totalLabel.setText("TOTAL AMOUNT OF ITEMS SOLD TODAY=  " + "" + nFormat.format(totalAmount) + "  Naira");

		}

	}

	// class for date selection
	private class DateSelectionListener implements ItemListener {

		@Override
		public void itemStateChanged(ItemEvent arg0) {

			if (dateCombo.getSelectedIndex() != -1) {

				model.setRowCount(0);
				dailySales();// remove all element from table// refreshing

			}
		}

	}

	// all date purchase was made

	private void allPurchaseDate() {
		String dateTime = "";
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;
		String shelName = "Select DISTINCT mydate from item_purchased order By mydate Desc";

		try {
			ps1 = EstrongDbConnection.getConnection().prepareStatement(shelName);
			rs1 = ps1.executeQuery();
			while (rs1.next()) {
				dateTime = rs1.getString("mydate");
				dateComboModel.addElement(dateTime);

			}
		} catch (SQLException ex) {
			System.out.println("combobox items error" + ex);
		}

	}

	private class CalcualteTotalListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			if (dateCombo.getSelectedIndex() == -1) {
				JOptionPane.showMessageDialog(null, "No date is selected...");
			} else {
				sumTotal();
			}
		}

	}

}
