package eStrong.users;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class EstrongDbConnection {

	public static Connection getConnection() {
		Connection dbConn = null;
		try {

//			String dbURL = "jdbc:sqlite:C:\\E_Strong_SellFolder\\InvoiceFiles\\eStrongIctDatabase.db";
			String mysqlUrl ="jdbc:mysql://192.168.111.1:3306";
			String name ="estrong";
			String pass ="estrong400";
			String useDB = "USE estrong_inventory_db";
			try {
				Class.forName("com.mysql.jdbc.Driver");

				dbConn = DriverManager.getConnection(mysqlUrl, name, pass);
				Statement st = dbConn.createStatement();
				st.execute("Create Database if not exists estrong_inventory_db");
				st.execute(useDB);

			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (SQLException ex) {
			System.out.println(ex.getMessage() + " DB connection");
			ex.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error in database connection. Check your connection..");
		}
		return dbConn;
	}

}
