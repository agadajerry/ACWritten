package eStrong.users;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class E_Strong_Home extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton[] panelBtn = new JButton[8];
	private CardLayout cLayout;
	private JPanel centerPanel;
	public static JLabel saveIcon, infoLabel;
	private JPanel[] sidePanel = new JPanel[8];

	public E_Strong_Home() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.setBounds(0,0,screenSize.width,screenSize.height);
		setTitle("INVENTORY MANAGEMENT SYSTEM");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/e_Strong/images/e_stronglogo.png"));
		setIconImage(icon);
		menuUi();
		this.setBackground(Color.WHITE);

		JPanel northPanel = new JPanel();
		northPanel.setPreferredSize(new Dimension(700,80));
		northPanel.setBorder(new EmptyBorder(10,10,10,10));
		northPanel.setBackground(Color.WHITE);
		
		JLabel northLabel = new JLabel(" ESTRONG ICT INVENTORY MANAGEMENT SYSTEM");

		northLabel.setFont(new Font("Aharoni", Font.BOLD, 32));

		northPanel.add(northLabel);

		add(northPanel, BorderLayout.NORTH);

		// West Panel holding Buttons

		JPanel westPanel = new JPanel(new GridLayout(9, 1, 3, 3));
		
		ImageIcon shopIcon = new ImageIcon(getClass().getResource("/e_Strong/images/e_strong.png"));
		JLabel iconLabel = new JLabel("", shopIcon, JLabel.CENTER);
		iconLabel.setBackground(Color.WHITE);
		iconLabel.setForeground(Color.WHITE);
		westPanel.add(iconLabel);

		for (int i = 0; i < panelBtn.length; i++) {
			panelBtn[i] = new JButton();

			sidePanel[i] = new JPanel();
			//

			panelBtn[i].addActionListener(new PanelButtonListener());
			panelBtn[i].setForeground(Color.WHITE);
			panelBtn[i].setBackground(new Color(0, 194, 255));
			panelBtn[i].setFont(new Font("David", 1, 16));
			panelBtn[i].addFocusListener(new HoverEffectListener());

			//
			sidePanel[i].setPreferredSize(new Dimension(230, 70));
			sidePanel[i].setBackground(Color.WHITE);
			sidePanel[i].setBorder(new EmptyBorder(6, 6, 6, 6));
			sidePanel[i].add(panelBtn[i]);
			westPanel.add(sidePanel[i]);
		}
		panelBtn[0].setText("PRODUCT RECORD");
		panelBtn[1].setText("ADD NEW ITEM");
		panelBtn[2].setText("OPEN ITEM'S LIST");
		panelBtn[3].setText("CREATE NEW INVOICE");
		panelBtn[4].setText("OPEN INVOICE LIST");
		panelBtn[5].setText("CUSTOMERS' LIST");
		panelBtn[6].setText("DAILY SALES");
		panelBtn[7].setText("MONTHLY SALES");

		
		add(westPanel, BorderLayout.WEST);
		// center panel with cardLayout mechanism

		centerPanel = new JPanel();
		
		centerPanel.setBackground(Color.WHITE);
		cLayout = new CardLayout();
		centerPanel.setLayout(cLayout);
		// Adding panels to center panel

		centerPanel.add(new ItemListPanel(), "itemList");
		centerPanel.add(new ProductRecord(), "productRecord");
		centerPanel.add(new NewInvoicePanel(), "newinvoice");
		cLayout.show(centerPanel, "productRecord");
		add(centerPanel, BorderLayout.CENTER);

		// dummy south panel
		JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		southPanel.setBackground(Color.GRAY);
		JLabel devLabel = new JLabel("Designed By JerrySoft", JLabel.RIGHT);
		devLabel.setFont(new Font("Algerian", Font.ITALIC, 10));
		devLabel.setForeground(Color.WHITE);
		southPanel.add(devLabel);
		add(southPanel, BorderLayout.SOUTH);

		this.setVisible(true);
	}

	private void menuUi() {

		// Menu section Code
		// menu bar and items
		JMenuBar mBar = new JMenuBar();
		JMenu filemenu = new JMenu("File");
		filemenu.setMnemonic(KeyEvent.VK_F);
		JMenu editMenu = new JMenu("Edit");
		JMenu help = new JMenu("Help");
		help.setMnemonic(KeyEvent.VK_H);
		editMenu.setMnemonic(KeyEvent.VK_E);

		mBar.add(filemenu);
		mBar.add(editMenu);
		mBar.add(help);
		// mBar.setBackground(new Color(240, 98, 146));

		JMenuItem show_p = new JMenuItem("Update Returned Product");
		JMenuItem monthlySale = new JMenuItem("Monthly Sales");
		
		JMenuItem aboutDev = new JMenuItem("About");
		//
		show_p.addActionListener(new ShowProductPurchase());
		monthlySale.addActionListener(new MonthlySaleListener());
		show_p.setMnemonic(KeyEvent.VK_N);
		aboutDev.setMnemonic(KeyEvent.VK_A);
		aboutDev.addActionListener(new AboutDevListener());
		//

		filemenu.add(show_p);
		filemenu.add(monthlySale);		
		filemenu.addSeparator();
		help.add(aboutDev);
		setJMenuBar(mBar);

	}

	// btn Listener class
	private class PanelButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("ADD NEW ITEM")) {

//				AddNewItemPanel adNew = new AddNewItemPanel(0, null, null);
//				adNew.setVisible(true);
				JOptionPane.showMessageDialog(null, "Contact Admin for this operation...");
			}
			if (btn.getActionCommand().equals("CUSTOMERS' LIST")) {

				AllCustomerList acl = new AllCustomerList();
				acl.setVisible(true);

			}
			if (btn.getActionCommand().equals("OPEN ITEM'S LIST")) {

				cLayout.show(centerPanel, "itemList");
				ItemListPanel.model.setRowCount(0);
				ItemListPanel.AllItems_in_Shelf();
			}
			if (btn.getActionCommand().equals("OPEN INVOICE LIST")) {
				InvoiceListDialog ild = new InvoiceListDialog();
				ild.setVisible(true);

			}
			if (btn.getActionCommand().equals("CREATE NEW INVOICE")) {

				cLayout.show(centerPanel, "newinvoice");


			}
			if (btn.getActionCommand().equals("DAILY SALES")) {

				DialySaleDailog dsd = new DialySaleDailog();
				dsd.setVisible(true);
			}
			if (btn.getActionCommand().equals("MONTHLY SALES")) {

				MonthlySaleDialog dsd = new MonthlySaleDialog();
				dsd.setVisible(true);
			}
			if (btn.getActionCommand().equals("PRODUCT RECORD")) {

				cLayout.show(centerPanel,"productRecord");
			}
		}

	}

	// hover effect class

	private class HoverEffectListener implements FocusListener {

		@Override
		public void focusGained(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("PRODUCT RECORD")) {
				panelBtn[0].setForeground(new Color(0, 194, 255));
				panelBtn[0].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("ADD NEW ITEM")) {
				panelBtn[1].setForeground(new Color(0, 194, 255));
				panelBtn[1].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("OPEN ITEM'S LIST")) {
				panelBtn[2].setForeground(new Color(0, 194, 255));
				panelBtn[2].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("CREATE NEW INVOICE")) {
				panelBtn[3].setForeground(new Color(0, 194, 255));
				panelBtn[3].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("OPEN INVOICE LIST")) {
				panelBtn[4].setForeground(new Color(0, 194, 255));
				panelBtn[4].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("CUSTOMERS' LIST")) {
				panelBtn[5].setForeground(new Color(0, 194, 255));
				panelBtn[5].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("DAILY SALES")) {
				panelBtn[6].setForeground(new Color(0, 194, 255));
				panelBtn[6].setBackground(Color.WHITE);
			}
			if (btn.getActionCommand().equals("MONTHLY SALES")) {
				panelBtn[7].setForeground(new Color(0, 194, 255));
				panelBtn[7].setBackground(Color.WHITE);
			}
		}

		@Override
		public void focusLost(FocusEvent ev) {
			JButton btn = (JButton) ev.getSource();
			if (btn.getActionCommand().equals("PRODUCT RECORD")) {
				panelBtn[0].setForeground(Color.WHITE);
				panelBtn[0].setBackground(new Color(0, 194, 255));
			}
			if (btn.getActionCommand().equals("ADD NEW ITEM")) {
				panelBtn[1].setForeground(Color.WHITE);
				panelBtn[1].setBackground(new Color(0, 194, 255));
			}
			if (btn.getActionCommand().equals("OPEN ITEM'S LIST")) {
				panelBtn[2].setForeground(Color.WHITE);
				panelBtn[2].setBackground(new Color(0, 194, 255));
			}
			if (btn.getActionCommand().equals("CREATE NEW INVOICE")) {
				panelBtn[3].setForeground(Color.WHITE);
				panelBtn[3].setBackground(new Color(0, 194, 255));
			}
			if (btn.getActionCommand().equals("OPEN INVOICE LIST")) {
				panelBtn[4].setForeground(Color.WHITE);
				panelBtn[4].setBackground(new Color(0, 194, 255));
			}
			if (btn.getActionCommand().equals("CUSTOMERS' LIST")) {
				panelBtn[5].setForeground(Color.WHITE);
				panelBtn[5].setBackground(new Color(0, 194, 255));
			}
			if (btn.getActionCommand().equals("DAILY SALES")) {
				panelBtn[6].setForeground(Color.WHITE);
				panelBtn[6].setBackground(new Color(0, 194, 255));
			}
			if (btn.getActionCommand().equals("MONTHLY SALES")) {
				panelBtn[7].setForeground(Color.WHITE);
				panelBtn[7].setBackground(new Color(0, 194, 255));
			}
		}

	}



	// show deleted product
	private class ShowProductPurchase implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {

			CustomerProductListDialog adp = new CustomerProductListDialog();
			adp.setVisible(true);
		}

	}

	// about dev class
	private class AboutDevListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			AboutDeveloperDialog about = new AboutDeveloperDialog();
			about.setVisible(true);
		}

	}

	private class MonthlySaleListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			MonthlySaleDialog msd = new MonthlySaleDialog();
			msd.setVisible(true);
		}
		
	}
}
