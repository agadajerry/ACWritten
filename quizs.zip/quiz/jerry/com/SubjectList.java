package quiz.jerry.com;

public class SubjectList {
	private String subjectName;
	private String candidateName;

	
	

	
	

	public SubjectList(String subjectName) {
		
		this.subjectName = subjectName;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	

}
