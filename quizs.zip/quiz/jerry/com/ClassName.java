package quiz.jerry.com;

public class ClassName {

	private String levelOfClass;

	public ClassName(String levelOfClass) {
		super();
		this.levelOfClass = levelOfClass;
	}

	public String getLevelOfClass() {
		return levelOfClass;
	}

	public void setLevelOfClass(String levelOfClass) {
		this.levelOfClass = levelOfClass;
	}
	
	
}
