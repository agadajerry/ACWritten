package com.shopping;

public class StockItem {

	private int quantity;
	private int unitPrice;
	private String itemName;
	private int sum =0;
	public StockItem(String name, int quant, int unitPrice) {
		this.itemName = name;
		this.quantity = quant;
		this.unitPrice =unitPrice;
		
	}
	public String getItemName() {
		return itemName;
	}
	
	public int getQuantity() {
		return quantity;
	}
	public int getUnitPrice() {
		return unitPrice;
	}
	public StockItem(int sum) {
		this.sum = sum;
	}
	public int getSum() {
		return quantity*unitPrice;
	}
}
