package com.shopping;

import java.util.ArrayList;
import java.util.Scanner;

public class ShoppingCart {
	public static ArrayList<StockItem> stockItems = new ArrayList<StockItem>();
	public static Scanner sc = new Scanner(System.in);
	public static int quantity, unitPrice;
	public static String itemName;
	public static char response;
	public static int sumTotal = 0;

	public static void main(String[] args) {

		System.out.println("Do you want to make a purchase? enter(y)" + " for yes or (n) for No");
		response = sc.next().charAt(0);
		while (response == 'y' || response == 'Y') {
			System.out.println(" enter the name of the items you want to buy");

			itemName = sc.next();
			System.out.println(" enter the Quantity you want to buy");
			quantity = sc.nextInt();
			System.out.println(" enter the Unit Price");
			unitPrice = sc.nextInt();

			System.out.println("Do you want to make more purchase? enter for yes or (n) for No");
			
			stockItems.add(new StockItem(itemName, quantity, unitPrice));
			response = sc.next().charAt(0);
			

		}

		for (int i = 0; i < stockItems.size(); i++) {
			System.out.println("======================================");
			System.out.println("Name Of Item "+stockItems.get(i).getItemName() + "\n" +
		"quantity selected -"+ stockItems.get(i).getQuantity()+"\n"
					+"Unit Price - "+stockItems.get(i).getUnitPrice()+"\nTotal Price -"+ stockItems.get(i).getQuantity()
					*stockItems.get(i).getUnitPrice());
			/*for (int j = 0; i < 1; i++) {
				System.out.println("======================================");
			}*/
		}
		for (int i = 0; i < stockItems.size(); i++) {
			sumTotal += stockItems.get(i).getSum();
		}
		System.out.println("======================================");
		System.out.println("Grand Total Price - " + sumTotal);
		System.out.println("======================================");
	}

}
