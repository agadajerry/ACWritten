package com.agada.jerry;

public class Aphabet {

	public static void main(String[] args) {
		
		char n;

		for(n='A'; n<='Z'; n++) {
			
			
			System.out.print("|"+n);
		
		}
		

	}

}
